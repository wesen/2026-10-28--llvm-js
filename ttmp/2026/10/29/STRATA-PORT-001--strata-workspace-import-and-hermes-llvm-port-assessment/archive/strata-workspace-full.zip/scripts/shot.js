const { chromium } = require('playwright');
(async () => {
  const [,, file, out, hash, theme] = process.argv;
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1360, height: 900 }, colorScheme: theme || 'light', reducedMotion: 'reduce' });
  await p.goto('file://' + file + (hash ? '#' + hash : ''));
  await p.waitForTimeout(800);
  await p.screenshot({ path: out });
  await b.close();
})();
