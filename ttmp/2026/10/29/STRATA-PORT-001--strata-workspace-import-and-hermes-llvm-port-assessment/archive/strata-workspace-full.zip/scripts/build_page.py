"""Build a single browsable HTML page from README.md and examples/*.js.

Usage: python3 -I build_page.py <project_dir> <out_dir> <doc_url>
"""
import html
import os
import re
import shutil
import sys

import markdown

project, out, doc_url = sys.argv[1], sys.argv[2], sys.argv[3]
ex_dir = os.path.join(project, 'examples')
os.makedirs(os.path.join(out, 'examples'), exist_ok=True)

SECTIONS = [
    ('A', 'The maths, simple to complex', range(1, 20)),
    ('B', 'Real-world scenarios', range(20, 30)),
    ('C', 'Design process', range(30, 40)),
    ('D', 'Scientific study', range(40, 50)),
    ('E', 'Meta-design and capstone', range(50, 70)),
]
COMPARISON = {6: 'Comparison examples 1 and 2', 24: 'Comparison example 3', 23: 'Comparison example 4', 25: 'Comparison example 5'}

KEYWORDS = set('''const let var function return if else for of in new await async try catch throw import from export
class typeof true false null undefined this while continue break'''.split())
UNITS = set('bytes kib mib slots jobs ms count'.split())

TOKEN = re.compile(r'''
  (?P<com>//[^\n]*)
| (?P<tpl>`(?:\\.|[^`\\])*`)
| (?P<str>'(?:\\.|[^'\\\n])*'|"(?:\\.|[^"\\\n])*")
| (?P<num>\b0x[0-9a-fA-F]+n?\b|\b\d[\d_]*(?:\.\d+)?(?:e[+-]?\d+)?n?\b)
| (?P<id>[A-Za-z_$][\w$]*)
| (?P<other>[\s\S])
''', re.X)


def highlight(code):
    out_parts = []
    in_result = False   # continuation lines of a multi-line '// →' result keep the result colour
    for m in TOKEN.finditer(code):
        kind = m.lastgroup
        text = m.group(kind)
        esc = html.escape(text, quote=False)
        if kind == 'other' and text.isspace():
            out_parts.append(esc)
            continue
        if kind == 'com':
            if '→' in text:
                cls = 'res'
            elif in_result and re.match(r'//\s{2,}', text):
                cls = 'res'
            else:
                cls = 'com'
            in_result = cls == 'res'
            out_parts.append(f'<span class="{cls}">{esc}</span>')
            continue
        in_result = False
        if False:
            pass
        elif kind in ('tpl', 'str'):
            out_parts.append(f'<span class="str">{esc}</span>')
        elif kind == 'num':
            out_parts.append(f'<span class="num">{esc}</span>')
        elif kind == 'id':
            nxt = code[m.end():m.end() + 1]
            if text in KEYWORDS:
                out_parts.append(f'<span class="kw">{esc}</span>')
            elif text == 'g' and nxt == '.':
                out_parts.append(f'<span class="ns">{esc}</span>')
            elif text in UNITS and nxt == '(':
                out_parts.append(f'<span class="unit">{esc}</span>')
            else:
                out_parts.append(esc)
        else:
            out_parts.append(esc)
    return ''.join(out_parts)


def parse_example(path):
    lines = open(path, encoding='utf-8').read().split('\n')
    header = []
    i = 0
    while i < len(lines) and lines[i].startswith('//'):
        header.append(lines[i][2:].strip())
        i += 1
    body = '\n'.join(lines[i:]).strip('\n') + '\n'
    first = header[0]
    num, title = [s.strip() for s in first.split('·', 1)]
    paras, cur = [], []
    for h in header[1:]:
        if not h:
            if cur:
                paras.append(' '.join(cur))
            cur = []
        else:
            cur.append(h)
    if cur:
        paras.append(' '.join(cur))
    return int(num), num, title, paras, body


def inline_md(text):
    text = html.escape(text, quote=False)
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    return text


def para_html(p):
    m = re.match(r'(Model|Notice):\s*(.*)', p)
    if m:
        return f'<p><span class="lead-label">{m.group(1)}</span> {inline_md(m.group(2))}</p>'
    return f'<p>{inline_md(p)}</p>'


examples = []
for name in sorted(os.listdir(ex_dir)):
    if not name.endswith('.js'):
        continue
    n, num, title, paras, body = parse_example(os.path.join(ex_dir, name))
    examples.append(dict(n=n, num=num, title=title, paras=paras, body=body, file=name,
                         lines=body.count('\n'), anchor=f'ex-{num}'))
    shutil.copy(os.path.join(ex_dir, name), os.path.join(out, 'examples', name))
shutil.copy(os.path.join(project, 'README.md'), os.path.join(out, 'README.md'))

# README → HTML, dropping its H1 (the page header carries the title).
readme = open(os.path.join(project, 'README.md'), encoding='utf-8').read()
readme = re.sub(r'^# .*\n', '', readme, count=1)
readme_html = markdown.markdown(readme, extensions=['tables', 'fenced_code'])
readme_html = readme_html.replace('<table>', '<div class="table-wrap"><table>').replace('</table>', '</table></div>')


def slug(s):
    return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-')


overview_toc = []


def add_ids(m):
    title = re.sub('<[^>]+>', '', m.group(1))
    sid = 'ov-' + slug(title)
    overview_toc.append((sid, title))
    return f'<h2 id="{sid}">{m.group(1)}</h2>'


readme_html = re.sub(r'<h2>(.*?)</h2>', add_ids, readme_html)
# Highlight fenced JS in the README too.
readme_html = re.sub(r'<pre><code class="language-js">([\s\S]*?)</code></pre>',
                     lambda m: '<pre class="code"><code>' + highlight(html.unescape(m.group(1))) + '</code></pre>', readme_html)

nav = ['<nav class="toc" aria-label="Contents">',
       '<label class="filter-label" for="filter">Filter examples</label>',
       '<input id="filter" type="search" placeholder="e.g. roots, eval, law" autocomplete="off">',
       '<p class="toc-head">Overview</p><ul>']
for sid, title in overview_toc:
    nav.append(f'<li><a href="#{sid}">{html.escape(title)}</a></li>')
nav.append('</ul>')
for key, name, rng in SECTIONS:
    items = [e for e in examples if e['n'] in rng]
    nav.append(f'<p class="toc-head">{key} · {html.escape(name)}</p><ul>')
    for e in items:
        nav.append(f'<li data-ex="{e["anchor"]}"><a href="#{e["anchor"]}"><span class="toc-num">{e["num"]}</span>{html.escape(e["title"])}</a></li>')
    nav.append('</ul>')
nav.append('</nav>')

arts = []
for key, name, rng in SECTIONS:
    items = [e for e in examples if e['n'] in rng]
    arts.append(f'<section class="ex-section" id="sec-{key.lower()}"><h2 class="section-title"><span>{key}</span>{html.escape(name)}</h2>')
    for e in items:
        chips = f'<span class="chip">{key}</span>'
        if e['n'] in COMPARISON:
            chips += f'<span class="chip chip-cmp">{COMPARISON[e["n"]]}</span>'
        search_text = html.escape((e['title'] + ' ' + ' '.join(e['paras']) + ' ' + e['body']).lower(), quote=True)
        arts.append(f'''<article class="example" id="{e["anchor"]}" data-search="{search_text}">
<header class="ex-head"><span class="ex-num">{e["num"]}</span><h3>{html.escape(e["title"])}</h3><div class="chips">{chips}</div></header>
<div class="ex-desc">{''.join(para_html(p) for p in e["paras"])}</div>
<div class="code-wrap"><div class="code-bar"><span>examples/{e["file"]} · {e["lines"]} lines</span><span class="code-actions"><a href="examples/{e["file"]}">Raw file</a><button type="button" class="copy" data-file="{e["anchor"]}">Copy code</button></span></div>
<pre class="code" id="code-{e["anchor"]}"><code>{highlight(e["body"])}</code></pre></div>
</article>''')
    arts.append('</section>')

page = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>strata builder API</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Condensed:wght@500;600&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap" rel="stylesheet">
<style>
:root {{
  /* Layout: a fixed contents rail on the left, one reading column of ~72ch for prose, wider code blocks. */
  --bg: #f4f6f8;
  --surface: #ffffff;
  --ink: #17212b;
  --muted: #5a6675;
  --rule: #d9dfe6;
  --accent: #1f6f78;
  --accent-soft: #e2f0f1;
  --result: #8a5a12;
  --code-bg: #fbfcfd;
  --kw: #6b3fa0;
  --str: #2f6b2f;
  --num: #a2441c;
  --com: #7a8593;
  --font-display: "IBM Plex Sans Condensed", "Arial Narrow", system-ui, sans-serif;
  --font-body: "IBM Plex Sans", system-ui, -apple-system, "Segoe UI", sans-serif;
  --font-mono: "IBM Plex Mono", ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
  color-scheme: light;
}}
@media (prefers-color-scheme: dark) {{
  :root:not([data-theme="light"]) {{
    --bg: #11161c; --surface: #171e26; --ink: #e3e9ef; --muted: #9aa7b5; --rule: #2a3440;
    --accent: #5fc0c7; --accent-soft: #173238; --result: #e0b066; --code-bg: #141a21;
    --kw: #c3a2ee; --str: #9fd39a; --num: #f0a27a; --com: #7d8a99; color-scheme: dark;
  }}
}}
:root[data-theme="dark"] {{
  --bg: #11161c; --surface: #171e26; --ink: #e3e9ef; --muted: #9aa7b5; --rule: #2a3440;
  --accent: #5fc0c7; --accent-soft: #173238; --result: #e0b066; --code-bg: #141a21;
  --kw: #c3a2ee; --str: #9fd39a; --num: #f0a27a; --com: #7d8a99; color-scheme: dark;
}}
* {{ box-sizing: border-box; }}
html, body {{ margin: 0; }}
body {{ background: var(--bg); color: var(--ink); font: 16px/1.6 var(--font-body); }}
a {{ color: var(--accent); }}
a:focus-visible, button:focus-visible, input:focus-visible {{ outline: 2px solid var(--accent); outline-offset: 2px; }}
code {{ font-family: var(--font-mono); font-size: 0.88em; }}
.shell {{ display: grid; grid-template-columns: 280px minmax(0, 1fr); min-height: 100%; }}
.toc {{ position: sticky; top: 0; align-self: start; height: 100vh; overflow-y: auto; padding: 24px 16px 40px 24px;
       border-right: 1px solid var(--rule); background: var(--surface); font-size: 14px; }}
.toc ul {{ list-style: none; margin: 0 0 16px; padding: 0; }}
.toc li a {{ display: flex; gap: 8px; padding: 3px 6px; border-radius: 4px; text-decoration: none; color: var(--ink); line-height: 1.35; }}
.toc li a:hover {{ background: var(--accent-soft); }}
.toc li.hidden {{ display: none; }}
.toc-head {{ margin: 16px 0 6px; font: 600 12px/1.3 var(--font-display); letter-spacing: 0.04em; text-transform: uppercase; color: var(--muted); }}
.toc-num {{ font-family: var(--font-mono); color: var(--muted); min-width: 1.6em; font-variant-numeric: tabular-nums; }}
.filter-label {{ display: block; font: 600 12px var(--font-display); text-transform: uppercase; letter-spacing: 0.04em; color: var(--muted); margin-bottom: 6px; }}
#filter {{ width: 100%; padding: 8px 10px; border: 1px solid var(--rule); border-radius: 6px; background: var(--bg); color: var(--ink); font: 14px var(--font-body); }}
main {{ padding: 32px clamp(16px, 4vw, 56px) 80px; min-width: 0; }}
.page-head {{ max-width: 980px; border-bottom: 1px solid var(--rule); padding-bottom: 20px; margin-bottom: 8px; }}
.page-head h1 {{ font: 600 clamp(28px, 4vw, 40px)/1.1 var(--font-display); margin: 0 0 10px; text-wrap: balance; }}
.status {{ display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 12px; }}
.pill {{ font: 500 13px var(--font-body); padding: 3px 10px; border-radius: 999px; border: 1px solid var(--rule); background: var(--surface); color: var(--muted); }}
.pill.warn {{ border-color: var(--result); color: var(--result); }}
.page-head p {{ max-width: 72ch; margin: 0; color: var(--muted); }}
.overview {{ max-width: 980px; }}
.overview h2 {{ font: 600 24px/1.25 var(--font-display); margin: 40px 0 12px; text-wrap: balance; scroll-margin-top: 16px; }}
.overview p, .overview li {{ max-width: 72ch; }}
.table-wrap {{ overflow-x: auto; margin: 12px 0 20px; border: 1px solid var(--rule); border-radius: 8px; background: var(--surface); }}
table {{ border-collapse: collapse; width: 100%; font-size: 14px; }}
th, td {{ text-align: left; vertical-align: top; padding: 8px 12px; border-bottom: 1px solid var(--rule); }}
th {{ font: 600 13px var(--font-display); letter-spacing: 0.02em; color: var(--muted); background: var(--bg); }}
tr:last-child td {{ border-bottom: 0; }}
td code {{ white-space: nowrap; }}
.ex-section {{ max-width: 1100px; margin-top: 56px; }}
.section-title {{ display: flex; align-items: baseline; gap: 12px; font: 600 26px/1.2 var(--font-display); margin: 0 0 4px;
                 padding-bottom: 10px; border-bottom: 2px solid var(--ink); }}
.section-title span {{ font-family: var(--font-mono); font-size: 18px; color: var(--accent); }}
.example {{ margin: 28px 0 0; padding-top: 4px; scroll-margin-top: 12px; }}
.example.hidden {{ display: none; }}
.ex-head {{ display: flex; flex-wrap: wrap; align-items: baseline; gap: 10px 14px; }}
.ex-num {{ font: 500 15px var(--font-mono); color: var(--accent); font-variant-numeric: tabular-nums; }}
.ex-head h3 {{ font: 600 21px/1.25 var(--font-display); margin: 0; text-wrap: balance; }}
.chips {{ display: flex; gap: 6px; flex-wrap: wrap; }}
.chip {{ font: 500 12px var(--font-body); padding: 1px 8px; border-radius: 4px; background: var(--accent-soft); color: var(--accent); }}
.chip-cmp {{ background: transparent; border: 1px solid var(--accent); }}
.ex-desc {{ max-width: 72ch; color: var(--ink); }}
.ex-desc p {{ margin: 8px 0; }}
.lead-label {{ font-weight: 600; color: var(--accent); margin-right: 2px; }}
.code-wrap {{ margin: 12px 0 0; border: 1px solid var(--rule); border-radius: 8px; overflow: hidden; background: var(--code-bg); }}
.code-bar {{ display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; padding: 6px 12px;
            border-bottom: 1px solid var(--rule); font: 12.5px var(--font-mono); color: var(--muted); background: var(--surface); }}
.code-actions {{ display: flex; gap: 12px; align-items: center; }}
.copy {{ font: 500 12.5px var(--font-body); padding: 3px 10px; border-radius: 5px; border: 1px solid var(--rule); background: var(--bg); color: var(--ink); cursor: pointer; }}
.copy:hover {{ border-color: var(--accent); color: var(--accent); }}
pre.code {{ margin: 0; padding: 14px 16px; overflow-x: auto; font: 13px/1.55 var(--font-mono); tab-size: 2; }}
.overview pre.code {{ border: 1px solid var(--rule); border-radius: 8px; background: var(--code-bg); }}
pre.code code {{ font-size: inherit; }}
.kw {{ color: var(--kw); }}
.str {{ color: var(--str); }}
.num {{ color: var(--num); }}
.com {{ color: var(--com); font-style: italic; }}
.res {{ color: var(--result); }}
.ns {{ color: var(--accent); font-weight: 500; }}
.unit {{ color: var(--num); font-weight: 500; }}
.empty {{ display: none; color: var(--muted); margin-top: 32px; }}
.empty.show {{ display: block; }}
@media (max-width: 860px) {{
  .shell {{ grid-template-columns: 1fr; }}
  .toc {{ position: static; height: auto; border-right: 0; border-bottom: 1px solid var(--rule); padding: 16px; }}
}}
@media (prefers-reduced-motion: no-preference) {{ html {{ scroll-behavior: smooth; }} }}
</style>
</head>
<body>
<div class="shell">
{''.join(nav)}
<main>
<header class="page-head">
<h1>strata: a builder API for a composable JS-to-native compiler</h1>
<div class="status"><span class="pill warn">Examples only · nothing implemented</span><span class="pill">35 examples · results illustrative</span><span class="pill">LLVM-ENGINE-002</span></div>
<p>A proposed JavaScript API for stating the compiler as values: semantics, operations, analyses, passes, strategies and engines. It accompanies the architecture note <a href="{doc_url}">Semantics-first architecture for a composable JS compiler and JIT</a>.</p>
</header>
<div class="overview">{readme_html}</div>
<p class="empty" id="empty">No example matches that filter.</p>
{''.join(arts)}
</main>
</div>
<script>
(function () {{
  var input = document.getElementById('filter');
  var examples = Array.prototype.slice.call(document.querySelectorAll('.example'));
  var tocItems = Array.prototype.slice.call(document.querySelectorAll('.toc li[data-ex]'));
  var empty = document.getElementById('empty');
  input.addEventListener('input', function () {{
    var q = input.value.trim().toLowerCase();
    var shown = 0;
    examples.forEach(function (el) {{
      var hit = !q || el.getAttribute('data-search').indexOf(q) !== -1;
      el.classList.toggle('hidden', !hit);
      if (hit) shown++;
    }});
    tocItems.forEach(function (li) {{
      var el = document.getElementById(li.getAttribute('data-ex'));
      li.classList.toggle('hidden', el.classList.contains('hidden'));
    }});
    empty.classList.toggle('show', shown === 0);
  }});
  document.querySelectorAll('button.copy').forEach(function (btn) {{
    btn.addEventListener('click', function () {{
      var code = document.getElementById('code-' + btn.getAttribute('data-file')).innerText;
      var done = function (label) {{ btn.textContent = label; setTimeout(function () {{ btn.textContent = 'Copy code'; }}, 1600); }};
      try {{
        navigator.clipboard.writeText(code).then(function () {{ done('Copied'); }}, function () {{ done('Copy blocked'); }});
      }} catch (e) {{ done('Copy blocked'); }}
    }});
  }});
}})();
</script>
</body>
</html>
'''
open(os.path.join(out, 'index.html'), 'w', encoding='utf-8').write(page)
print('examples', len(examples), 'bytes', len(page))
