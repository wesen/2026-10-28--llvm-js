/* Strata Workbench: the agent panel. One tool, eval, over the workbench's lab scope (host.labScope).
   Follows Form Skate Agent: threads, Mode · Model · Thinking, steps with snapshots and revert, YAML results,
   instructions and the whole Reference on the first turn, a [context] block on the latest. */
(function (root) {
  'use strict';
  const W = root;
  const MD = () => W.StrataMarkdown;
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const store = {
    get(k, d) { try { const v = W.localStorage.getItem('strata.v1.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { W.localStorage.setItem('strata.v1.' + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } },
  };
  const EVAL_TIMEOUT = 25000, RESULT_CUT = 9000, RESULT_STORED = 3000, TURNS_STORED = 30;
  const newThread = () => ({ id: 'a' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), title: 'New thread', turns: [] });
  const S = {
    threads: store.get('threads', []).filter(t => t && Array.isArray(t.turns)),
    active: store.get('thread', null),
    settings: Object.assign({ mode: 'auto', tier: 'default', effort: '' }, store.get('agentSettings', {})),
  };
  if (!S.threads.length) S.threads.push(newThread());
  if (!S.threads.some(t => t.id === S.active)) S.active = S.threads[0].id;
  const thread = () => S.threads.find(t => t.id === S.active) || S.threads[0];
  function persist() {
    const slim = S.threads.map(t => ({ id: t.id, title: t.title, turns: t.turns.slice(-TURNS_STORED).map(u => u.role === 'user' ? { role: 'user', text: u.text } : {
      role: 'agent', text: u.text || '', note: u.note || null, error: !!u.error,
      steps: (u.steps || []).map(s => ({ code: s.code, result: s.result && s.result.length > RESULT_STORED ? s.result.slice(0, RESULT_STORED) + '\n…' : s.result, ms: s.ms, error: !!s.error, changed: !!s.changed, reverted: !!s.reverted })),
    }) }));
    store.set('threads', slim); store.set('thread', S.active); store.set('agentSettings', S.settings);
  }

  let host = null, el = null, busy = false, ctl = null, off = null, samplePromise = null;
  const getSample = () => {
    if (!samplePromise) {
      const use = W.claude && typeof W.claude.use === 'function' ? W.claude.use.bind(W.claude) : null;
      samplePromise = use ? Promise.resolve(use('sample')).catch(() => null) : Promise.resolve(null);
    }
    return samplePromise;
  };
  const OFF = {
    load: 'Claude is not available in this view, so the agent cannot run. Everything else in the workbench works.',
    send: 'Claude is not available here, so the agent is off. Everything else in the workbench works.',
    not_granted: 'Claude is not allowed for this page. You can allow it from the artifact’s permissions.',
    sampling_disabled: 'Claude is not available for this account.',
    not_declared: 'This page no longer asks for Claude.',
    capability_disabled: 'Claude is unavailable in this view.',
    tools_unavailable: 'This view cannot run the agent’s tool.',
    capability_removed: 'This app version cannot run the agent.',
  };
  const NOTES = {
    cancelled: 'Stopped.',
    rate_limited: 'Too many requests just now; try again in a little while.',
    prompt_too_large: 'The conversation is too long. Start a new thread.',
    refused: 'Claude declined this request.',
  };

  /* ---------- YAML for the model ---------- */
  const yaml = v => { if (W.strata && typeof W.strata.yaml === 'function') { try { return W.strata.yaml(v); } catch (e) { /* fall back */ } } return (W.StrataShell && W.StrataShell.yaml) ? W.StrataShell.yaml(v) : JSON.stringify(v, null, 2); };
  const yaml1 = v => typeof v === 'string' ? v : yaml(v).replace(/\s*\n\s*/g, ' ');

  /* ---------- the instructions and the context ---------- */
  function instructions() {
    const ref = (W.STRATA_CONTENT && W.STRATA_CONTENT.reference) || '(The Reference is not loaded in this build.)';
    return `You are the coding agent inside Strata Workbench, a workbench for learning how a compiler works by building one: a JavaScript-to-native compiler framework whose engine is the strata library (the g namespace). A preset is a small set of editable files: main.js, a script that builds and returns a Program, a run, laws or results, and often program.js, the JavaScript the script compiles. The person sees the files, the control-flow graph of one function drawn as a drafting sheet (Stage), every level of the program as text (IR: L0 source, L1 core IR, L2 runtime IR, L3 execution plan, LLVM text, WebAssembly text), analysis facts with their fixed-point iterations (Facts), the execution plan's root slots (Plan), the reference interpreter step by step (Machine), and Events, Laws and Experiments.

You have one tool, eval: it runs an async JavaScript function body in the page and returns the value (as YAML) plus anything you console.log. Use it to read and edit the preset's files, rerun main.js, inspect the compiled program, run it, check laws and save presets. The scope is described below under "The agent's eval scope". Keep results small: pick fields, slice arrays.

How to work:
- Look before you change: files.read(path, from, to) / files.grep(pattern) for the preset's code; ir(level, fn), cfg(fn), facts(fn), plan(fn), perm(opId) and why(target) for the compiled program.
- Change code with files.edit(path, find, replace) (exact, unique text) rather than rewriting files. Then call run() and read { ok, kind, errors }.
- Verify by measuring: exec({ mode: 'spec' | 'plan' | 'wasm', gc: 'off' | 'alloc' | 'stress' }) runs the current program and returns its outcome, output, steps and metrics; a law (g.law.*) returns ok or a minimized counterexample. Compare before and after, and say which mode and GC setting a number came from.
- To keep work for the person, save it as a preset: presets.save({ title, about, files, notes, tries }) returns a new id (U-01, …) kept in the page's shared store or this browser; presets.edit(id, patch) changes one of their own presets; presets.load(id) opens it. Write notes in the workbench's style: a # title, a lede, a Try it callout with lab: links, ## sections, an exercise.
- In Ask mode the person approves each eval; in Read-only mode edits are refused: say what you would change instead.
- Answer in a few short paragraphs of markdown. Name files, lines and op ids; you may include lab: links, which the person can click: [open](lab:open?file=main.js&line=12), [select](lab:node?id=total/body/2), [plan](lab:show?view=plan), [run with GC stress](lab:run?mode=plan&gc=stress), [preset](lab:preset?id=I-03), [chapter](lab:book?ch=4), [iteration](lab:analysis?name=liveness&i=2). Use $…$ for maths.
- Vocabulary: block, block parameter, edge, invoke, terminator, operation, contract, behaviour, obligation, permission, fact, lattice, fixed point, pass, pipeline, refinement, safepoint, root slot, execution plan, provider, artifact, engine. Value ids are SSA names; op ids are fn/block/index, and a block's terminator is fn/block/term.
${ref}`;
  }

  /* ---------- turns for sample() ---------- */
  const firstLine = code => (String(code || '').split('\n').find(l => l.trim()) || '').trim();
  function toTurns(th) {
    let out = [];
    for (const t of th.turns) {
      if (t.role === 'user') out.push({ role: 'user', content: t.text });
      else {
        const lines = (t.steps || []).map(s => `[eval${s.reverted ? ', later reverted' : ''}] ${firstLine(s.code).slice(0, 100)} → ${String(s.result == null ? '' : s.result).replace(/\s+/g, ' ').slice(0, 160)}`);
        out.push({ role: 'assistant', content: (lines.length ? lines.join('\n') + '\n' : '') + (t.text || '(no answer)') });
      }
    }
    while (out.length && out[out.length - 1].role === 'assistant') out.pop();
    const merged = [];
    for (const m of out) { const last = merged[merged.length - 1]; if (last && last.role === m.role) last.content += '\n\n' + m.content; else merged.push(Object.assign({}, m)); }
    out = merged;
    for (let i = out.length - 1; i >= 0; i--) if (out[i].role === 'user') { out[i].content = (host ? host.context() : '[context]\n[/context]') + '\n' + out[i].content; break; }
    const firstUser = out.findIndex(m => m.role === 'user');
    if (firstUser >= 0) out[firstUser].content = instructions() + '\n---\n' + out[firstUser].content;
    return out;
  }

  /* ---------- one eval step ---------- */
  async function runEval(code, readOnly) {
    const scope = host.labScope({ readOnly });
    const logs = [];
    const fmt = a => a.map(x => typeof x === 'string' ? x : yaml1(x)).join(' ');
    const con = { log: (...a) => logs.push(fmt(a)), info: (...a) => logs.push(fmt(a)), warn: (...a) => logs.push('warn: ' + fmt(a)), error: (...a) => logs.push('error: ' + fmt(a)) };
    scope.console = con; scope.log = con.log;
    delete scope.host;
    scope.lab = Object.assign({}, scope);
    const names = Object.keys(scope).filter(k => /^[A-Za-z_$][\w$]*$/.test(k));
    const t0 = performance.now(); let value, error = null;
    try {
      const fn = new Function(...names, '"use strict";\nreturn (async () => {\n' + code + '\n})();\n//# sourceURL=agent-eval.js');
      value = await Promise.race([fn(...names.map(k => scope[k])), new Promise((_, rej) => setTimeout(() => rej(new Error('eval timed out after 25 s')), EVAL_TIMEOUT))]);
    } catch (e) { error = e; }
    const ms = performance.now() - t0;
    let text;
    if (error) {
      const m = String(error && error.stack || '').match(/agent-eval\.js:(\d+)/);
      const line = m ? Math.max(1, +m[1] - 4) : null;
      text = `${error && error.name || 'Error'}: ${error && error.message || String(error)}${line ? ` (line ${line})` : ''}`;
      if (logs.length) text = 'logs:\n' + logs.join('\n') + '\n---\n' + text;
    } else {
      const v = value === undefined ? 'undefined' : yaml(value);
      text = logs.length ? 'logs:\n' + logs.join('\n') + '\n---\n' + v : v;
    }
    if (text.length > RESULT_CUT) text = text.slice(0, RESULT_CUT) + `\n… cut (${text.length} chars). Return less: pick fields, slice arrays.`;
    return { text, error: !!error, ms };
  }
  const filesChanged = snap => {
    const a = snap || {}, b = host.files || {};
    const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
    for (const k of keys) if (a[k] !== b[k]) return true;
    return false;
  };

  /* ---------- a turn ---------- */
  async function send(text) {
    text = String(text || '').trim();
    if (!text || busy) return;
    const sample = await getSample();
    if (!sample) { off = OFF.send; render(); return; }
    const th = thread();
    th.turns.push({ role: 'user', text });
    if (th.title === 'New thread') th.title = text.slice(0, 32);
    const turn = { role: 'agent', text: '', steps: [], pending: true };
    th.turns.push(turn);
    const ta = el && el.querySelector('.composer textarea'); if (ta) ta.value = '';
    busy = true; persist(); render();
    ctl = new AbortController();
    const evalTool = {
      name: 'eval',
      description: 'Run an async JavaScript function body in the workbench with the lab API in scope (files, run, program, ir, cfg, facts, steps, plan, perm, why, exec, g, presets, notes, book, link, …). Returns the value as YAML plus console.log output. Use `return` to return a value.',
      inputSchema: { type: 'object', properties: { code: { type: 'string', description: 'the body of an async function; return what you want to see' } }, required: ['code'] },
      execute: async (input, c) => {
        const code = String((input && input.code) || '');
        const step = { code, result: null, running: true, ms: 0, snapshot: { files: Object.assign({}, host.files) } };
        turn.steps.push(step); render();
        if (S.settings.mode === 'ask') {
          step.asking = true; step.open = true; render();
          const ok = await new Promise(res => {
            step.resolve = res;
            const sig = (c && c.signal) || ctl.signal;
            if (sig) sig.addEventListener('abort', () => res(false), { once: true });
          });
          step.asking = false; step.resolve = null;
          if (!ok) { step.running = false; step.error = true; step.result = 'The person declined this step.'; render(); persist(); return 'Declined by the person. Ask what they want instead, or explain the change without running it.'; }
        }
        let r;
        try { r = await runEval(code, S.settings.mode === 'read'); }
        catch (e) { r = { text: /unsafe-eval|EvalError|Content Security/i.test(String(e)) ? 'Error: this view does not allow running code (the page policy blocks eval)' : 'Error: ' + (e && e.message), error: true, ms: 0 }; }
        step.running = false; step.ms = r.ms; step.result = r.text; step.error = r.error; step.changed = filesChanged(step.snapshot.files);
        render(); persist();
        return r.text;
      },
    };
    const opts = { signal: ctl.signal, cache: false, modelTier: S.settings.tier || 'default', tools: [evalTool], onText: ({ text: t }) => { turn.text = t; renderLog(); } };
    if (S.settings.effort) opts.effort = S.settings.effort;
    try {
      const res = await sample(toTurns(th), opts);
      turn.text = (res && res.text) || turn.text;
      if (res && res.truncated) turn.note = 'The answer hit the length limit.';
    } catch (e) {
      const code = e && e.code;
      if (code === 'refused') turn.text = '';
      if (OFF[code]) { off = OFF[code]; turn.note = OFF[code]; }
      else turn.note = NOTES[code] || ('Interrupted: ' + ((e && (e.message || e.code)) || 'unknown error'));
      if (!turn.text) turn.error = true;
    } finally {
      for (const s of turn.steps) if (s.asking && s.resolve) s.resolve(false);
      turn.pending = false; busy = false; ctl = null; persist(); render();
    }
  }
  function stop() { if (ctl) ctl.abort(); }
  function revert(ti, si) {
    const th = thread(), turn = th.turns[ti], s = turn && turn.steps && turn.steps[si];
    if (!s) return;
    if (!s.snapshot) { host.toast('This step’s snapshot is gone (reloaded page)', true); return; }
    host.restoreFiles(s.snapshot.files);
    for (let j = si; j < turn.steps.length; j++) turn.steps[j].reverted = true;
    host.build(); host.toast('Reverted the files to before that step and rebuilt'); render(); persist();
  }

  /* ---------- rendering ---------- */
  const SEG = (label, key, opts) => `<span class="ctl-l">${label}</span><div class="seg sm" role="group" aria-label="${label}">${opts.map(([v, t, title]) => `<button class="${S.settings[key] === v ? 'on' : ''}" aria-pressed="${S.settings[key] === v}" data-set="${key}" data-val="${esc(v)}"${title ? ` title="${esc(title)}"` : ''}${busy ? '' : ''}>${t}</button>`).join('')}</div>`;
  function suggestions() {
    const p = host && host.preset;
    const own = (p && Array.isArray(p.tries)) ? p.tries : [];
    return own.concat(['Explain what each level does to this program, from L1 to the execution plan', 'Run this program in Plan mode with GC stress and explain any stale value']).slice(0, 6);
  }
  function stepHtml(s, ti, si) {
    const cls = ['tool', s.running && !s.asking ? 'run' : '', s.asking ? 'ask' : '', s.error ? 'err' : '', s.reverted ? 'reverted' : ''].filter(Boolean).join(' ');
    const ms = s.asking ? 'waiting for you' : s.running ? 'running…' : `${Math.round(s.ms)} ms`;
    const hl = MD() ? MD().highlight(s.code, 'js') : esc(s.code);
    return `<details class="${cls}"${s.open || s.asking ? ' open' : ''} data-t="${ti}" data-s="${si}"><summary><i class="dot"></i><span class="nm">eval</span><span class="first">${esc(firstLine(s.code))}</span><span class="ms">${ms}</span></summary><div class="tb"><pre class="src">${hl}</pre>${s.asking ? `<div class="row"><button class="btn primary sm" data-act="approve" data-t="${ti}" data-s="${si}">Run this step</button><button class="btn sm" data-act="decline" data-t="${ti}" data-s="${si}">Decline</button></div>` : ''}${s.result != null ? `<pre class="res${s.error ? ' bad' : ''}">${esc(s.result)}</pre>` : ''}<div class="row">${s.changed && !s.reverted && s.snapshot ? `<button class="link" data-act="revert" data-t="${ti}" data-s="${si}">revert files to before this step</button>` : ''}${s.reverted ? '<span class="dim">reverted</span>' : ''}<button class="link" data-act="copy" data-t="${ti}" data-s="${si}">copy code</button></div></div></details>`;
  }
  function logHtml() {
    const th = thread();
    if (!th.turns.length) {
      const dis = busy || !!off;
      return `<div class="agent-empty"><p>Ask for a change and the agent edits the preset's files, reruns main.js and measures the result: runs in each mode, facts, plans and laws. It can save what it builds as a new preset. It works through one tool, <b>eval</b>, with the same API you see in the Reference.</p><div class="sugg">${suggestions().map(s => `<button data-act="sugg" data-q="${esc(s)}"${dis ? ' disabled' : ''}>${esc(s)}</button>`).join('')}</div></div>`;
    }
    return th.turns.map((t, ti) => {
      if (t.role === 'user') return `<div class="msg user"><span class="who">You</span><div class="body">${esc(t.text)}</div></div>`;
      const steps = (t.steps || []).map((s, si) => stepHtml(s, ti, si)).join('');
      const ans = t.text ? `<div class="md doc-inline">${MD() ? MD().render(t.text, { toc: false }) : esc(t.text)}</div>` : (t.pending ? `<span class="thinking">${t.steps && t.steps.length ? 'Working' : 'Thinking'}</span>` : '');
      return `<div class="msg agent${t.error ? ' error' : ''}"><span class="who">Agent</span>${steps}${ans}${t.note ? `<span class="note">${esc(t.note)}</span>` : ''}</div>`;
    }).join('');
  }
  function renderLog() {
    if (!el) return;
    const log = el.querySelector('.agent-log'); if (!log) return;
    log.innerHTML = logHtml();
    log.scrollTop = log.scrollHeight;
  }
  function render() {
    if (!el) return;
    const th = thread();
    el.querySelector('.threads').innerHTML = S.threads.map(t => `<span class="th${t.id === th.id ? ' on' : ''}"><button data-act="thread" data-id="${esc(t.id)}">${esc(t.title)}</button><button class="x" aria-label="close thread" data-act="close" data-id="${esc(t.id)}">×</button></span>`).join('') + `<button class="new" data-act="new"${busy ? ' disabled' : ''}>+ New</button>`;
    el.querySelector('.agent-set').innerHTML = SEG('Mode', 'mode', [['auto', 'Auto', 'runs each step'], ['ask', 'Ask', 'you approve each step'], ['read', 'Read-only', 'no edits']]) + SEG('Model', 'tier', [['quick', 'Fast'], ['default', 'Balanced'], ['complex', 'Deep']]) + SEG('Thinking', 'effort', [['', 'Auto'], ['low', 'Low'], ['medium', 'Med'], ['high', 'High']]);
    const ob = el.querySelector('.agent-off');
    if (off) { ob.hidden = false; ob.innerHTML = `<b>The agent is off here.</b>${esc(off)}`; } else { ob.hidden = true; ob.innerHTML = ''; }
    renderLog();
    const meta = el.querySelector('.composer .meta');
    meta.textContent = 'Enter sends · Shift+Enter for a new line · ' + ({ auto: 'steps run as they come', ask: 'you approve each step', read: 'read-only' }[S.settings.mode] || '');
    const btn = el.querySelector('.composer [data-act="send"], .composer [data-act="stop"]');
    const ta = el.querySelector('.composer textarea');
    if (busy) { btn.outerHTML = '<button class="btn danger" data-act="stop">Stop</button>'; }
    else { btn.outerHTML = `<button class="btn primary" data-act="send"${(off || !ta.value.trim()) ? ' disabled' : ''}>Send</button>`; }
  }

  function mount(root_, h) {
    host = h || host; el = root_;
    el.innerHTML = `<div class="tabbody col agent-panel"><div class="threads"></div><div class="agent-set"></div><div class="agent-off" hidden></div><div class="agent-log"></div><div class="composer"><textarea placeholder="Ask the agent: “why is this op not erased?”, “make the loop variable int32 and check it”, “save this as a preset”" aria-label="Message to the agent"></textarea><div class="row"><span class="meta"></span><button class="btn primary" data-act="send" disabled>Send</button></div></div></div>`;
    const ta = el.querySelector('.composer textarea');
    ta.value = S.draft || '';
    ta.addEventListener('input', () => { S.draft = ta.value; const b = el.querySelector('.composer [data-act="send"]'); if (b) b.disabled = !!off || !ta.value.trim(); });
    ta.addEventListener('keydown', ev => { if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); const t = ta.value; S.draft = ''; send(t); } });
    el.addEventListener('click', ev => {
      const a = ev.target.closest('a.lablink'); if (a) { ev.preventDefault(); host.link(a.dataset.lab); return; }
      const b = ev.target.closest('[data-act]'); if (!b) return;
      const act = b.dataset.act, ti = +b.dataset.t, si = +b.dataset.s;
      const th = thread(), step = th.turns[ti] && th.turns[ti].steps && th.turns[ti].steps[si];
      if (act === 'send') { const t = ta.value; S.draft = ''; send(t); }
      else if (act === 'stop') stop();
      else if (act === 'sugg') send(b.dataset.q);
      else if (act === 'new') { if (busy) return; const t = newThread(); S.threads.push(t); S.active = t.id; persist(); render(); }
      else if (act === 'thread') { S.active = b.dataset.id; persist(); render(); }
      else if (act === 'close') { if (busy && b.dataset.id === S.active) return; S.threads = S.threads.filter(t => t.id !== b.dataset.id); if (!S.threads.length) S.threads.push(newThread()); if (!S.threads.some(t => t.id === S.active)) S.active = S.threads[S.threads.length - 1].id; persist(); render(); }
      else if (act === 'approve' && step && step.resolve) step.resolve(true);
      else if (act === 'decline' && step && step.resolve) step.resolve(false);
      else if (act === 'revert') revert(ti, si);
      else if (act === 'copy' && step) { Promise.resolve().then(() => navigator.clipboard.writeText(step.code)).then(() => host.toast('Copied'), () => host.toast('Copying is not available here: the clipboard refused it', true)); }
    });
    el.addEventListener('click', ev => { const set = ev.target.closest('[data-set]'); if (set && !ev.target.closest('[data-act]')) { S.settings[set.dataset.set] = set.dataset.val; persist(); render(); } });
    el.addEventListener('toggle', ev => {
      const d = ev.target; if (!d.matches || !d.matches('details.tool')) return;
      const th = thread(), s = th.turns[+d.dataset.t] && th.turns[+d.dataset.t].steps[+d.dataset.s];
      if (s) s.open = d.open;
    }, true);
    render();
    getSample().then(s => { if (!s && !off) { off = OFF.load; } render(); });
  }
  function update(w) { if (w === 'preset' && el && !thread().turns.length) renderLog(); }
  function unmount() { const ta = el && el.querySelector('.composer textarea'); if (ta) S.draft = ta.value; el = null; }
  function prefill(q) {
    S.draft = String(q || '');
    if (el) { const ta = el.querySelector('.composer textarea'); if (ta) { ta.value = S.draft; ta.focus(); ta.dispatchEvent(new Event('input')); } }
  }
  function init(h) { host = h; }

  W.StrataAgent = { mount, update, unmount, prefill, init, instructions, toTurns: () => toTurns(thread()), state: S };
})(typeof window !== 'undefined' ? window : globalThis);
