// core.js: the Strata engine.
// A small compiler framework for a JavaScript subset, built to be read: a reference
// interpreter that defines meaning, a core IR, operation contracts, one fixed-point
// solver, rewrites, lowering with root plans, and two backends (LLVM IR text and
// WebAssembly). Everything is plain JavaScript and runs in a browser or in Node.
(function (root) {
'use strict';

const VERSION = '0.1.0';

// ---------------------------------------------------------------- small helpers

function hashString(text) {                       // FNV-1a, 32 bits, as 8 hex digits
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(16).padStart(8, '0');
}

function stable(value) {                          // JSON with sorted keys, for hashing
  if (value === undefined) return 'undefined';
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
  if (typeof value.toJSON === 'function') return stable(value.toJSON());
  return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stable(value[k])).join(',') + '}';
}

function rng(seed = 1) {                          // mulberry32: deterministic samples
  let a = seed >>> 0;
  const next = () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  next.int = (lo, hi) => lo + Math.floor(next() * (hi - lo + 1));
  next.pick = list => list[Math.floor(next() * list.length)];
  next.chance = p => next() < p;
  return next;
}

const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
const round = (x, d = 3) => Math.round(x * 10 ** d) / 10 ** d;

class StrataError extends Error {
  constructor(message, detail = {}) { super(message); this.name = 'StrataError'; Object.assign(this, detail); }
}

// ---------------------------------------------------------------- YAML (the agent reads this)

const PLAIN = /^[A-Za-z0-9 .,:/()+\-·×→%_@<>=*|[\]#'?!]*$/;

function yamlScalar(v) {
  if (v === null) return 'null';
  if (v === undefined) return 'undefined';
  if (typeof v === 'number') {
    if (Number.isNaN(v)) return 'NaN';
    if (!Number.isFinite(v)) return v > 0 ? 'Infinity' : '-Infinity';
    if (Object.is(v, -0)) return '-0';
    return String(Math.round(v * 1e5) / 1e5);
  }
  if (typeof v === 'boolean') return String(v);
  if (typeof v === 'bigint') return v + 'n';
  if (typeof v === 'function') return `[function ${v.name || 'anonymous'}]`;
  if (typeof v === 'string') {
    if (v.includes('\n')) return null;           // caller writes a block
    if (v.length < 120 && PLAIN.test(v) && v.trim() === v && v !== '' &&
        !/^(true|false|null|undefined|NaN|-?\d)/.test(v) && !/: /.test(v) && !v.startsWith('- ')) return v;
    return JSON.stringify(v);
  }
  return undefined;
}

function yaml(value, indent = '', depth = 0, seen = new Set()) {
  const s = yamlScalar(value);
  if (s !== undefined && s !== null) return s;
  if (typeof value === 'string') {
    return '|\n' + value.split('\n').map(line => indent + '  ' + line).join('\n');
  }
  if (value && typeof value.yamlTag === 'function') return value.yamlTag();
  if (seen.has(value)) return '[circular]';
  if (depth > 5) return Array.isArray(value) ? `[array ${value.length}]` : '{…}';
  seen = new Set(seen); seen.add(value);
  if (value instanceof Map) value = Object.fromEntries(value);
  if (value instanceof Set) value = [...value];
  if (ArrayBuffer.isView(value)) value = Array.from(value);
  if (Array.isArray(value)) {
    if (value.length === 0) return '[]';
    if (value.every(x => typeof x === 'number')) {
      const shown = value.slice(0, 64).map(yamlScalar).join(', ');
      return '[' + shown + (value.length > 64 ? `, … ${value.length - 64} items` : '') + ']';
    }
    const out = value.slice(0, 60).map(item => {
      const body = yaml(item, indent + '  ', depth + 1, seen);
      if (item && typeof item === 'object' && !Array.isArray(item) && !(item.yamlTag) && body.includes('\n')) {
        return indent + '- ' + body.trimStart();
      }
      return indent + '- ' + body;
    });
    if (value.length > 60) out.push(indent + `# … ${value.length - 60} more`);
    return '\n' + out.join('\n');
  }
  if (typeof value === 'object') {
    if (typeof value.toYAML === 'function') return yaml(value.toYAML(), indent, depth, seen);
    const keys = Object.keys(value).filter(k => value[k] !== undefined && typeof value[k] !== 'function');
    if (keys.length === 0) return '{}';
    const out = keys.slice(0, 80).map(k => {
      const body = yaml(value[k], indent + '  ', depth + 1, seen);
      const key = /^[A-Za-z_$][\w$\-/.]*$/.test(k) ? k : JSON.stringify(k);
      return indent + key + ':' + (body.startsWith('\n') ? body : ' ' + body);
    });
    if (keys.length > 80) out.push(indent + `# … ${keys.length - 80} more keys`);
    return (depth === 0 ? '' : '\n') + out.join('\n');
  }
  return String(value);
}

function toYAML(value) {
  const text = yaml(value);
  return text.startsWith('\n') ? text.slice(1) : text;
}

// ---------------------------------------------------------------- quantities with units

class DimensionError extends Error {
  constructor(message) { super(message); this.name = 'DimensionError'; }
}

class Quantity {
  constructor(n, unit) { this.n = n; this.unit = unit; Object.freeze(this); }
  same(q, verb) {
    if (!(q instanceof Quantity)) throw new DimensionError(`cannot ${verb} a plain number and ${this.unit}; give it a unit`);
    if (q.unit !== this.unit) throw new DimensionError(`cannot ${verb} ${q.unit} and ${this.unit}; convert through a layout`);
    return q.n;
  }
  add(q) { return new Quantity(this.n + this.same(q, 'add'), this.unit); }
  sub(q) { return new Quantity(this.n - this.same(q, 'subtract'), this.unit); }
  mul(k) {
    if (k instanceof Quantity) throw new DimensionError(`cannot multiply ${this.unit} by ${k.unit}`);
    return new Quantity(this.n * k, this.unit);
  }
  div(k) { return k instanceof Quantity ? this.n / this.same(k, 'divide') : new Quantity(this.n / k, this.unit); }
  lt(q) { return this.n < this.same(q, 'compare'); }
  le(q) { return this.n <= this.same(q, 'compare'); }
  gt(q) { return this.n > this.same(q, 'compare'); }
  ge(q) { return this.n >= this.same(q, 'compare'); }
  eq(q) { return this.n === this.same(q, 'compare'); }
  max(q) { return this.n >= this.same(q, 'compare') ? this : q; }
  min(q) { return this.n <= this.same(q, 'compare') ? this : q; }
  toString() {
    if (this.unit === 'B') {
      if (this.n !== 0 && this.n % 1048576 === 0) return `${this.n / 1048576} MiB`;
      if (this.n !== 0 && this.n % 1024 === 0) return `${this.n / 1024} KiB`;
      return `${round(this.n, 2)} B`;
    }
    if (this.unit === 'count') return String(this.n);
    const singular = { slots: 'slot', jobs: 'job' }[this.unit];
    return `${round(this.n, 3)} ${this.n === 1 && singular ? singular : this.unit}`;
  }
  toJSON() { return this.toString(); }
  yamlTag() { return this.toString(); }
}

const bytes = n => new Quantity(n, 'B');
const kib = n => bytes(n * 1024);
const mib = n => bytes(n * 1048576);
const slots = n => new Quantity(n, 'slots');
const jobs = n => new Quantity(n, 'jobs');
const ms = n => new Quantity(n, 'ms');
const count = n => new Quantity(n, 'count');
for (const [name, f] of Object.entries({ bytes, slots, jobs, ms, count })) f.unit = f(0).unit, f.unitName = name;

const layout = {
  host64: {
    name: 'host64', slotBytes: 8, align: 16,
    bytes(q) { if (q.unit !== 'slots') throw new DimensionError('layout.bytes takes slots'); return bytes(q.n * 8); },
    slots(q) { if (q.unit !== 'B') throw new DimensionError('layout.slots takes bytes'); return slots(Math.ceil(q.n / 8)); },
  },
};

// ---------------------------------------------------------------- the type lattice
// A type is a set of value kinds. Join is union, meet is intersection, le is inclusion.

const KINDS = ['undefined', 'null', 'boolean', 'int32', 'double', 'string', 'object', 'function', 'cell', 'completion'];
const KBIT = Object.fromEntries(KINDS.map((k, i) => [k, 1 << i]));
const NAMED = {
  bottom: 0, undefined: KBIT.undefined, null: KBIT.null, boolean: KBIT.boolean, int32: KBIT.int32,
  number: KBIT.int32 | KBIT.double, string: KBIT.string, object: KBIT.object, function: KBIT.function,
  cell: KBIT.cell, completion: KBIT.completion,
};
NAMED.any = NAMED.undefined | NAMED.null | NAMED.boolean | NAMED.number | NAMED.string | NAMED.object | NAMED.function;
NAMED.top = NAMED.any | NAMED.cell | NAMED.completion;
NAMED.propertyKey = NAMED.string | NAMED.number;
const MANAGED = KBIT.object | KBIT.function | KBIT.cell | KBIT.completion;

const typeCache = new Map();
class Type {
  constructor(bits) { this.bits = bits; Object.freeze(this); }
  static of(bits) { if (!typeCache.has(bits)) typeCache.set(bits, new Type(bits)); return typeCache.get(bits); }
  join(o) { return Type.of(this.bits | o.bits); }
  meet(o) { return Type.of(this.bits & o.bits); }
  minus(o) { return Type.of(this.bits & ~o.bits); }
  le(o) { return (this.bits & ~o.bits) === 0; }
  eq(o) { return this.bits === o.bits; }
  has(kind) { return (this.bits & KBIT[kind]) !== 0; }
  get managed() { return (this.bits & MANAGED) !== 0; }
  get isBottom() { return this.bits === 0; }
  toString() {
    for (const name of ['bottom', 'any', 'top', 'number']) if (NAMED[name] === this.bits) return name;
    const parts = [];
    let rest = this.bits;
    if ((rest & NAMED.number) === NAMED.number) { parts.push('number'); rest &= ~NAMED.number; }
    for (const k of KINDS) if (rest & KBIT[k]) parts.push(k);
    return parts.join('|');
  }
  toJSON() { return this.toString(); }
  yamlTag() { return this.toString(); }
}

const t = {};
for (const [name, bits] of Object.entries(NAMED)) t[name] = Type.of(bits);
t.union = (...types) => types.reduce((a, b) => a.join(b), t.bottom);
t.parse = text => {
  const parts = String(text).split('|').map(s => s.trim());
  return t.union(...parts.map(p => {
    if (!(p in NAMED)) throw new StrataError(`unknown type ${p}`);
    return t[p];
  }));
};
t.ofValue = v => {                                // the kind of one runtime value
  if (v === undefined) return t.undefined;
  if (v === null) return t.null;
  if (typeof v === 'boolean') return t.boolean;
  if (typeof v === 'number') return (Object.is(v, -0) || (v | 0) !== v) ? Type.of(KBIT.double) : t.int32;
  if (typeof v === 'string') return t.string;
  if (v && v.isRef) return v.kindType || t.object;
  return t.any;
};
t.double = Type.of(KBIT.double);
t.all = () => Object.keys(NAMED).map(n => t[n]);

// Representations: how a value of a type is stored after lowering.
const rep = {
  tagged: { name: 'tagged', canHold: () => true, bits: 64 },
  f64: { name: 'f64', canHold: ty => ty.le(t.number), bits: 64 },
  i32: { name: 'i32', canHold: ty => ty.le(t.int32), bits: 32 },
  bool: { name: 'bool', canHold: ty => ty.le(t.boolean), bits: 32 },
};
for (const r of Object.values(rep)) { r.toString = () => r.name; r.toJSON = () => r.name; }

// ---------------------------------------------------------------- behaviour summaries
// A behaviour is an upper bound on what an operation may do. Join is the union of what
// two operations may do, so it is associative, commutative and idempotent, with `none`
// as the unit and `unknown` as the top.

const USER_RESOURCES = ['heap', 'cells', 'jobs', 'timers', 'globals'];
const ALL_RESOURCES = [...USER_RESOURCES, 'engine'];

class Behaviour {
  constructor({ reads = [], writes = [], fresh = false, throws = false, diverges = false, callsUser = false, host = [] } = {}) {
    this.reads = new Set(reads); this.writes = new Set(writes);
    this.fresh = fresh; this.throws = throws; this.diverges = diverges; this.callsUser = callsUser;
    this.host = new Set(host);
    if (callsUser) {                              // user code may touch every user-visible resource
      for (const r of USER_RESOURCES) { this.reads.add(r); this.writes.add(r); }
      this.fresh = this.throws = this.diverges = true; this.host.add('*');
    }
    Object.freeze(this);
  }
  join(o) {
    return new Behaviour({
      reads: [...this.reads, ...o.reads], writes: [...this.writes, ...o.writes],
      fresh: this.fresh || o.fresh, throws: this.throws || o.throws, diverges: this.diverges || o.diverges,
      callsUser: this.callsUser || o.callsUser, host: [...this.host, ...o.host],
    });
  }
  le(o) {
    const sub = (a, b) => [...a].every(x => b.has(x) || b.has('*'));
    return sub(this.reads, o.reads) && sub(this.writes, o.writes) && sub(this.host, o.host) &&
      (!this.fresh || o.fresh) && (!this.throws || o.throws) && (!this.diverges || o.diverges) &&
      (!this.callsUser || o.callsUser);
  }
  eq(o) { return this.le(o) && o.le(this); }
  has(flag) { return !!this[flag] && (typeof this[flag] !== 'object' || this[flag].size > 0); }
  get isNone() { return this.le(fx.none); }
  get isUnknown() { return this.writes.has('engine'); }
  expand() { return this; }
  toString() {
    if (this.isNone) return 'none';
    if (this.isUnknown) return 'unknown';
    if (this.callsUser) return 'callsUser' + (this.writes.has('engine') ? ', engine' : '');
    const parts = [];
    const rw = [...this.writes].filter(r => !this.reads.has(r));
    const both = [...this.writes].filter(r => this.reads.has(r));
    const ro = [...this.reads].filter(r => !this.writes.has(r));
    if (ro.length) parts.push(`reads(${ro.join(', ')})`);
    if (both.length) parts.push(`reads+writes(${both.join(', ')})`);
    if (rw.length) parts.push(`writes(${rw.join(', ')})`);
    if (this.fresh) parts.push('fresh');
    if (this.throws) parts.push('throws');
    if (this.diverges) parts.push('diverges');
    if (this.host.size) parts.push(`host(${[...this.host].join(', ')})`);
    return parts.join(', ');
  }
  toJSON() { return this.toString(); }
  yamlTag() { return this.toString(); }
}

const fx = {
  none: new Behaviour(),
  reads: (...r) => new Behaviour({ reads: r }),
  writes: (...r) => new Behaviour({ reads: r, writes: r }),
  fresh: new Behaviour({ fresh: true }),
  throws: new Behaviour({ throws: true }),
  diverges: new Behaviour({ diverges: true }),
  callsUser: new Behaviour({ callsUser: true }),
  host: name => new Behaviour({ host: [name] }),
  unknown: new Behaviour({ callsUser: true, reads: ['engine'], writes: ['engine'] }),
  join: (...bs) => bs.reduce((a, b) => a.join(b), new Behaviour()),
  resources: ALL_RESOURCES,
};
fx.of = ops => fx.join(...[...ops].map(o => (o.contract ? o.contract.behaviour : o.behaviour || fx.none)));

// ---------------------------------------------------------------- runtime obligations
// What lowering must guarantee around an operation. A collecting operation borrows its
// managed operands: they must be in root slots while the helper runs.

const OBLIGATIONS = ['mayCollect', 'nonlocalThrow', 'writeBarrier', 'protectsResult', 'sharesBindingCells'];
class Obligations {
  constructor(flags = []) { this.flags = new Set(flags); Object.freeze(this); }
  join(o) { return new Obligations([...this.flags, ...o.flags]); }
  has(flag) { return this.flags.has(flag); }
  le(o) { return [...this.flags].every(f => o.flags.has(f)); }
  toString() { return this.flags.size ? [...this.flags].join(', ') : 'none'; }
  toJSON() { return this.toString(); }
  yamlTag() { return this.toString(); }
}
const ob = { none: new Obligations(), join: (...os) => os.reduce((a, b) => a.join(b), new Obligations()) };
for (const f of OBLIGATIONS) ob[f] = new Obligations([f]);
ob.needsHost = cap => new Obligations(['needsHost:' + cap]);

// ---------------------------------------------------------------- derived permissions
// Permissions answer: may a transformation erase, merge, move, duplicate, hoist or
// speculate this operation? They are derived from the behaviour, never declared.
// Each answer is true, false, or a condition string, with the reasons behind it.

const PERMS = ['erase', 'merge', 'move', 'duplicate', 'hoist', 'speculate'];

function derivePermissions(behaviour, facts = {}) {
  const b = behaviour, out = {}, because = {};
  const blockers = [];
  if (b.callsUser) blockers.push('may run user code');
  if (b.throws) blockers.push('may throw');
  if (b.diverges) blockers.push('may diverge');
  const writes = [...b.writes].filter(r => r !== 'engine' || b.isUnknown);
  if (writes.length) blockers.push(`writes ${writes.join(', ')}`);
  if (b.host.size) blockers.push('talks to the host');
  if (b.isUnknown) blockers.unshift('behaviour unknown');
  const reads = [...b.reads];
  const quiet = blockers.length === 0;           // total, silent, no observable writes

  // erase: only an operation whose result is unused and whose effects are unobservable
  if (quiet && (!b.fresh || facts.identityObserved === false)) out.erase = true;
  else if (quiet && b.fresh) out.erase = 'if its new identity is never observed';
  else out.erase = false;
  because.erase = out.erase === true
    ? ['no writes, no throw, no divergence, no user code' + (b.fresh ? '; the new identity is unobserved' : '')]
    : blockers.length ? blockers.slice() : ['creates a fresh identity'];

  // merge: two evaluations give the same value only without fresh identity
  if (quiet && !b.fresh && reads.length === 0) out.merge = true;
  else if (quiet && !b.fresh) out.merge = `if nothing writes ${reads.join(', ')} between them`;
  else out.merge = false;
  because.merge = out.merge === false ? (b.fresh ? ['creates a fresh identity', ...blockers] : blockers.slice()) : ['deterministic and silent'];

  // move: reorder with neighbours
  if (b.callsUser || b.isUnknown || b.host.size) out.move = false;
  else if (b.throws) out.move = 'not across other operations that throw or write';
  else if (writes.length) out.move = `not across operations that read or write ${writes.join(', ')}`;
  else if (reads.length) out.move = `not across operations that write ${reads.join(', ')}`;
  else out.move = true;
  because.move = out.move === true ? ['no reads, no writes, no throw'] : (out.move === false ? blockers.slice() : [String(out.move)]);

  // duplicate: run it twice where it ran once (e.g. in both arms of a split)
  out.duplicate = quiet && !b.fresh ? true : false;
  because.duplicate = out.duplicate ? ['silent and without fresh identity'] : (b.fresh ? ['creates a fresh identity', ...blockers] : blockers.slice());

  // speculate: run it where it would not have run
  out.speculate = quiet ? (reads.length && !facts.total ? 'with the facts that make it total' : true) : false;
  because.speculate = out.speculate === false ? blockers.slice() : ['cannot throw, diverge or write'];

  // hoist: speculate it out of a loop, keeping one evaluation for all iterations
  if (!quiet || b.fresh) out.hoist = false;
  else if (reads.length) out.hoist = `if nothing in the loop writes ${reads.join(', ')}`;
  else out.hoist = true;
  because.hoist = out.hoist === false ? (b.fresh ? ['creates a fresh identity', ...blockers] : blockers.slice()) : ['loop-invariant when its operands are'];

  return { ...out, because };
}

const PERM_RANK = v => (v === true ? 2 : v === false ? 0 : 1);

// ---------------------------------------------------------------- operations and contracts
// An operation's contract is the one place its behaviour is declared: operand and
// result types, a reference step (what it means), a behaviour summary, runtime
// obligations, how it lowers, and the cheaper variants that facts may select.

class OpDef {
  constructor(spec) {
    Object.assign(this, {
      name: spec.name, set: spec.set || spec.name.split('.')[0],
      operands: spec.operands || [], variadic: !!spec.variadic, results: spec.results || [],
      behaviour: spec.behaviour || fx.none, obligations: spec.obligations || ob.none,
      step: spec.step || null, resultType: spec.resultType || null, lower: spec.lower || null,
      narrow: spec.narrow || null, laws: spec.laws || {}, about: spec.about || '', attrs: spec.attrs || [],
    });
    Object.freeze(this);
  }
  with(patch) { return new OpDef({ ...this, ...patch }); }
  operandsOf(...types) { return this.with({ operands: types }); }
  resultsOf(...types) { return this.with({ results: types }); }
  behaves(b) { return this.with({ behaviour: b }); }
  obliges(o) { return this.with({ obligations: o }); }
  steps(fn) { return this.with({ step: fn }); }
  get mayThrow() { return this.behaviour.throws; }
  get mayCollect() { return this.obligations.has('mayCollect'); }
  get contract() { return { behaviour: this.behaviour, obligations: this.obligations }; }
  typeOf(argTypes, op, fn) {
    if (this.resultType) return this.resultType(argTypes, op, fn);
    return this.results[0] || t.undefined;
  }
  toJSON() { return { name: this.name, behaviour: this.behaviour.toString(), obligations: this.obligations.toString() }; }
  yamlTag() { return `op ${this.name}`; }
}

// The fluent builder spelled as on the API page: g.op('x').operands(...).results(...)...
function opBuilder(name) {
  let spec = { name };
  const b = {
    operands: (...ts) => (spec.operands = ts, b), results: (...ts) => (spec.results = ts, b),
    behaviour: x => (spec.behaviour = x, b), obligations: x => (spec.obligations = x, b),
    step: f => (spec.step = f, b), resultType: f => (spec.resultType = f, b),
    lower: l => (spec.lower = l, b), narrow: f => (spec.narrow = f, b), laws: l => (spec.laws = l, b),
    about: s => (spec.about = s, b), variadic: () => (spec.variadic = true, b),
    build: () => new OpDef(spec),
  };
  Object.defineProperty(b, 'def', { get: () => new OpDef(spec) });
  return b;
}

// Behaviours used by many operations.
const USER = fx.callsUser;                          // may run getters, valueOf, proxies…
const ALLOC = fx.fresh;
const COLLECTS = ob.mayCollect;
const CALLING = ob.join(ob.mayCollect, ob.nonlocalThrow);

const N = t.number, A = t.any, B = t.boolean, S = t.string;
const numeric = (types) => types.every(x => x.le(t.number));
const stringy = (types) => types.some(x => x.le(t.string));

// The result type of js.add from its operand types: string if either is a string,
// number if neither can become a string, otherwise either.
const addType = ([a, b]) => {
  if (a.isBottom || b.isBottom) return t.bottom;   // an operand with no value yet: nothing flows out
  const prim = t.number.join(t.boolean).join(t.null).join(t.undefined);
  if (a.le(t.string) || b.le(t.string)) return t.string;
  if (a.le(prim) && b.le(prim)) return t.number;
  return t.number.join(t.string);
};

const STD = [
  // core: numbers, booleans, identity, guards, direct calls
  { name: 'num.add', operands: [N, N], results: [N], step: (s, [a, b]) => a + b, laws: { commutative: true, associative: false }, lower: { inline: 'fadd' } },
  { name: 'num.sub', operands: [N, N], results: [N], step: (s, [a, b]) => a - b, lower: { inline: 'fsub' } },
  { name: 'num.mul', operands: [N, N], results: [N], step: (s, [a, b]) => a * b, laws: { commutative: true, associative: false }, lower: { inline: 'fmul' } },
  { name: 'num.div', operands: [N, N], results: [N], step: (s, [a, b]) => a / b, lower: { inline: 'fdiv' } },
  { name: 'num.mod', operands: [N, N], results: [N], step: (s, [a, b]) => a % b, lower: { inline: 'frem' } },
  { name: 'num.neg', operands: [N], results: [N], step: (s, [a]) => -a, lower: { inline: 'fneg' } },
  { name: 'num.lt', operands: [N, N], results: [B], step: (s, [a, b]) => a < b, lower: { inline: 'fcmp olt' } },
  { name: 'num.le', operands: [N, N], results: [B], step: (s, [a, b]) => a <= b, lower: { inline: 'fcmp ole' } },
  { name: 'num.gt', operands: [N, N], results: [B], step: (s, [a, b]) => a > b, lower: { inline: 'fcmp ogt' } },
  { name: 'num.ge', operands: [N, N], results: [B], step: (s, [a, b]) => a >= b, lower: { inline: 'fcmp oge' } },
  { name: 'num.eq', operands: [N, N], results: [B], step: (s, [a, b]) => a === b, lower: { inline: 'fcmp oeq' } },
  { name: 'num.ne', operands: [N, N], results: [B], step: (s, [a, b]) => a !== b, lower: { inline: 'fcmp une' } },
  { name: 'i32.add', operands: [t.int32, t.int32], results: [t.int32], step: (s, [a, b]) => (a + b) | 0, laws: { commutative: true, associative: true }, lower: { inline: 'add i32' } },
  { name: 'i32.sub', operands: [t.int32, t.int32], results: [t.int32], step: (s, [a, b]) => (a - b) | 0, lower: { inline: 'sub i32' } },
  { name: 'i32.mul', operands: [t.int32, t.int32], results: [t.int32], step: (s, [a, b]) => Math.imul(a, b), laws: { commutative: true, associative: true }, lower: { inline: 'mul i32' } },
  { name: 'i32.lt', operands: [t.int32, t.int32], results: [B], step: (s, [a, b]) => a < b, lower: { inline: 'icmp slt' } },
  { name: 'i32.eq', operands: [t.int32, t.int32], results: [B], step: (s, [a, b]) => a === b, lower: { inline: 'icmp eq' } },
  { name: 'bool.not', operands: [B], results: [B], step: (s, [a]) => !a, lower: { inline: 'xor i1' } },
  { name: 'bool.and', operands: [B, B], results: [B], step: (s, [a, b]) => a && b, lower: { inline: 'and i1' } },
  { name: 'bool.or', operands: [B, B], results: [B], step: (s, [a, b]) => a || b, lower: { inline: 'or i1' } },
  { name: 'core.copy', operands: [t.top], results: [t.top], step: (s, [a]) => a, resultType: ([a]) => a, lower: { inline: 'copy' } },
  { name: 'core.ref_eq', operands: [A, A], results: [B], step: (s, [a, b]) => s.sameRef(a, b), lower: { inline: 'icmp eq i64' } },
  { name: 'core.is_number', operands: [A], results: [B], step: (s, [a]) => typeof a === 'number', lower: { helper: 'shllvm_typeof_is' } },
  { name: 'core.is_int32', operands: [A], results: [B], step: (s, [a]) => typeof a === 'number' && (a | 0) === a && !Object.is(a, -0), lower: { helper: 'shllvm_typeof_is' } },
  { name: 'core.call', variadic: true, results: [A], behaviour: USER, obligations: CALLING, attrs: ['callee'],
    step: (s, args, op) => s.callDirect(op.attrs.callee, args), resultType: (ts, op, fn) => {
      if (op && op.attrs.resultType) return t.parse(op.attrs.resultType);
      const callee = fn && fn.module && op && fn.module.fn(op.attrs.callee);   // the callee's declared result
      return callee ? callee.result : t.any;
    }, lower: { direct: true } },

  // js.value: the JavaScript operators. Those that convert objects may run user code.
  { name: 'js.add', operands: [A, A], results: [A], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.add(a, b), resultType: addType,
    narrow: ts => numeric(ts) ? 'num.add' : ts.every(x => x.le(t.string)) ? 'str.concat' : null, lower: { helper: 'shllvm_binary', code: 'add' } },
  { name: 'js.sub', operands: [A, A], results: [N], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.toNumber(a) - s.toNumber(b), narrow: ts => numeric(ts) ? 'num.sub' : null, lower: { helper: 'shllvm_binary', code: 'sub' } },
  { name: 'js.mul', operands: [A, A], results: [N], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.toNumber(a) * s.toNumber(b), narrow: ts => numeric(ts) ? 'num.mul' : null, lower: { helper: 'shllvm_binary', code: 'mul' } },
  { name: 'js.div', operands: [A, A], results: [N], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.toNumber(a) / s.toNumber(b), narrow: ts => numeric(ts) ? 'num.div' : null, lower: { helper: 'shllvm_binary', code: 'div' } },
  { name: 'js.mod', operands: [A, A], results: [N], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.toNumber(a) % s.toNumber(b), narrow: ts => numeric(ts) ? 'num.mod' : null, lower: { helper: 'shllvm_binary', code: 'mod' } },
  { name: 'js.neg', operands: [A], results: [N], behaviour: USER, obligations: CALLING, step: (s, [a]) => -s.toNumber(a), narrow: ts => numeric(ts) ? 'num.neg' : null, lower: { helper: 'shllvm_unary', code: 'neg' } },
  { name: 'js.lt', operands: [A, A], results: [B], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.compare(a, b, (x, y) => x < y), narrow: ts => numeric(ts) ? 'num.lt' : null, lower: { helper: 'shllvm_binary', code: 'lt' } },
  { name: 'js.le', operands: [A, A], results: [B], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.compare(a, b, (x, y) => x <= y), narrow: ts => numeric(ts) ? 'num.le' : null, lower: { helper: 'shllvm_binary', code: 'le' } },
  { name: 'js.gt', operands: [A, A], results: [B], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.compare(a, b, (x, y) => x > y), narrow: ts => numeric(ts) ? 'num.gt' : null, lower: { helper: 'shllvm_binary', code: 'gt' } },
  { name: 'js.ge', operands: [A, A], results: [B], behaviour: USER, obligations: CALLING, step: (s, [a, b]) => s.compare(a, b, (x, y) => x >= y), narrow: ts => numeric(ts) ? 'num.ge' : null, lower: { helper: 'shllvm_binary', code: 'ge' } },
  { name: 'js.strict_eq', operands: [A, A], results: [B], step: (s, [a, b]) => s.strictEquals(a, b), narrow: ts => numeric(ts) ? 'num.eq' : null, lower: { helper: 'shllvm_binary', code: 'strict_eq' } },
  { name: 'js.strict_ne', operands: [A, A], results: [B], step: (s, [a, b]) => !s.strictEquals(a, b), narrow: ts => numeric(ts) ? 'num.ne' : null, lower: { helper: 'shllvm_binary', code: 'strict_ne' } },
  { name: 'js.not', operands: [A], results: [B], step: (s, [a]) => !s.truthy(a), narrow: ts => ts[0].le(t.boolean) ? 'bool.not' : null, lower: { helper: 'shllvm_truthy' } },
  { name: 'js.truthy', operands: [A], results: [B], step: (s, [a]) => s.truthy(a), resultType: () => t.boolean, narrow: ts => ts[0].le(t.boolean) ? 'core.copy' : null, lower: { helper: 'shllvm_truthy' } },
  { name: 'js.typeof', operands: [A], results: [S], step: (s, [a]) => s.typeOf(a), lower: { helper: 'shllvm_unary', code: 'typeof' } },
  { name: 'str.concat', operands: [S, S], results: [S], behaviour: ALLOC, obligations: COLLECTS, step: (s, [a, b]) => a + b, lower: { helper: 'shllvm_binary', code: 'add' } },

  // js.object: allocation and properties. A get or put may run a getter or setter.
  { name: 'obj.new', results: [t.object], behaviour: ALLOC, obligations: COLLECTS, step: s => s.newObject(), lower: { helper: 'shllvm_object' } },
  { name: 'arr.new', variadic: true, results: [t.object], behaviour: ALLOC, obligations: COLLECTS, step: (s, args) => s.newArray(args), lower: { helper: 'shllvm_array' } },
  { name: 'js.define', operands: [t.object, S, A], results: [], behaviour: fx.writes('heap'), obligations: ob.join(COLLECTS, ob.writeBarrier), step: (s, [o, k, v]) => s.define(o, k, v), lower: { helper: 'shllvm_define' } },
  { name: 'js.define_getter', operands: [t.object, S, t.function], results: [], behaviour: fx.writes('heap'), obligations: ob.join(COLLECTS, ob.writeBarrier), step: (s, [o, k, f]) => s.defineAccessor(o, k, f, 'get'), lower: { helper: 'shllvm_define_accessor' } },
  { name: 'js.define_setter', operands: [t.object, S, t.function], results: [], behaviour: fx.writes('heap'), obligations: ob.join(COLLECTS, ob.writeBarrier), step: (s, [o, k, f]) => s.defineAccessor(o, k, f, 'set'), lower: { helper: 'shllvm_define_accessor' } },
  { name: 'js.get', operands: [A, t.propertyKey], results: [A], behaviour: USER, obligations: CALLING, step: (s, [o, k]) => s.getProperty(o, k), lower: { helper: 'shllvm_get' } },
  { name: 'js.put', operands: [A, t.propertyKey, A], results: [], behaviour: USER, obligations: ob.join(CALLING, ob.writeBarrier), step: (s, [o, k, v]) => s.setProperty(o, k, v), lower: { helper: 'shllvm_set' } },
  { name: 'js.get_own_data', operands: [t.object, t.propertyKey], results: [A], behaviour: fx.reads('heap'), step: (s, [o, k]) => s.getOwnData(o, k), lower: { helper: 'shllvm_get_id' } },

  // js.function: closures, calls, cells (the storage of captured variables)
  { name: 'js.closure', variadic: true, results: [t.function], behaviour: ALLOC, obligations: COLLECTS, attrs: ['callee'], step: (s, caps, op) => s.newClosure(op.attrs.callee, caps), lower: { helper: 'shllvm_closure' } },
  { name: 'js.call', variadic: true, results: [A], behaviour: USER, obligations: CALLING, step: (s, [f, self, ...args]) => s.callValue(f, self, args), lower: { helper: 'shllvm_call' } },
  { name: 'js.call_method', variadic: true, results: [A], behaviour: USER, obligations: CALLING, step: (s, [o, key, ...args]) => s.callMethod(o, key, args), lower: { helper: 'shllvm_call' } },
  { name: 'cell.new', variadic: true, results: [t.cell], behaviour: ALLOC, obligations: COLLECTS, step: (s, args) => s.newCell(args.length ? args[0] : s.HOLE), lower: { helper: 'shllvm_env_create' } },
  { name: 'cell.load', operands: [t.cell], results: [A], behaviour: fx.reads('cells'), step: (s, [c]) => s.cellLoad(c, false), lower: { helper: 'shllvm_env_load' } },
  { name: 'cell.load_checked', operands: [t.cell], results: [A], behaviour: fx.reads('cells').join(fx.throws), obligations: ob.nonlocalThrow, step: (s, [c], op) => s.cellLoad(c, true, op.attrs.name), lower: { helper: 'shllvm_check_tdz' } },
  { name: 'cell.store', operands: [t.cell, A], results: [], behaviour: fx.writes('cells'), obligations: ob.writeBarrier, step: (s, [c, v]) => s.cellStore(c, v), lower: { helper: 'shllvm_env_store' } },
  { name: 'js.global_get', operands: [S], results: [A], behaviour: fx.reads('globals').join(fx.throws), obligations: ob.nonlocalThrow, step: (s, [n]) => s.globalGet(n), lower: { helper: 'shllvm_global' } },
  { name: 'js.global_put', operands: [S, A], results: [], behaviour: fx.writes('globals'), obligations: ob.writeBarrier, step: (s, [n, v]) => s.globalPut(n, v), lower: { helper: 'shllvm_declare_global' } },
  { name: 'js.new_error', operands: [A], results: [t.object], behaviour: ALLOC.join(USER), obligations: CALLING, attrs: ['kind'], step: (s, [m], op) => s.newError(op.attrs.kind || 'Error', m), lower: { helper: 'shllvm_constructed_object' } },
  { name: 'js.type_error', operands: [S], results: [], behaviour: fx.throws.join(ALLOC), obligations: CALLING, step: (s, [m]) => s.throwError('TypeError', m), lower: { helper: 'shllvm_throw_type_error' } },

  // js.control: the host, jobs, timers, promises, completion records for finally
  { name: 'host.print', variadic: true, results: [], behaviour: fx.host('print'), obligations: COLLECTS, step: (s, args) => s.print(args), lower: { helper: 'shllvm_builtin', code: 'print' } },
  { name: 'job.enqueue', variadic: true, results: [], behaviour: fx.writes('jobs'), obligations: COLLECTS, step: (s, [f, ...args]) => s.enqueue(f, args), lower: { helper: 'shllvm_builtin', code: 'queueMicrotask' } },
  { name: 'timer.set', operands: [t.function, N], results: [], behaviour: fx.writes('timers'), obligations: COLLECTS, step: (s, [f, d]) => s.setTimer(f, d), lower: { helper: 'shllvm_builtin', code: 'setTimeout' } },
  { name: 'promise.resolve', operands: [A], results: [t.object], behaviour: ALLOC.join(fx.writes('jobs')), obligations: COLLECTS, step: (s, [v]) => s.promiseResolve(v), lower: { helper: 'shllvm_builtin', code: 'Promise.resolve' } },
  { name: 'completion.normal', results: [t.completion], behaviour: ALLOC, obligations: COLLECTS, step: s => s.completion('normal'), lower: { helper: 'shllvm_object' } },
  { name: 'completion.return', operands: [A], results: [t.completion], behaviour: ALLOC, obligations: COLLECTS, step: (s, [v]) => s.completion('return', v), lower: { helper: 'shllvm_object' } },
  { name: 'completion.throw', operands: [A], results: [t.completion], behaviour: ALLOC, obligations: COLLECTS, step: (s, [v]) => s.completion('throw', v), lower: { helper: 'shllvm_object' } },
  { name: 'completion.is', operands: [t.completion], results: [B], attrs: ['kind'], step: (s, [c], op) => s.completionIs(c, op.attrs.kind), lower: { helper: 'shllvm_get_id' } },
  { name: 'completion.value', operands: [t.completion], results: [A], step: (s, [c]) => s.completionValue(c), lower: { helper: 'shllvm_get_id' } },
];

const ops = {};
for (const spec of STD) ops[spec.name] = new OpDef(spec);
const opRegistry = Object.assign({}, ops);         // std plus registered extensions

function lookupOp(name) {
  const d = opRegistry[name];
  if (!d) throw new StrataError(`unknown operation ${name}`, { kind: 'unknown-op' });
  return d;
}

// Operation sets group operations; union is a monoid over disjoint names.
class OpSet {
  constructor(name, defs = [], meta = {}) {
    this.name = name; this.version = meta.version || '0.1.0'; this.defs = new Map(defs.map(d => [d.name, d]));
    Object.freeze(this);
  }
  ops(...defs) { return new OpSet(this.name, [...this.defs.values(), ...defs.map(d => (d.def || d))], { version: this.version }); }
  get size() { return this.defs.size; }
  get(name) { return this.defs.get(name); }
  names() { return [...this.defs.keys()]; }
  register() { for (const d of this.defs.values()) opRegistry[d.name] = d; return this; }
  rename(prefix) { return new OpSet(prefix, [...this.defs.values()].map(d => d.with({ name: prefix + d.name.slice(d.name.indexOf('.')) })), { version: this.version }); }
  yamlTag() { return `opset ${this.name}@${this.version} (${this.defs.size} ops)`; }
}
function opsetUnion(...sets) {
  const out = new Map();
  for (const s of sets) for (const d of s.defs.values()) {
    if (out.has(d.name)) throw new StrataError(`OpsetConflict: ${d.name} defined twice`);
    out.set(d.name, d);
  }
  return new OpSet(sets.map(s => s.name).join('+'), [...out.values()]);
}

const SET_OF = name => {
  if (/^(num|i32|bool|core)\./.test(name) || name === 'host.print') return 'core';   // output is the core observation
  if (/^(js\.(add|sub|mul|div|mod|neg|lt|le|gt|ge|strict_eq|strict_ne|not|truthy|typeof)$|str\.)/.test(name)) return 'js.value';
  if (/^(obj|arr)\.|^js\.(define|get|put|get_own_data|new_error)/.test(name)) return 'js.object';
  if (/^(cell|js\.(closure|call|call_method|global_get|global_put|type_error))/.test(name)) return 'js.function';
  return 'js.control';
};
const opsets = {};
for (const d of Object.values(ops)) {
  const set = SET_OF(d.name);
  opsets[set] = (opsets[set] || new OpSet(set)).ops(d);
}
const OPSET_KEYS = { core: 'core', jsValue: 'js.value', jsObject: 'js.object', jsFunction: 'js.function', jsControl: 'js.control' };
for (const [k, v] of Object.entries(OPSET_KEYS)) opsets[k] = opsets[v];

// Narrowing: a general operation becomes a cheaper one when facts about its operand
// types justify it. The variant's contract must refine the general one under those facts.
function narrowOp(name, argTypes) {
  const d = lookupOp(name);
  return d.narrow ? d.narrow(argTypes) : null;
}

function permsOf(nameOrDef, facts = {}) {
  const d = typeof nameOrDef === 'string' ? lookupOp(nameOrDef) : (nameOrDef.def || nameOrDef);
  return derivePermissions(d.behaviour, facts);
}

// ---------------------------------------------------------------- the core IR
// A function is a list of blocks. A block has parameters, operations and exactly one
// terminator. Values enter a block only as arguments on an edge, so merges and
// loop-carried values are block parameters. A block may declare where an exception
// raised by one of its operations goes: a handler block, or `unwind` to the caller.

class Lit {
  constructor(value) { this.lit = value; Object.freeze(this); }
  toString() { return litText(this.lit); }
  toJSON() { return this.lit === undefined ? { undef: true } : (typeof this.lit === 'number' && !Number.isFinite(this.lit) || Object.is(this.lit, -0)) ? { num: litText(this.lit) } : { lit: this.lit }; }
}
const lit = v => (v instanceof Lit ? v : new Lit(v));
const isLit = x => x instanceof Lit;
function litText(v) {
  if (v === undefined) return 'undefined';
  if (typeof v === 'number') return Object.is(v, -0) ? '-0' : String(v);
  if (typeof v === 'string') return JSON.stringify(v);
  return String(v);
}
const operandText = a => (isLit(a) ? a.toString() : String(a));
const operandFromJSON = a => (typeof a === 'string' ? a : a.undef ? lit(undefined) : a.num !== undefined ? lit(Number(a.num)) : lit(a.lit));

class Fn {
  constructor({ name, params = [], result = t.any, blocks = [], meta = {} }) {
    this.name = name; this.params = params; this.result = result; this.blocks = blocks; this.meta = meta;
    this.kind = 'fn';
  }
  get entry() { return this.blocks[0] ? this.blocks[0].name : null; }
  block(name) { return this.blocks.find(b => b.name === name) || null; }
  clone() { return fnFromJSON(fnToJSON(this)); }
  hash() { return hashString(stable(fnToJSON(this))); }
  values() {
    const out = this.params.map(p => p.id);
    for (const b of this.blocks) {
      for (const p of b.params) out.push(p.id);
      for (const o of b.ops) if (o.result) out.push(o.result);
    }
    return out;
  }
  edit(fn) { const copy = this.clone(); fn(editor(copy)); return copy; }
  toString() { return printFn(this); }
  yamlTag() { return `fn ${this.name} (${this.blocks.length} blocks)`; }
  toJSON() { return fnToJSON(this); }
}

class Module {
  constructor(functions = [], meta = {}) {
    this.kind = 'module'; this.functions = new Map(functions.map(f => [f.name, f])); this.meta = meta;
    // Each function knows its module, so a direct call's result can take the callee's declared type.
    for (const f of functions) Object.defineProperty(f, 'module', { value: this, configurable: true, writable: true, enumerable: false });
    this.main = meta.main || (functions[0] && functions[0].name) || null;
  }
  fn(name) { return this.functions.get(name) || null; }
  names() { return [...this.functions.keys()]; }
  clone() { return new Module([...this.functions.values()].map(f => f.clone()), { ...this.meta }); }
  hash() { return hashString(this.names().map(n => this.fn(n).hash()).join(',')); }
  toString() { return [...this.functions.values()].map(printFn).join('\n'); }
  yamlTag() { return `module (${this.functions.size} functions)`; }
}

const termEdges = term => {
  if (!term) return [];
  switch (term.kind) {
    case 'jump': return [{ ...term.to, kind: 'jump' }];
    case 'branch': return [{ ...term.t, kind: 'true' }, { ...term.f, kind: 'false' }];
    case 'invoke': return [{ ...term.normal, kind: 'normal' }, { ...term.exc, kind: 'throw' }];
    default: return [];
  }
};

function successors(fn, b) {
  const out = termEdges(b.term);
  if (b.onThrow && b.onThrow !== 'unwind') out.push({ block: b.onThrow, args: b.throwArgs || [], kind: 'handler' });
  return out;
}

function predecessors(fn) {
  const preds = new Map(fn.blocks.map(b => [b.name, []]));
  for (const b of fn.blocks) for (const e of successors(fn, b)) if (preds.has(e.block)) preds.get(e.block).push({ from: b.name, ...e });
  return preds;
}

// Every place a value is used: op operands, terminator operands, edge arguments.
function forEachUse(fn, visit) {
  for (const b of fn.blocks) {
    (b.throwArgs || []).forEach(a => { if (!isLit(a)) visit(a, { block: b, index: -1, head: true, edge: { block: b.onThrow, args: b.throwArgs, kind: 'handler' } }); });
    b.ops.forEach((o, i) => o.args.forEach((a, j) => { if (!isLit(a)) visit(a, { block: b, index: i, op: o, slot: j }); }));
    const term = b.term; if (!term) continue;
    const at = { block: b, index: b.ops.length, term: true };
    if (term.kind === 'branch' && !isLit(term.cond)) visit(term.cond, at);
    if ((term.kind === 'return' || term.kind === 'throw') && !isLit(term.value)) visit(term.value, at);
    if (term.kind === 'invoke') term.op.args.forEach(a => { if (!isLit(a)) visit(a, { ...at, op: term.op }); });
    for (const e of termEdges(term)) e.args.forEach(a => { if (!isLit(a)) visit(a, { ...at, edge: e }); });
  }
}

function usesOf(fn) {
  const uses = new Map();
  forEachUse(fn, (v, at) => { if (!uses.has(v)) uses.set(v, []); uses.get(v).push(at); });
  return uses;
}

function replaceUses(fn, from, to) {               // substitute an operand everywhere
  const sub = a => (a === from ? to : a);
  for (const b of fn.blocks) {
    if (b.throwArgs) b.throwArgs = b.throwArgs.map(sub);
    for (const o of b.ops) o.args = o.args.map(sub);
    const term = b.term; if (!term) continue;
    if (term.kind === 'branch') term.cond = sub(term.cond);
    if (term.kind === 'return' || term.kind === 'throw') term.value = sub(term.value);
    if (term.kind === 'invoke') term.op.args = term.op.args.map(sub);
    for (const key of ['to', 't', 'f', 'normal', 'exc']) if (term[key]) term[key].args = term[key].args.map(sub);
  }
}

function freshName(fn, base = 'v') {
  const taken = new Set(fn.values());
  for (const b of fn.blocks) taken.add(b.name);
  let i = 1; while (taken.has(base + i)) i++;
  return base + i;
}

// The defining site of every value: a function parameter, a block parameter, an op.
function definitions(fn) {
  const defs = new Map();
  for (const p of fn.params) defs.set(p.id, { kind: 'param', block: fn.entry, type: p.type });
  for (const b of fn.blocks) {
    for (const p of b.params) defs.set(p.id, { kind: 'block-param', block: b.name, type: p.type });
    b.ops.forEach((o, i) => { if (o.result) defs.set(o.result, { kind: 'op', block: b.name, index: i, op: o }); });
  }
  return defs;
}

// ---------------------------------------------------------------- building functions

function makeOp(name, args, attrs = {}, result = null) {
  return { op: name, args, result, attrs: { ...attrs } };
}

function fnBuilder(name, paramTypes, resultType, body) {
  const params = Object.entries(paramTypes || {}).map(([id, ty]) => ({ id, type: typeOf(ty) }));
  const fn = new Fn({ name, params, result: typeOf(resultType || t.any) });
  let counter = 0;
  const taken = new Set(params.map(p => p.id));
  const fresh = () => { let id; do { id = 'v' + (++counter); } while (taken.has(id)); taken.add(id); return id; };
  const cursorFor = block => {
    const $ = {
      op(opName, ...args) {
        let attrs = {};
        if (args.length && args[0] && typeof args[0] === 'object' && !isLit(args[0]) && !Array.isArray(args[0])) attrs = args.shift();
        const def = lookupOp(opName);
        const id = def.results.length ? fresh() : null;
        block.ops.push(makeOp(opName, args.map(asOperand), attrs, id));
        return id;
      },
      call(callee, ...args) { return $.op('core.call', { callee }, ...args); },
      closure(callee, ...caps) { return $.op('js.closure', { callee }, ...caps); },
      const: v => lit(v),
      jump(edge) { block.term = { kind: 'jump', to: edge }; },
      branch(cond, te, fe) { block.term = { kind: 'branch', cond: asOperand(cond), t: te, f: fe }; },
      ret(v = lit(undefined)) { block.term = { kind: 'return', value: asOperand(v) }; },
      throw(v) { block.term = { kind: 'throw', value: asOperand(v) }; },
      unreachable() { block.term = { kind: 'unreachable' }; },
      invoke(opName, args, { normal, throw: exc, attrs = {} }) {
        block.term = { kind: 'invoke', op: makeOp(opName, args.map(asOperand), attrs, null), normal, exc };
      },
    };
    return $;
  };
  const f = {
    params: Object.fromEntries(params.map(p => [p.id, p.id])),
    to: (blockName, ...args) => ({ block: blockName, args: args.map(asOperand) }),
    entry(cb, opts = {}) { return f.block('entry', {}, cb, opts); },
    block(bname, ps, cb, opts = {}) {
      const bparams = Object.entries(ps || {}).map(([want, ty]) => {
        // Block parameters live in one SSA namespace, so a repeated name is freshened (i, i1, i2…).
        let id = want, k = 0; while (taken.has(id)) id = want + (++k);
        taken.add(id); return { id, type: typeOf(ty), as: want };
      });
      const block = { name: bname, params: bparams, ops: [], term: null, onThrow: opts.onThrow || null, throwArgs: (opts.throwArgs || []).map(asOperand) };
      fn.blocks.push(block);
      cb(cursorFor(block), Object.fromEntries(bparams.map(p => [p.as, p.id])));
      for (const p of bparams) delete p.as;
      return bname;
    },
  };
  body(f, f.params);
  const entryIndex = fn.blocks.findIndex(b => b.name === 'entry');
  if (entryIndex > 0) fn.blocks.unshift(fn.blocks.splice(entryIndex, 1)[0]);
  return fn;
}

const asOperand = a => (isLit(a) || typeof a === 'string' ? a : lit(a));
const typeOf = ty => (ty instanceof Type ? ty : t.parse(ty));

function editor(fn) {
  return {
    fn,
    retarget(blockName, { whenTrue, whenFalse, to } = {}) {
      const b = fn.block(blockName);
      if (b.term.kind === 'branch') { if (whenTrue) b.term.t.block = whenTrue; if (whenFalse) b.term.f.block = whenFalse; }
      else if (b.term.kind === 'jump' && to) b.term.to.block = to;
    },
    removeOp(blockName, index) { fn.block(blockName).ops.splice(index, 1); },
    insertOp(blockName, index, opName, args, attrs = {}) {
      const id = lookupOp(opName).results.length ? freshName(fn) : null;
      fn.block(blockName).ops.splice(index, 0, makeOp(opName, args.map(asOperand), attrs, id));
      return id;
    },
  };
}

// ---------------------------------------------------------------- text form

function opText(o) {
  const d = opRegistry[o.op];
  const attrNames = d ? d.attrs : [];
  let head = o.op;
  const extra = Object.entries(o.attrs || {}).filter(([k]) => k !== 'callee' && attrNames.includes(k));
  if (extra.length) head += '[' + extra.map(([k, v]) => (attrNames[0] === k ? String(v) : `${k}=${v}`)).join(', ') + ']';
  const args = o.args.map(operandText);
  if (o.attrs && o.attrs.callee) args.unshift('@' + o.attrs.callee);
  return `${head}(${args.join(', ')})`;
}
const edgeText = e => `${e.block}(${e.args.map(operandText).join(', ')})`;

function termText(term) {
  if (!term) return '<no terminator>';
  switch (term.kind) {
    case 'jump': return `jump ${edgeText(term.to)}`;
    case 'branch': return `branch ${operandText(term.cond)}, ${edgeText(term.t)}, ${edgeText(term.f)}`;
    case 'return': return `return ${operandText(term.value)}`;
    case 'throw': return `throw ${operandText(term.value)}`;
    case 'unreachable': return 'unreachable';
    case 'invoke': return `invoke ${opText(term.op)} normal ${edgeText(term.normal)} throw ${edgeText(term.exc)}`;
    default: return '?';
  }
}

function blockHeader(b, isEntry) {
  const ps = b.params.length || !isEntry ? `(${b.params.map(p => `${p.id}: ${p.type}`).join(', ')})` : '';
  const args = b.throwArgs && b.throwArgs.length ? `(${b.throwArgs.map(operandText).join(', ')})` : '';
  const handler = b.onThrow ? (b.onThrow === 'unwind' ? ' throws unwind' : ` throws to ${b.onThrow}${args}`) : '';
  return `${b.name}${ps}${handler}:`;
}

function printFn(fn, { annotate } = {}) {
  const lines = [`fn ${fn.name}(${fn.params.map(p => `${p.id}: ${p.type}`).join(', ')}) -> ${fn.result} {`];
  fn.blocks.forEach((b, bi) => {
    lines.push(blockHeader(b, bi === 0));
    b.ops.forEach((o, i) => {
      let line = '  ' + (o.result ? `${o.result} = ` : '') + opText(o);
      const note = annotate && annotate(b, i, o);
      if (note) line = line.padEnd(44) + ' ; ' + note;
      lines.push(line);
    });
    let tl = '  ' + termText(b.term);
    const tnote = annotate && annotate(b, 'term', b.term);
    if (tnote) tl = tl.padEnd(44) + ' ; ' + tnote;
    lines.push(tl);
  });
  lines.push('}');
  return lines.join('\n');
}

// The parser accepts what printFn writes, plus comments after ; or //.
function tokenizeArgs(text) {
  const out = []; let cur = '', depth = 0, quote = null;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote) { cur += c; if (c === '\\') { cur += text[++i]; continue; } if (c === quote) quote = null; continue; }
    if (c === '"') { quote = c; cur += c; continue; }
    if (c === '(' || c === '[') depth++;
    if (c === ')' || c === ']') depth--;
    if (c === ',' && depth === 0) { out.push(cur.trim()); cur = ''; continue; }
    cur += c;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function parseOperand(tok, where) {
  if (/^-?\d/.test(tok) || tok === 'NaN' || tok === 'Infinity' || tok === '-Infinity' || tok === '-0') {
    const v = tok === '-0' ? -0 : Number(tok);
    if (Number.isNaN(v) && tok !== 'NaN') throw new StrataError(`bad number ${tok} ${where}`);
    return lit(v);
  }
  if (tok.startsWith('"')) return lit(JSON.parse(tok));
  if (tok === 'true' || tok === 'false') return lit(tok === 'true');
  if (tok === 'null') return lit(null);
  if (tok === 'undefined') return lit(undefined);
  if (/^[A-Za-z_$][\w$.']*$/.test(tok)) return tok;
  throw new StrataError(`cannot read operand "${tok}" ${where}`);
}

function parseOpCall(text, where) {
  const m = /^([a-z_][\w.]*)(?:\[([^\]]*)\])?\((.*)\)$/.exec(text.trim());
  if (!m) throw new StrataError(`cannot read operation "${text}" ${where}`);
  const [, name, attrText, argText] = m;
  const d = opRegistry[name];
  const attrs = {};
  if (attrText) attrText.split(',').map(s => s.trim()).filter(Boolean).forEach((part, i) => {
    const kv = part.split('=');
    if (kv.length === 2) attrs[kv[0].trim()] = kv[1].trim();
    else attrs[(d && d.attrs[i]) || 'kind'] = part;
  });
  const args = [];
  for (const tok of tokenizeArgs(argText)) {
    if (tok.startsWith('@')) attrs.callee = tok.slice(1);
    else args.push(parseOperand(tok, where));
  }
  return makeOp(name, args, attrs);
}

function parseEdge(text, where) {
  const m = /^([A-Za-z_][\w.]*)(?:\((.*)\))?$/.exec(text.trim());
  if (!m) throw new StrataError(`cannot read edge "${text}" ${where}`);
  return { block: m[1], args: m[2] ? tokenizeArgs(m[2]).map(a => parseOperand(a, where)) : [] };
}

function parseParams(text, where) {
  if (!text || !text.trim()) return [];
  return tokenizeArgs(text).map(p => {
    const [id, ty] = p.split(':').map(s => s.trim());
    return { id, type: ty ? t.parse(ty) : t.any };
  });
}

function stripComment(line) {
  let quote = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"' && line[i - 1] !== '\\') quote = !quote;
    if (!quote && (c === ';' || (c === '/' && line[i + 1] === '/'))) return line.slice(0, i);
  }
  return line;
}

function parseIR(text) {
  const fns = []; let fn = null, block = null;
  const lines = text.split('\n');
  lines.forEach((raw, n) => {
    const where = `(line ${n + 1})`;
    const line = stripComment(raw).trim();
    if (!line) return;
    let m;
    if ((m = /^fn\s+([A-Za-z_$][\w$.]*)\s*\((.*)\)\s*(?:->\s*([\w|]+))?\s*\{$/.exec(line))) {
      fn = new Fn({ name: m[1], params: parseParams(m[2], where), result: m[3] ? t.parse(m[3]) : t.any });
      fns.push(fn); block = null; return;
    }
    if (line === '}') { fn = null; block = null; return; }
    if (!fn) throw new StrataError(`text outside a function ${where}`);
    if ((m = /^([A-Za-z_][\w.]*)(?:\(([^)]*)\))?(?:\s+throws\s+(?:to\s+)?([\w.]+)(?:\((.*)\))?)?:$/.exec(line))) {
      block = { name: m[1], params: parseParams(m[2], where), ops: [], term: null, onThrow: m[3] || null, throwArgs: m[4] ? tokenizeArgs(m[4]).map(a => parseOperand(a, where)) : [], line: n + 1 };
      fn.blocks.push(block); return;
    }
    if (!block) throw new StrataError(`operation before any block ${where}`);
    if (block.term) throw new StrataError(`block ${block.name} continues after its terminator ${where}`, { rule: 'terminator' });
    if ((m = /^jump\s+(.*)$/.exec(line))) { block.term = { kind: 'jump', to: parseEdge(m[1], where) }; return; }
    if ((m = /^branch\s+(.*)$/.exec(line))) {
      const parts = tokenizeArgs(m[1]);
      if (parts.length !== 3) throw new StrataError(`branch needs a condition and two edges ${where}`);
      block.term = { kind: 'branch', cond: parseOperand(parts[0], where), t: parseEdge(parts[1], where), f: parseEdge(parts[2], where) }; return;
    }
    if ((m = /^return(?:\s+(.*))?$/.exec(line))) { block.term = { kind: 'return', value: m[1] ? parseOperand(m[1].trim(), where) : lit(undefined) }; return; }
    if ((m = /^throw\s+(.*)$/.exec(line))) { block.term = { kind: 'throw', value: parseOperand(m[1].trim(), where) }; return; }
    if (line === 'unreachable') { block.term = { kind: 'unreachable' }; return; }
    if ((m = /^invoke\s+(.*\))\s+normal\s+(\S+(?:\(.*?\))?)\s+throw\s+(\S+(?:\(.*\))?)$/.exec(line))) {
      block.term = { kind: 'invoke', op: parseOpCall(m[1], where), normal: parseEdge(m[2], where), exc: parseEdge(m[3], where) }; return;
    }
    if ((m = /^(?:([A-Za-z_$][\w$.']*)\s*=\s*)?(.+)$/.exec(line))) {
      const o = parseOpCall(m[2], where); o.result = m[1] || null; o.line = n + 1;
      block.ops.push(o); return;
    }
    throw new StrataError(`cannot read "${line}" ${where}`);
  });
  return fns.length === 1 ? fns[0] : new Module(fns);
}

// ---------------------------------------------------------------- JSON form

function fnToJSON(fn) {
  const edge = e => ({ block: e.block, args: e.args.map(a => (isLit(a) ? a.toJSON() : a)) });
  const opJ = o => ({ op: o.op, args: o.args.map(a => (isLit(a) ? a.toJSON() : a)), result: o.result, attrs: o.attrs });
  return {
    name: fn.name, params: fn.params.map(p => ({ id: p.id, type: String(p.type) })), result: String(fn.result), meta: fn.meta,
    blocks: fn.blocks.map(b => {
      const term = b.term && { ...b.term };
      if (term) {
        for (const k of ['to', 't', 'f', 'normal', 'exc']) if (term[k]) term[k] = edge(term[k]);
        if (term.cond !== undefined) term.cond = isLit(term.cond) ? term.cond.toJSON() : term.cond;
        if (term.value !== undefined) term.value = isLit(term.value) ? term.value.toJSON() : term.value;
        if (term.op) term.op = opJ(term.op);
      }
      return { name: b.name, params: b.params.map(p => ({ id: p.id, type: String(p.type) })), onThrow: b.onThrow, throwArgs: (b.throwArgs || []).map(a => (isLit(a) ? a.toJSON() : a)), ops: b.ops.map(opJ), term };
    }),
  };
}

function fnFromJSON(j) {
  const edge = e => ({ block: e.block, args: e.args.map(operandFromJSON) });
  const opF = o => ({ op: o.op, args: o.args.map(operandFromJSON), result: o.result, attrs: { ...(o.attrs || {}) } });
  return new Fn({
    name: j.name, params: j.params.map(p => ({ id: p.id, type: t.parse(p.type) })), result: t.parse(j.result), meta: { ...(j.meta || {}) },
    blocks: j.blocks.map(b => {
      const term = b.term && { ...b.term };
      if (term) {
        for (const k of ['to', 't', 'f', 'normal', 'exc']) if (term[k]) term[k] = edge(term[k]);
        if (term.cond !== undefined) term.cond = operandFromJSON(term.cond);
        if (term.value !== undefined) term.value = operandFromJSON(term.value);
        if (term.op) term.op = opF(term.op);
      }
      return { name: b.name, params: b.params.map(p => ({ id: p.id, type: t.parse(p.type) })), onThrow: b.onThrow || null, throwArgs: (b.throwArgs || []).map(operandFromJSON), ops: b.ops.map(opF), term };
    }),
  });
}

// ---------------------------------------------------------------- dominators
// Cooper, Harvey and Kennedy's iterative algorithm over the reverse postorder. A block
// with a handler is split in two nodes: its head (parameters) and its body (operations),
// and the exceptional edge leaves from the head, because a throw can happen before any
// of the block's operations has defined its value.

function dominators(fn) {
  const nodes = [], succ = new Map();
  const add = (n) => { if (!succ.has(n)) { succ.set(n, []); nodes.push(n); } };
  for (const b of fn.blocks) { add(b.name); add(b.name + '#body'); }
  for (const b of fn.blocks) {
    succ.get(b.name).push(b.name + '#body');
    for (const e of termEdges(b.term)) if (fn.block(e.block)) succ.get(b.name + '#body').push(e.block);
    if (b.onThrow && b.onThrow !== 'unwind' && fn.block(b.onThrow)) succ.get(b.name).push(b.onThrow);
  }
  const order = [], seen = new Set();
  const visit = n => { seen.add(n); for (const s of succ.get(n)) if (!seen.has(s)) visit(s); order.push(n); };
  if (fn.entry) visit(fn.entry);
  const rpo = order.reverse(), index = new Map(rpo.map((n, i) => [n, i]));
  const preds = new Map(rpo.map(n => [n, []]));
  for (const n of rpo) for (const s of succ.get(n)) if (preds.has(s)) preds.get(s).push(n);
  const idom = new Map([[fn.entry, fn.entry]]);
  const intersect = (a, b) => {
    while (a !== b) {
      while (index.get(a) > index.get(b)) a = idom.get(a);
      while (index.get(b) > index.get(a)) b = idom.get(b);
    }
    return a;
  };
  let changed = true, rounds = 0;
  while (changed) {
    changed = false; rounds++;
    for (const n of rpo.slice(1)) {
      const ps = preds.get(n).filter(p => idom.has(p));
      if (!ps.length) continue;
      let d = ps[0];
      for (const p of ps.slice(1)) d = intersect(p, d);
      if (idom.get(n) !== d) { idom.set(n, d); changed = true; }
    }
  }
  const reachable = new Set(rpo);
  const dominates = (a, b) => {                   // node a dominates node b
    if (!reachable.has(b)) return true;
    let x = b;
    while (true) { if (x === a) return true; const up = idom.get(x); if (up === x || up === undefined) return x === a; x = up; }
  };
  const blockIdom = {};
  for (const b of fn.blocks) {
    if (!reachable.has(b.name) || b.name === fn.entry) continue;
    const up = idom.get(b.name);
    blockIdom[b.name] = up ? up.replace('#body', '') : null;
  }
  return { idom: blockIdom, dominates, reachable: new Set(fn.blocks.filter(b => reachable.has(b.name)).map(b => b.name)), rounds, nodeIdom: idom };
}

// ---------------------------------------------------------------- the verifier
// Five rules, each reported as data naming the rule and the place.

function staticType(fn, defs, a) {
  if (isLit(a)) return t.ofValue(a.lit);
  const d = defs.get(a);
  if (!d) return t.top;
  if (d.kind !== 'op') return d.type;
  const def = opRegistry[d.op.op];
  return def ? def.typeOf(d.op.args.map(x => staticType(fn, defs, x)), d.op, fn) : t.top;
}

function verify(target, opts = {}) {
  const fns = target instanceof Module ? [...target.functions.values()] : [target];
  const diags = [];
  for (const fn of fns) verifyFn(fn, diags, target instanceof Module ? target : null, opts);
  return { ok: !diags.some(d => d.severity === 'error'), diagnostics: diags };
}

function verifyFn(fn, diags, module, opts) {
  const err = (rule, message, at = {}, severity = 'error') => diags.push({ severity, kind: 'verify', rule, message, at: { fn: fn.name, ...at } });
  if (!fn.blocks.length) { err('entry', `${fn.name} has no blocks`); return; }
  const names = new Set();
  for (const b of fn.blocks) {
    if (names.has(b.name)) err('block-name', `block ${b.name} is defined twice`, { block: b.name });
    names.add(b.name);
  }
  // Rule 1: one definition per value.
  const seen = new Map();
  const define = (id, where) => {
    if (seen.has(id)) err('single-definition', `${id} is defined twice (${seen.get(id)} and ${where})`, { value: id });
    seen.set(id, where);
  };
  fn.params.forEach(p => define(p.id, 'parameter'));
  for (const b of fn.blocks) {
    b.params.forEach(p => define(p.id, `${b.name} parameter`));
    b.ops.forEach((o, i) => { if (o.result) define(o.result, `${b.name}/${i}`); });
  }
  const defs = definitions(fn);
  const dom = dominators(fn);
  for (const b of fn.blocks) {
    // Rule 5: exactly one terminator; known targets.
    if (!b.term) err('terminator', `block ${b.name} has no terminator`, { block: b.name });
    for (const e of termEdges(b.term)) if (!fn.block(e.block)) err('unknown-block', `${b.name} jumps to unknown block ${e.block}`, { block: b.name });
    if (b.onThrow && b.onThrow !== 'unwind' && !fn.block(b.onThrow)) err('unknown-block', `${b.name} throws to unknown block ${b.onThrow}`, { block: b.name });
    // Operations: known, right arity; Rule 3: may-throw needs an exit.
    const checkOp = (o, at, inInvoke) => {
      const d = opRegistry[o.op];
      if (!d) { err('unknown-op', `unknown operation ${o.op}`, at); return; }
      if (!d.variadic && o.args.length !== d.operands.length) err('arity', `${o.op} takes ${d.operands.length} operands, got ${o.args.length}`, at);
      if (d.mayThrow && !inInvoke && !b.onThrow) err('may-throw-without-exit', `${o.op} may throw but ${b.name} has no exceptional exit; use invoke or declare "throws to <block>" or "throws unwind"`, at);
      if ((o.op === 'js.closure' || o.op === 'core.call') && module && !module.fn(o.attrs.callee)) err('unknown-callee', `${o.op} names @${o.attrs.callee}, which is not in the module`, at);
    };
    b.ops.forEach((o, i) => checkOp(o, { block: b.name, op: `${fn.name}/${b.name}/${i}` }, false));
    if (b.term && b.term.kind === 'invoke') checkOp(b.term.op, { block: b.name, op: `${fn.name}/${b.name}/term` }, true);
    // Rule 2: edge arity and types (the implicit first argument of invoke and handler edges).
    for (const e of successors(fn, b)) {
      const target = fn.block(e.block); if (!target) continue;
      let implicit = 0;
      if (e.kind === 'throw' || e.kind === 'handler') implicit = 1;
      if (e.kind === 'normal') implicit = (opRegistry[b.term.op.op] && opRegistry[b.term.op.op].results.length) ? 1 : 0;
      const expected = target.params.length - implicit;
      if (e.args.length !== expected) {
        err('edge-arity', `edge ${b.name}→${e.block} passes ${e.args.length} argument${e.args.length === 1 ? '' : 's'}; ${e.block} expects ${Math.max(expected, 0)}${implicit ? ` after the implicit ${e.kind === 'normal' ? 'result' : 'thrown value'}` : ''}`, { block: b.name, edge: `${b.name}→${e.block}` });
        continue;
      }
      e.args.forEach((a, k) => {
        const p = target.params[k + implicit];
        const at = staticType(fn, defs, a);
        if (!at.le(p.type)) err('edge-type', `edge ${b.name}→${e.block} passes ${operandText(a)}: ${at} to ${p.id}: ${p.type}`, { block: b.name, edge: `${b.name}→${e.block}` });
      });
    }
  }
  // Rule 2 continued: every use is dominated by its definition.
  forEachUse(fn, (v, at) => {
    const d = defs.get(v);
    const where = { block: at.block.name, op: `${fn.name}/${at.block.name}/${at.term ? 'term' : at.index}` };
    if (!d) { err('undefined-value', `${v} is used in ${at.block.name} but never defined`, where); return; }
    if (d.kind === 'param') return;
    const useNode = at.head ? at.block.name : at.block.name + '#body';
    if (d.kind === 'block-param') {
      if (!dom.dominates(d.block, useNode)) err('dominance', `${v} (a parameter of ${d.block}) does not dominate its use in ${at.block.name}`, where);
      return;
    }
    if (d.block === at.block.name) {
      if (at.head || d.index >= at.index) err('dominance', `${v} is used in ${at.block.name} before it is defined`, where);
      return;
    }
    if (!dom.dominates(d.block + '#body', useNode)) {
      const path = counterPath(fn, d.block, at.block.name);
      err('dominance', `${v} is defined in ${d.block} but used in ${at.block.name}, which ${d.block} does not dominate${path ? ` (path ${path.join(' → ')})` : ''}`, where);
    }
  });
  // Unreachable blocks are reported, not silently dropped.
  for (const b of fn.blocks) if (!dom.reachable.has(b.name)) err('unreachable', `block ${b.name} is unreachable`, { block: b.name }, 'warning');
  if (opts.facts && opts.facts.stale) for (const s of opts.facts.stale) err('stale-fact', s.message, s.at || {});
}

function counterPath(fn, avoid, to) {                // a path from entry to `to` that skips `avoid`
  const prev = new Map([[fn.entry, null]]), queue = [fn.entry];
  if (fn.entry === avoid) return null;
  while (queue.length) {
    const n = queue.shift();
    if (n === to) { const path = []; for (let x = n; x; x = prev.get(x)) path.unshift(x); return path; }
    for (const e of successors(fn, fn.block(n))) if (e.block !== avoid && !prev.has(e.block) && fn.block(e.block)) { prev.set(e.block, n); queue.push(e.block); }
  }
  return null;
}

// ---------------------------------------------------------------- the machine
// One interpreter serves two purposes. With mode 'spec' it is the reference semantics
// of the core IR: it never collects and nothing moves. With mode 'plan' it runs the
// same program under an execution plan: at collecting operations a moving collector
// copies every reachable object to a new address and updates only what the plan rooted.
// A value the plan forgot still holds the old address, and its next use is reported as
// a stale reference: the bug a real backend must never have.

class Ref {
  constructor(addr, kind, oid) { this.addr = addr; this.kind = kind; this.oid = oid; this.isRef = true; Object.freeze(this); }
  get kindType() { return this.kind === 'function' ? t.function : this.kind === 'cell' ? t.cell : this.kind === 'completion' ? t.completion : t.object; }
  toString() { return `#${this.oid}`; }
  toJSON() { return { ref: this.oid, kind: this.kind }; }
  yamlTag() { return `${this.kind} #${this.oid}`; }
}

class JSThrow { constructor(value) { this.value = value; } }
class Diverge { constructor(steps) { this.steps = steps; } }
class StaleUse extends Error {
  constructor(detail) {
    const where = String(detail.collectedAt || '?'), freed = where.endsWith(' (freed)'), site = where.replace(' (freed)', '');
    super(`stale reference: ${detail.value} (object #${detail.oid}) was not rooted, so the collection at ${site} ${freed ? 'freed it' : 'moved it'}; it was then used at ${detail.at}`);
    this.detail = detail;
  }
}

const HOLE = Symbol('uninitialized');

class Machine {
  constructor(module, opts = {}) {
    this.module = module;
    this.mode = opts.mode || 'spec';
    this.plans = opts.plans || {};
    this.gc = this.mode === 'plan' ? (opts.gc || 'off') : 'off';
    this.budget = opts.budget || 200000;
    this.recordLimit = opts.recordLimit === undefined ? 4000 : opts.recordLimit;
    this.maxDepth = opts.maxDepth || 300;
    this.heap = new Map(); this.nextAddr = 1; this.nextOid = 1; this.sinceGC = 0;
    this.forwardTo = new Map(); this.execDepth = 0; this.hostRoots = [];
    this.output = []; this.trace = []; this.events = []; this.records = [];
    this.microtasks = []; this.timers = []; this.vtime = 0; this.timerSeq = 0;
    this.frames = []; this.steps = 0; this.lastCollection = null; this.movedAt = new Map();
    this.metrics = { steps: 0, calls: 0, allocations: 0, collections: 0, moved: 0, peakRootSlots: 0, rootBytes: 0, jobs: 0, maxDepth: 0 };
    this.HOLE = HOLE;
    this.globals = new Map();
    this.installBuiltins();
  }

  // ---- heap
  alloc(kind, fields = {}) {
    const addr = this.nextAddr++, oid = this.nextOid++;
    this.heap.set(addr, { kind, oid, props: new Map(), ...fields });
    this.metrics.allocations++; this.sinceGC++;
    return new Ref(addr, kind, oid);
  }
  deref(v, what = 'value') {
    let o = this.heap.get(v.addr);
    // A helper holds its operands through handles, as a real runtime does: an object the
    // collector moved during the helper's own execution is found at its new address. An
    // object that nothing rooted was freed, and reading it is a stale use.
    for (let a = v.addr; !o && this.forwardTo.has(a);) { a = this.forwardTo.get(a); o = this.heap.get(a); }
    if (!o) throw new StaleUse({ value: what, oid: v.oid, collectedAt: this.movedAt.get(v.addr) || '?', at: this.here() });
    return o;
  }
  here() { const f = this.frames[this.frames.length - 1]; return f ? f.at : 'top level'; }

  // ---- the semantic helpers the operations' steps call
  sameRef(a, b) { return this.strictEquals(a, b); }
  strictEquals(a, b) {
    if (a && a.isRef && b && b.isRef) { this.deref(a); this.deref(b); return a.oid === b.oid; }   // identity survives moves
    if ((a && a.isRef) || (b && b.isRef)) return false;
    return a === b;
  }
  truthy(v) { return v && v.isRef ? true : !!v; }
  typeOf(v) {
    if (v === null) return 'object';
    if (v && v.isRef) return this.deref(v).kind === 'function' ? 'function' : 'object';
    return typeof v;
  }
  toPrimitive(v, hint = 'default') {
    if (!(v && v.isRef)) return v;
    const o = this.deref(v);
    for (const name of hint === 'string' ? ['toString', 'valueOf'] : ['valueOf', 'toString']) {
      const m = this.lookup(o, name, v);
      if (m && m.isRef && this.deref(m).kind === 'function') {
        const r = this.callValue(m, v, []);
        if (!(r && r.isRef)) return r;
      }
    }
    if (o.kind === 'array') return o.elems.map(e => (e === undefined || e === null ? '' : this.toString(e))).join(',');
    if (o.kind === 'function') return 'function';
    if (o.kind === 'error') return `${this.toString(this.getProperty(v, 'name'))}: ${this.toString(this.getProperty(v, 'message'))}`;
    if (o.kind === 'promise') return '[object Promise]';
    return '[object Object]';
  }
  toNumber(v) {
    if (v && v.isRef) return this.toNumber(this.toPrimitive(v, 'number'));
    if (v === undefined) return NaN;
    if (v === null) return 0;
    if (typeof v === 'boolean') return v ? 1 : 0;
    if (typeof v === 'string') return Number(v);
    return v;
  }
  toString(v) {
    if (v && v.isRef) return this.toString(this.toPrimitive(v, 'string'));
    if (typeof v === 'number' && Object.is(v, -0)) return '0';
    return String(v);
  }
  add(a, b) {
    const pa = this.toPrimitive(a), pb = this.toPrimitive(b);
    if (typeof pa === 'string' || typeof pb === 'string') return this.toString(pa) + this.toString(pb);
    return this.toNumber(pa) + this.toNumber(pb);
  }
  compare(a, b, f) {
    const pa = this.toPrimitive(a, 'number'), pb = this.toPrimitive(b, 'number');
    if (typeof pa === 'string' && typeof pb === 'string') return f(pa, pb);
    return f(this.toNumber(pa), this.toNumber(pb));
  }
  key(k) { return typeof k === 'number' ? (Object.is(k, -0) ? '0' : String(k)) : this.toString(k); }
  lookup(o, k, self) {                            // own properties only; no prototype chain in this subset
    if (o.kind === 'array') {
      if (k === 'length') return o.elems.length;
      if (/^\d+$/.test(k)) return o.elems[Number(k)];
    }
    if (o.kind === 'promise' && k === 'then') return this.builtin('then');
    const slot = o.props.get(k);
    if (!slot) return undefined;
    if ('value' in slot) return slot.value;
    return slot.get ? this.callValue(slot.get, self, []) : undefined;
  }
  getProperty(v, k) {
    if (v === undefined || v === null) this.throwError('TypeError', `cannot read property ${this.key(k)} of ${v}`);
    if (typeof v === 'string') {
      const key = this.key(k);
      if (key === 'length') return v.length;
      return /^\d+$/.test(key) ? v[Number(key)] : undefined;
    }
    if (!(v && v.isRef)) return undefined;
    return this.lookup(this.deref(v), this.key(k), v);
  }
  getOwnData(v, k) { const s = this.deref(v).props.get(this.key(k)); return s && 'value' in s ? s.value : undefined; }
  setProperty(v, k, value) {
    if (!(v && v.isRef)) this.throwError('TypeError', `cannot set property ${this.key(k)} of ${v === undefined || v === null ? v : typeof v}`);
    const o = this.deref(v), key = this.key(k);
    if (o.kind === 'array' && (key === 'length' || /^\d+$/.test(key))) {
      if (key === 'length') o.elems.length = this.toNumber(value); else o.elems[Number(key)] = value;
      return;
    }
    const slot = o.props.get(key);
    if (slot && !('value' in slot)) {
      if (!slot.set) this.throwError('TypeError', `cannot set ${key}: it has a getter and no setter`);
      this.callValue(slot.set, v, [value]); return;
    }
    o.props.set(key, { value });
  }
  define(v, k, value) { this.deref(v).props.set(this.key(k), { value }); }
  defineAccessor(v, k, f, which) {
    const o = this.deref(v), key = this.key(k);
    const slot = o.props.get(key);
    const acc = slot && !('value' in slot) ? slot : {};
    acc[which] = f; o.props.set(key, acc);
  }
  newObject() { return this.alloc('object'); }
  newArray(elems) { return this.alloc('array', { elems: elems.slice() }); }
  newClosure(callee, caps) {
    if (!this.module.fn(callee)) this.throwError('TypeError', `no function @${callee}`);
    return this.alloc('function', { fn: callee, caps: caps.slice() });
  }
  newCell(v) { return this.alloc('cell', { value: v }); }
  cellLoad(c, checked, name) {
    const v = this.deref(c, 'cell').value;
    if (v === HOLE) {
      if (checked) this.throwError('ReferenceError', `cannot access ${name || 'a variable'} before initialization`);
      return undefined;
    }
    return v;
  }
  cellStore(c, v) { this.deref(c, 'cell').value = v; }
  globalGet(name) {
    if (!this.globals.has(name)) this.throwError('ReferenceError', `${name} is not defined`);
    return this.globals.get(name);
  }
  globalPut(name, v) { this.globals.set(name, v); }
  newError(kind, message) {
    const e = this.alloc('error');
    const o = this.heap.get(e.addr);
    o.props.set('name', { value: kind }); o.props.set('message', { value: message === undefined ? '' : this.toString(message) });
    return e;
  }
  throwError(kind, message) {
    const e = this.alloc('error');
    const o = this.heap.get(e.addr);
    o.props.set('name', { value: kind }); o.props.set('message', { value: message });
    throw new JSThrow(e);
  }
  display(v) {
    if (v && v.isRef) {
      const o = this.heap.get(v.addr);
      if (!o) return '<stale>';
      if (o.kind === 'array') return o.elems.map(e => (e === undefined || e === null ? '' : this.display(e))).join(',');
      if (o.kind === 'function') return 'function';
      if (o.kind === 'error') return `${this.display(o.props.get('name').value)}: ${this.display(o.props.get('message').value)}`;
      if (o.kind === 'promise') return '[object Promise]';
      if (o.kind === 'cell') return '<cell>';
      return '[object Object]';
    }
    if (typeof v === 'number' && Object.is(v, -0)) return '0';
    return String(v);
  }
  // A debugger's view of a value, for the step records: identity and a few fields.
  inspect(v, depth = 0) {
    if (v === HOLE) return '<uninitialized>';
    if (typeof v === 'string') return JSON.stringify(v.length > 40 ? v.slice(0, 40) + '…' : v);
    if (!(v && v.isRef)) return typeof v === 'number' && Object.is(v, -0) ? '-0' : String(v);
    let o = this.heap.get(v.addr);
    for (let a = v.addr; !o && this.forwardTo.has(a);) { a = this.forwardTo.get(a); o = this.heap.get(a); }
    if (!o) return `#${v.oid} <stale>`;
    const inner = x => (depth > 0 ? (x && x.isRef ? `#${x.oid}` : this.inspect(x, depth + 1)) : this.inspect(x, depth + 1));
    switch (o.kind) {
      case 'function': return `#${v.oid} fn ${o.native ? o.name + ' (builtin)' : '@' + o.fn}`;
      case 'cell': return `#${v.oid} cell = ${o.value === HOLE ? '<uninitialized>' : inner(o.value)}`;
      case 'completion': return `#${v.oid} completion(${o.ckind}${o.value !== undefined ? ', ' + inner(o.value) : ''})`;
      case 'promise': return `#${v.oid} promise ${o.state}${o.state !== 'pending' ? ' ' + inner(o.value) : ''}`;
      case 'array': return `#${v.oid} [${o.elems.slice(0, 4).map(inner).join(', ')}${o.elems.length > 4 ? ', …' : ''}]`;
      case 'error': return `#${v.oid} ${this.display(v)}`;
      default: {
        const ks = [...o.props.keys()];
        const shown = ks.slice(0, 3).map(k => { const sl = o.props.get(k); return 'value' in sl ? `${k}: ${inner(sl.value)}` : `${k}: <accessor>`; });
        return `#${v.oid} {${shown.join(', ')}${ks.length > 3 ? ', …' : ''}}`;
      }
    }
  }
  print(args) {
    const line = args.map(a => this.display(a)).join(' ');
    this.output.push(line);
    this.trace.push({ type: 'print', values: args.map(a => (a && a.isRef ? { ref: a.oid } : a)) });
    this.event('print', { line });
  }
  enqueue(f, args = []) { this.microtasks.push({ f, args }); this.event('job', { what: 'enqueue', queue: this.microtasks.length }); }
  setTimer(f, delay) { this.timers.push({ at: this.vtime + Math.max(0, this.toNumber(delay) || 0), seq: this.timerSeq++, f }); this.event('timer', { what: 'set', at: this.vtime + delay }); }
  promiseResolve(v) {
    if (v && v.isRef && this.deref(v).kind === 'promise') return v;
    return this.alloc('promise', { state: 'fulfilled', value: v, reactions: [] });
  }
  promiseThen(p, onFulfilled) {
    const q = this.alloc('promise', { state: 'pending', value: undefined, reactions: [] });
    const po = this.deref(p);
    const reaction = { handler: onFulfilled, target: q };
    if (po.state === 'fulfilled') this.enqueue(this.builtin('react'), [reaction, po.value]);
    else po.reactions.push(reaction);
    return q;
  }
  fulfil(q, value) {
    const qo = this.deref(q);
    if (qo.state !== 'pending') return;
    if (value && value.isRef && this.deref(value).kind === 'promise') { this.promiseThen(value, this.builtin('adopt', q)); return; }
    qo.state = 'fulfilled'; qo.value = value;
    for (const r of qo.reactions) this.enqueue(this.builtin('react'), [r, value]);
    qo.reactions = [];
  }
  completion(kind, value) { return this.alloc('completion', { ckind: kind, value }); }
  completionIs(c, kind) { return this.deref(c, 'completion').ckind === kind; }
  completionValue(c) { return this.deref(c, 'completion').value; }

  // ---- builtins are native function objects
  installBuiltins() {
    const native = (name, impl) => { const r = this.alloc('function', { native: impl, name }); return r; };
    this.natives = {
      print: native('print', (self, args) => { this.print(args); return undefined; }),
      queueMicrotask: native('queueMicrotask', (self, [f]) => { this.enqueue(f, []); return undefined; }),
      setTimeout: native('setTimeout', (self, [f, d]) => { this.setTimer(f, d || 0); return undefined; }),
      then: native('then', (self, [f]) => this.promiseThen(self, f)),
      react: native('react', (self, [reaction, value]) => {
        let result = value;
        if (reaction.handler && reaction.handler.isRef && this.deref(reaction.handler).kind === 'function') {
          try { result = this.callValue(reaction.handler, undefined, [value]); }
          catch (e) { if (e instanceof JSThrow) { const q = this.deref(reaction.target); q.state = 'rejected'; q.value = e.value; this.event('error', { what: 'unhandled rejection', value: this.display(e.value) }); return undefined; } throw e; }
        }
        this.fulfil(reaction.target, result); return undefined;
      }),
    };
    const promise = this.alloc('object');
    this.heap.get(promise.addr).props.set('resolve', { value: native('resolve', (self, [v]) => this.promiseResolve(v)) });
    for (const [k, v] of Object.entries(this.natives)) if (!['then', 'react'].includes(k)) this.globals.set(k, v);
    this.globals.set('Promise', promise);
  }
  builtin(name, bound) {
    if (name === 'adopt') return this.alloc('function', { native: (self, [v]) => { this.fulfil(bound, v); return undefined; }, name: 'adopt' });
    return this.natives[name];
  }

  // ---- calls
  callValue(f, self, args) {
    if (!(f && f.isRef) || this.deref(f).kind !== 'function') this.throwError('TypeError', `${this.display(f)} is not a function`);
    const o = this.deref(f);
    this.metrics.calls++;
    if (o.native) return o.native(self, args);
    const fn = this.module.fn(o.fn);
    return this.callFn(fn, [...o.caps, self, ...args]);
  }
  callMethod(o, key, args) { return this.callValue(this.getProperty(o, key), o, args); }
  callDirect(callee, args) { const fn = this.module.fn(callee); if (!fn) this.throwError('TypeError', `no function @${callee}`); this.metrics.calls++; return this.callFn(fn, args); }

  event(type, data = {}) { if (this.events.length < 2000) this.events.push({ n: this.steps, type, ...data }); }
  tick(fn, block, op, text, value) {
    this.steps++;
    if (this.steps > this.budget) throw new Diverge(this.steps);
    if (this.records.length < this.recordLimit) this.records.push({ n: this.steps, fn: fn.name, block: block.name, op, text, value: value === undefined ? undefined : this.inspect(value), depth: this.frames.length });
  }

  value(a, frame) {
    if (isLit(a)) return a.lit;
    if (!frame.env.has(a)) throw new StrataError(`${a} has no value in ${frame.fn.name} (at ${frame.at})`);
    const v = frame.env.get(a);
    if (this.mode === 'plan' && v && v.isRef && !this.heap.has(v.addr)) {
      const detail = { value: a, oid: v.oid, collectedAt: this.movedAt.get(v.addr) || '?', at: frame.at };
      this.event('stale', detail);
      throw new StaleUse(detail);
    }
    return v;
  }

  exec(o, frame) {
    const d = lookupOp(o.op);
    if (this.execDepth === 0) this.forwardTo.clear();   // handles live only while a helper runs
    if (this.mode === 'plan' && d.mayCollect) this.maybeCollect();
    const args = o.args.map(a => this.value(a, frame));
    this.execDepth++;
    try { return d.step(this, args, o); } finally { this.execDepth--; }
  }

  callFn(fn, args) {
    if (this.frames.length >= this.maxDepth) this.throwError('RangeError', 'maximum call stack size exceeded');
    const frame = { fn, env: new Map(), at: `${fn.name}/${fn.entry}/0`, plan: this.plans[fn.name] };
    fn.params.forEach((p, i) => frame.env.set(p.id, args[i]));
    this.frames.push(frame);
    this.metrics.maxDepth = Math.max(this.metrics.maxDepth, this.frames.length);
    if (this.mode === 'plan') {
      const total = this.frames.reduce((n, f) => n + (f.plan ? f.plan.frameSlots : 0), 0);
      if (total > this.metrics.peakRootSlots) { this.metrics.peakRootSlots = total; this.metrics.rootBytes = total * 8; }
    }
    try {
      let block = fn.blocks[0], incoming = [];
      for (;;) {
        block.params.forEach((p, i) => frame.env.set(p.id, incoming[i]));
        let next = null;
        for (let i = 0; i < block.ops.length && !next; i++) {
          const o = block.ops[i];
          frame.at = `${fn.name}/${block.name}/${i}`;
          let v;
          try { v = this.exec(o, frame); }
          catch (e) {
            if (!(e instanceof JSThrow) || !block.onThrow || block.onThrow === 'unwind') throw e;
            this.event('catch', { at: frame.at, handler: block.onThrow, value: this.display(e.value) });
            next = { block: fn.block(block.onThrow), incoming: [e.value, ...(block.throwArgs || []).map(x => this.value(x, frame))] };
            break;
          }
          if (o.result) frame.env.set(o.result, v);
          this.tick(fn, block, i, opText(o), v);
        }
        if (next) { block = next.block; incoming = next.incoming; continue; }
        const term = block.term;
        frame.at = `${fn.name}/${block.name}/term`;
        const edgeArgs = e => e.args.map(a => this.value(a, frame));
        switch (term.kind) {
          case 'jump': this.tick(fn, block, 'term', termText(term)); incoming = edgeArgs(term.to); block = fn.block(term.to.block); break;
          case 'branch': {
            const c = this.value(term.cond, frame);
            this.tick(fn, block, 'term', termText(term), c);
            const e = this.truthy(c) ? term.t : term.f;
            incoming = edgeArgs(e); block = fn.block(e.block); break;
          }
          case 'return': { const v = this.value(term.value, frame); this.tick(fn, block, 'term', termText(term), v); return v; }
          case 'throw': {
            const v = this.value(term.value, frame);
            this.tick(fn, block, 'term', termText(term), v);
            this.event('throw', { at: frame.at, value: this.display(v) });
            if (block.onThrow && block.onThrow !== 'unwind') {   // a throw in a protected block goes to its handler
              this.event('catch', { at: frame.at, handler: block.onThrow, value: this.display(v) });
              incoming = [v, ...(block.throwArgs || []).map(x => this.value(x, frame))]; block = fn.block(block.onThrow); break;
            }
            throw new JSThrow(v);
          }
          case 'unreachable': throw new StrataError(`reached unreachable in ${fn.name}/${block.name}`);
          case 'invoke': {
            const d = lookupOp(term.op.op);
            let v;
            try { v = this.exec(term.op, frame); }
            catch (e) {
              if (!(e instanceof JSThrow)) throw e;
              this.tick(fn, block, 'term', termText(term), e.value);
              this.event('catch', { at: frame.at, handler: term.exc.block, value: this.display(e.value) });
              incoming = [e.value, ...edgeArgs(term.exc)]; block = fn.block(term.exc.block); break;
            }
            this.tick(fn, block, 'term', termText(term), v);
            incoming = [...(d.results.length ? [v] : []), ...edgeArgs(term.normal)]; block = fn.block(term.normal.block); break;
          }
          default: throw new StrataError(`unknown terminator ${term.kind}`);
        }
      }
    } finally {
      this.frames.pop();
    }
  }

  // ---- the simulated moving collector (plan mode only)
  maybeCollect() {
    if (this.gc === 'stress' || (this.gc === 'alloc' && this.sinceGC >= 16)) this.collect();
  }
  rootsOfFrame(frame) {                           // what the plan says is rooted here
    const plan = frame.plan;
    if (!plan) return [];
    const sp = plan.safepoints[frame.at];
    return sp ? sp.rooted : [];
  }
  collect() {
    const at = this.here();
    const forward = new Map(), next = new Map();
    let addr = this.nextAddr;
    const move = v => {
      if (!(v && v.isRef)) return v;
      if (forward.has(v.addr)) return forward.get(v.addr);
      const o = this.heap.get(v.addr);
      if (!o) return v;                             // already stale: stays stale
      const nv = new Ref(addr++, v.kind, v.oid);
      forward.set(v.addr, nv); next.set(nv.addr, o); queue.push(o);
      return nv;
    };
    const queue = [];
    // Roots: the slots of every frame, the globals, the job and timer queues, the builtins.
    const slotUpdates = [];
    for (const frame of this.frames) {
      const plan = frame.plan, slotsHeld = new Map();
      for (const id of this.rootsOfFrame(frame)) {
        const slot = plan.slotOf[id];
        if (slot === undefined) continue;
        slotsHeld.set(slot, id);                    // a later value in the same slot overwrites an earlier one
      }
      for (const [, id] of slotsHeld) if (frame.env.has(id)) slotUpdates.push([frame, id, move(frame.env.get(id))]);
    }
    for (const [k, v] of this.globals) this.globals.set(k, move(v));
    for (const k of Object.keys(this.natives)) this.natives[k] = move(this.natives[k]);
    for (const j of this.microtasks) { j.f = move(j.f); j.args = j.args.map(a => (a && a.handler !== undefined ? this.moveReaction(a, move) : move(a))); }
    for (const tm of this.timers) tm.f = move(tm.f);
    for (const h of this.hostRoots) { h.f = move(h.f); h.args = h.args.map(a => (a && a.handler !== undefined ? this.moveReaction(a, move) : move(a))); }
    // Trace: copy what the roots reach, updating every reference inside moved objects.
    while (queue.length) {
      const o = queue.shift();
      for (const [k, s] of o.props) o.props.set(k, 'value' in s ? { value: move(s.value) } : { get: move(s.get), set: move(s.set) });
      if (o.elems) o.elems = o.elems.map(move);
      if (o.caps) o.caps = o.caps.map(move);
      if ('value' in o && o.kind !== 'object') o.value = move(o.value);
      if (o.reactions) o.reactions = o.reactions.map(r => this.moveReaction(r, move));
    }
    for (const [frame, id, nv] of slotUpdates) frame.env.set(id, nv);
    for (const oldAddr of this.heap.keys()) if (!forward.has(oldAddr)) this.movedAt.set(oldAddr, at + ' (freed)');
    for (const [oldAddr, nv] of forward) { this.movedAt.set(oldAddr, at); this.forwardTo.set(oldAddr, nv.addr); }
    this.metrics.collections++; this.metrics.moved += forward.size;
    this.event('collect', { at, moved: forward.size, freed: this.heap.size - forward.size });
    this.heap = next; this.nextAddr = addr; this.sinceGC = 0; this.lastCollection = at;
  }
  moveReaction(r, move) { r.handler = move(r.handler); r.target = move(r.target); return r; }

  // ---- running a program: main, then the job queues
  runMain(name, args) {
    const fn = this.module.fn(name || this.module.main);
    if (!fn) throw new StrataError(`no function ${name || this.module.main}`);
    try { return { kind: 'normal', value: this.callFn(fn, fn.params.map((p, i) => (args ? args[i] : undefined))) }; }
    catch (e) { return this.outcomeOf(e); }
  }
  outcomeOf(e) {
    if (e instanceof JSThrow) { this.event('throw', { what: 'uncaught', value: this.display(e.value) }); return { kind: 'throw', value: e.value }; }
    if (e instanceof Diverge) return { kind: 'diverge', steps: e.steps };
    if (e instanceof StaleUse) return { kind: 'error', stale: e.detail, message: e.message };
    this.event('error', { message: e.message });
    return { kind: 'error', message: e.message };
  }
  runJobs(limit = Infinity) {
    let ran = 0;
    while (ran < limit && (this.microtasks.length || this.timers.length)) {
      let job;
      if (this.microtasks.length) job = this.microtasks.shift();
      else {
        this.timers.sort((a, b) => a.at - b.at || a.seq - b.seq);
        const tm = this.timers.shift(); this.vtime = tm.at; job = { f: tm.f, args: [] };
        this.event('timer', { what: 'fire', at: tm.at });
      }
      ran++; this.metrics.jobs++;
      this.hostRoots.push(job);                   // the running job is the host's: it stays rooted
      try { this.execDepth++; this.callValue(job.f, undefined, job.args); }
      catch (e) {
        const out = this.outcomeOf(e);
        if (out.kind !== 'throw') return { ran, stopped: out };
      } finally { this.execDepth--; this.hostRoots.pop(); }
    }
    return { ran, remaining: this.microtasks.length + this.timers.length };
  }
  result(outcome, extra = {}) {
    this.metrics.steps = this.steps;
    return {
      kind: 'run', mode: this.mode, gc: this.gc, outcome: { ...outcome, display: outcome.value !== undefined ? this.display(outcome.value) : undefined },
      output: this.output.slice(), trace: this.trace.slice(), events: this.events.slice(), steps: this.steps,
      records: this.records, metrics: { ...this.metrics }, ...extra,
      error: outcome.kind === 'error' ? { message: outcome.message, at: outcome.stale ? outcome.stale.at : undefined, stale: outcome.stale } : undefined,
      yamlTag: undefined,
    };
  }
}

function runModule(module, opts = {}) {
  const m = new Machine(module, opts);
  const t0 = now();
  const outcome = m.runMain(opts.entry, opts.args);
  let jobsOut = { ran: 0 };
  if (outcome.kind !== 'diverge' && !(outcome.kind === 'error')) jobsOut = m.runJobs(opts.jobs === undefined ? 10000 : (opts.jobs.n !== undefined ? opts.jobs.n : opts.jobs));
  const final = jobsOut.stopped && jobsOut.stopped.kind !== 'throw' ? jobsOut.stopped : outcome;
  return m.result(final, { ms: round(now() - t0, 2), jobsRun: jobsOut.ran });
}

// Observations: equal up to a renaming of objects that preserves identity, numbers by SameValue.
function observeEqual(a, b, opts = {}) {
  const map = new Map(), back = new Map();
  const same = (x, y, at) => {
    const rx = x && typeof x === 'object' && 'ref' in x, ry = y && typeof y === 'object' && 'ref' in y;
    if (rx || ry) {
      if (!(rx && ry)) return { equal: false, at, left: x, right: y, rule: 'an object against a primitive' };
      if (map.has(x.ref) && map.get(x.ref) !== y.ref) return { equal: false, at, rule: 'identity: one object on the left is two on the right' };
      if (back.has(y.ref) && back.get(y.ref) !== x.ref) return { equal: false, at, rule: 'identity: two objects on the left are one on the right' };
      map.set(x.ref, y.ref); back.set(y.ref, x.ref); return null;
    }
    if (!Object.is(x, y)) {
      const signedZero = typeof x === 'number' && typeof y === 'number' && x === 0 && y === 0;
      return { equal: false, at, left: x, right: y, rule: signedZero ? 'SameValue distinguishes -0 and +0' : 'values differ' };
    }
    return null;
  };
  const ta = a.trace || [], tb = b.trace || [];
  if (a.outcome.kind === 'error' || b.outcome.kind === 'error') return { equal: 'unknown', reason: 'a run stopped with an engine error: ' + (a.error || b.error || {}).message };
  if (a.outcome.kind === 'diverge' || b.outcome.kind === 'diverge') {
    if (a.outcome.kind !== b.outcome.kind) return { equal: 'unknown', reason: 'one run exhausted its step budget; compare under equal budgets' };
  }
  for (let i = 0; i < Math.max(ta.length, tb.length); i++) {
    if (!ta[i] || !tb[i]) return { equal: false, at: `trace[${i}]`, left: ta[i] || 'nothing', right: tb[i] || 'nothing', rule: 'different number of observations' };
    const va = ta[i].values, vb = tb[i].values;
    if (va.length !== vb.length) return { equal: false, at: `trace[${i}]`, rule: 'different arity' };
    for (let j = 0; j < va.length; j++) { const d = same(va[j], vb[j], `trace[${i}] argument ${j}`); if (d) return d; }
  }
  if (a.outcome.kind !== b.outcome.kind) return { equal: false, at: 'outcome', left: a.outcome.kind, right: b.outcome.kind, rule: 'outcomes differ' };
  // An uncaught exception is observed by what it prints as (its kind and message for an error).
  if (a.outcome.kind === 'throw' && a.outcome.display !== undefined && b.outcome.display !== undefined && a.outcome.display !== b.outcome.display)
    return { equal: false, at: 'outcome', left: a.outcome.display, right: b.outcome.display, rule: 'different uncaught values' };
  return { equal: true, observations: ta.length };
}

// ---------------------------------------------------------------- lattices
// A lattice supplies a bottom, a join and an order. A monotone transfer function over a
// lattice of finite height reaches a fixed point; one solver serves every analysis.

const lattice = {
  powerset(opts = {}) {
    return {
      name: 'powerset', universe: opts.universe,
      bottom: () => new Set(),
      join: (a, b) => { const out = new Set(a); for (const x of b) out.add(x); return out; },
      le: (a, b) => [...a].every(x => b.has(x)),
      eq: (a, b) => a.size === b.size && [...a].every(x => b.has(x)),
      height: () => (opts.universe ? [...opts.universe].length : Infinity),
      show: a => [...a].sort(),
      sample: (r, universe) => new Set([...universe].filter(() => r.chance(0.5))),
    };
  },
  flat(values = []) {
    const BOT = { flat: 'bottom' }, TOP = { flat: 'top' };
    return {
      name: 'flat', BOT, TOP, values,
      bottom: () => BOT,
      join: (a, b) => (a === BOT ? b : b === BOT ? a : Object.is(a, b) ? a : TOP),
      le: (a, b) => a === BOT || b === TOP || Object.is(a, b),
      eq: (a, b) => Object.is(a, b),
      height: () => 2, show: a => (a === BOT ? '⊥' : a === TOP ? '⊤' : a),
    };
  },
  map(inner) {
    return {
      name: `map(${inner.name})`, inner,
      bottom: () => new Map(),
      join: (a, b) => { const out = new Map(a); for (const [k, v] of b) out.set(k, out.has(k) ? inner.join(out.get(k), v) : v); return out; },
      le: (a, b) => [...a].every(([k, v]) => b.has(k) ? inner.le(v, b.get(k)) : inner.le(v, inner.bottom())),
      eq: (a, b) => a.size === b.size && [...a].every(([k, v]) => b.has(k) && inner.eq(v, b.get(k))),
      height: n => n * inner.height(), show: a => Object.fromEntries([...a].map(([k, v]) => [k, inner.show(v)])),
    };
  },
  types() {
    return {
      name: 'types', bottom: () => t.bottom, join: (a, b) => a.join(b), le: (a, b) => a.le(b), eq: (a, b) => a.eq(b),
      height: () => KINDS.length, show: a => a.toString(),
    };
  },
  product(...ls) {
    return {
      name: `product(${ls.map(l => l.name).join(', ')})`, parts: ls,
      bottom: () => ls.map(l => l.bottom()),
      join: (a, b) => ls.map((l, i) => l.join(a[i], b[i])),
      le: (a, b) => ls.every((l, i) => l.le(a[i], b[i])),
      eq: (a, b) => ls.every((l, i) => l.eq(a[i], b[i])),
      height: n => ls.reduce((h, l) => h + l.height(n), 0), show: a => ls.map((l, i) => l.show(a[i])),
    };
  },
  interval() {
    return {
      name: 'interval', infinite: true,
      bottom: () => null,
      join: (a, b) => (!a ? b : !b ? a : [Math.min(a[0], b[0]), Math.max(a[1], b[1])]),
      le: (a, b) => !a || (b && b[0] <= a[0] && a[1] <= b[1]),
      eq: (a, b) => (!a && !b) || (a && b && a[0] === b[0] && a[1] === b[1]),
      height: () => Infinity, show: a => (a ? `[${a[0]}, ${a[1]}]` : '⊥'),
    };
  },
};

const widen = {
  thresholds: steps => (prev, next) => {
    if (!prev || !next) return next;
    const lo = next[0] < prev[0] ? Math.max(...[-Infinity, ...steps].filter(s => s <= next[0])) : prev[0];
    const hi = next[1] > prev[1] ? Math.min(...[...steps, Infinity].filter(s => s >= next[1])) : prev[1];
    return [lo, hi];
  },
};

// ---------------------------------------------------------------- analyses as values

class Analysis {
  constructor(spec) { Object.assign(this, { name: 'analysis', direction: 'forward', exceptional: 'include', ...spec }); Object.freeze(this); }
  with(patch) { return new Analysis({ ...this, ...patch }); }
  lattice(l) { return this.with({ lat: l }); }
  forward() { return this.with({ direction: 'forward' }); }
  backward() { return this.with({ direction: 'backward' }); }
  transfer(f) { return this.with({ opTransfer: f, blockTransfer: null }); }
  block(f) { return this.with({ blockTransfer: f }); }
  edge(f) { return this.with({ edgeRule: f }); }
  widen(w) { return this.with({ widener: w }); }
  init(f) { return this.with({ boundary: f }); }
  yamlTag() { return `analysis ${this.name} (${this.direction})`; }
}
const analysisBuilder = name => new Analysis({ name });

// The edge rule for backward analyses over block parameters: a live parameter of the
// target makes the argument passed on this edge live; the implicit first parameter of an
// invoke or handler edge is defined by the edge itself.
const edgeRules = {
  substituteBlockArgs: () => (fn, from, e, x) => {
    const target = fn.block(e.block), implicit = implicitCount(fn, from, e);
    const out = new Set();
    for (const v of x) {
      const pi = target.params.findIndex(p => p.id === v);
      if (pi < 0) out.add(v);
      else if (pi >= implicit) { const a = e.args[pi - implicit]; if (a !== undefined && !isLit(a)) out.add(a); }
    }
    return out;
  },
  ignoreBlockArgs: () => (fn, from, e, x) => {
    const target = fn.block(e.block), names = new Set(target.params.map(p => p.id));
    return new Set([...x].filter(v => !names.has(v)));
  },
};

function implicitCount(fn, from, e) {
  if (e.kind === 'throw' || e.kind === 'handler') return 1;
  if (e.kind === 'normal') { const d = opRegistry[from.term.op.op]; return d && d.results.length ? 1 : 0; }
  return 0;
}

const operandsOf = o => o.args.filter(a => !isLit(a));
const termOperands = term => {
  const out = [];
  if (term.kind === 'branch') out.push(term.cond);
  if (term.kind === 'return' || term.kind === 'throw') out.push(term.value);
  if (term.kind === 'invoke') out.push(...term.op.args);
  return out.filter(a => !isLit(a));
};

// Liveness, block by block. Within a block, a may-throw operation with a handler makes
// everything the handler needs live across it, because the throw can come from there.
function livenessBlock(fn, b, liveOut, liveInOf, edgeRule, record) {
  let live = new Set(liveOut);
  const handler = b.onThrow && b.onThrow !== 'unwind' ? fn.block(b.onThrow) : null;
  const handlerLive = handler ? edgeRule(fn, b, { block: handler.name, args: b.throwArgs || [], kind: 'handler' }, liveInOf(handler.name)) : new Set();
  for (const a of termOperands(b.term)) live.add(a);
  if (record) record(`${fn.name}/${b.name}/term`, new Set([...liveOut]));
  for (let i = b.ops.length - 1; i >= 0; i--) {
    const o = b.ops[i];
    const d = opRegistry[o.op];
    if (o.result) live.delete(o.result);
    if (handler && d && d.mayThrow) for (const v of handlerLive) live.add(v);
    if (record) record(`${fn.name}/${b.name}/${i}`, new Set(live));
    for (const a of operandsOf(o)) live.add(a);
  }
  if (handler) for (const v of handlerLive) live.add(v);    // the handler's arguments are read at the head
  return live;
}

const analyses = {
  liveness: new Analysis({ name: 'liveness', direction: 'backward', lat: lattice.powerset(), edgeRule: edgeRules.substituteBlockArgs(), special: 'liveness' }),
  safepoints: new Analysis({ name: 'safepoints', direction: 'forward', lat: lattice.flat([false, true]), special: 'safepoints' }),
  typeFacts: new Analysis({ name: 'types', direction: 'forward', lat: lattice.map(lattice.types()), special: 'types' }),
  dominators: new Analysis({ name: 'dominators', special: 'dominators' }),
};
analyses.types = analyses.typeFacts;
analyses.product = (...as) => new Analysis({ name: as.map(a => a.name).join(' × '), parts: as, special: 'product' });

// ---------------------------------------------------------------- the solver
// A worklist over blocks. Each visit applies the block transfer; when a block's state
// changes, its neighbours in the direction of the analysis are queued again. The
// history of every visit is kept so the workbench can replay the iteration.

function solve(analysis, target, opts = {}) {
  if (target && target.kind === 'graph') return solveGraph(analysis, target, opts);
  const fn = target;
  if (analysis.special === 'product') {
    const parts = analysis.parts.map(a => solve(a, fn, opts));
    return { kind: 'facts', analysis: analysis.name, parts, iterations: Math.max(...parts.map(p => p.iterations)), ...Object.assign({}, ...parts.map(p => p.exports || {})), liveAcross: parts[0].liveAcross };
  }
  if (analysis.special === 'safepoints') return solveSafepoints(fn);
  if (analysis.special === 'dominators') { const d = dominators(fn); return { kind: 'facts', analysis: 'dominators', idom: d.idom, iterations: d.rounds, exports: { idom: d.idom } }; }
  if (analysis.special === 'types') return solveTypes(fn, opts);
  if (analysis.special === 'liveness' || analysis.direction === 'backward') return solveBackward(analysis, fn, opts);
  return solveForward(analysis, fn, opts);
}

function solveBackward(analysis, fn, opts = {}) {
  const lat = analysis.lat, rule = analysis.edgeRule || edgeRules.substituteBlockArgs();
  const IN = new Map(fn.blocks.map(b => [b.name, lat.bottom()])), OUT = new Map(fn.blocks.map(b => [b.name, lat.bottom()]));
  const preds = predecessors(fn), steps = [];
  const work = [...fn.blocks].reverse().map(b => b.name), queued = new Set(work);
  const budget = opts.budget ? opts.budget.n : Infinity, t0 = now();
  let visits = 0;
  while (work.length) {
    if (now() - t0 > budget) return budgetFallback(fn, analysis);
    const name = work.shift(); queued.delete(name); visits++;
    const b = fn.block(name);
    let out = lat.bottom();
    for (const e of termEdges(b.term)) if (fn.block(e.block)) out = lat.join(out, rule(fn, b, e, IN.get(e.block)));
    const inn = analysis.special === 'liveness' || !analysis.opTransfer
      ? livenessBlock(fn, b, out, n => IN.get(n), rule)
      : b.ops.slice().reverse().reduce((x, o) => analysis.opTransfer(o, x, { fn, block: b }), out);
    const changed = !lat.eq(inn, IN.get(name)) || !lat.eq(out, OUT.get(name));
    steps.push({ i: visits, block: name, before: { in: lat.show(IN.get(name)), out: lat.show(OUT.get(name)) }, after: { in: lat.show(inn), out: lat.show(out) }, changed });
    IN.set(name, inn); OUT.set(name, out);
    if (changed) {
      for (const p of preds.get(name) || []) if (!queued.has(p.from)) { work.push(p.from); queued.add(p.from); }
    }
  }
  // Live-across sets per operation: what is needed after it, excluding its own result.
  const across = {};
  for (const b of fn.blocks) livenessBlock(fn, b, OUT.get(b.name), n => IN.get(n), rule, (id, s) => { across[id] = [...s].sort(); });
  const show = m => Object.fromEntries([...m].map(([k, v]) => [k, lat.show(v)]));
  return {
    kind: 'facts', analysis: analysis.name, in: show(IN), out: show(OUT), across, steps, iterations: visits,
    liveAcross: id => across[id] || [],
    explain: (v, site) => explainLive(fn, v, site, across),
    of: v => ({ liveAt: Object.keys(across).filter(k => across[k].includes(v)) }),
    exports: { live: { in: show(IN), out: show(OUT), across } },
  };
}

function explainLive(fn, v, site, across) {
  const uses = usesOf(fn).get(v) || [];
  if (!(across[site] || []).includes(v)) return `${v} is not live across ${site}`;
  const u = uses[0];
  return u ? `${v} is live across ${site} because ${u.block.name} uses it later${u.edge ? ' as an argument to ' + u.edge.block : ''}` : `${v} is live across ${site}`;
}

function budgetFallback(fn, analysis) {
  const all = fn.values(), across = {};
  for (const b of fn.blocks) { b.ops.forEach((o, i) => { across[`${fn.name}/${b.name}/${i}`] = all; }); across[`${fn.name}/${b.name}/term`] = all; }
  return { kind: 'facts', analysis: analysis.name, status: 'budget-exhausted', result: 'fallback: every value live at every point (sound, imprecise)', across, liveAcross: id => across[id] || [], iterations: 0, steps: [] };
}

function solveForward(analysis, fn, opts = {}) {
  const lat = analysis.lat;
  const IN = new Map(fn.blocks.map(b => [b.name, lat.bottom()])), OUT = new Map(fn.blocks.map(b => [b.name, lat.bottom()]));
  if (analysis.boundary) IN.set(fn.entry, analysis.boundary(fn));
  const preds = predecessors(fn), steps = [];
  const work = fn.blocks.map(b => b.name), queued = new Set(work);
  let visits = 0;
  while (work.length) {
    const name = work.shift(); queued.delete(name); visits++;
    if (visits > 100000) throw new StrataError(`${analysis.name} did not converge; the lattice needs a widening`);
    const b = fn.block(name);
    let inn = name === fn.entry && analysis.boundary ? analysis.boundary(fn) : lat.bottom();
    for (const p of preds.get(name) || []) inn = lat.join(inn, analysis.edgeRule ? analysis.edgeRule(fn, fn.block(p.from), p, OUT.get(p.from)) : OUT.get(p.from));
    if (analysis.widener && visits > fn.blocks.length) inn = analysis.widener(IN.get(name), inn);
    const out = b.ops.reduce((x, o) => (analysis.opTransfer ? analysis.opTransfer(o, x, { fn, block: b }) : x), inn);
    const changed = !lat.eq(out, OUT.get(name)) || !lat.eq(inn, IN.get(name));
    steps.push({ i: visits, block: name, before: { in: lat.show(IN.get(name)), out: lat.show(OUT.get(name)) }, after: { in: lat.show(inn), out: lat.show(out) }, changed });
    IN.set(name, inn); OUT.set(name, out);
    if (changed) for (const e of successors(fn, b)) if (fn.block(e.block) && !queued.has(e.block)) { work.push(e.block); queued.add(e.block); }
  }
  const show = m => Object.fromEntries([...m].map(([k, v]) => [k, lat.show(v)]));
  return { kind: 'facts', analysis: analysis.name, in: show(IN), out: show(OUT), steps, iterations: visits, of: v => ({ in: show(IN), out: show(OUT) }) };
}

function solveSafepoints(fn) {
  const list = [];
  for (const b of fn.blocks) {
    b.ops.forEach((o, i) => { const d = opRegistry[o.op]; if (d && d.mayCollect) list.push(`${fn.name}/${b.name}/${i}`); });
    if (b.term && b.term.kind === 'invoke') { const d = opRegistry[b.term.op.op]; if (d && d.mayCollect) list.push(`${fn.name}/${b.name}/term`); }
  }
  return { kind: 'facts', analysis: 'safepoints', safepoints: list, iterations: 1, steps: [], exports: { safepoints: list } };
}

// Type facts, forward over a map from values to types. A branch on a type test refines
// the tested value on each edge, so a block reached only when x is a number knows it.
const TYPE_TESTS = { number: t.number, string: t.string, boolean: t.boolean, undefined: t.undefined, object: t.object.join(t.null), function: t.function };

function refinementOf(fn, defs, cond) {
  if (isLit(cond)) return null;
  const d = defs.get(cond);
  if (!d || d.kind !== 'op') return null;
  const o = d.op;
  if (o.op === 'core.is_number' && !isLit(o.args[0])) return { value: o.args[0], type: t.number };
  if (o.op === 'core.is_int32' && !isLit(o.args[0])) return { value: o.args[0], type: t.int32, onlyTrue: true };
  if (o.op === 'js.strict_eq' || o.op === 'num.eq') {
    const [a, b] = o.args;
    const ty = x => { if (isLit(x)) return null; const dx = defs.get(x); return dx && dx.kind === 'op' && dx.op.op === 'js.typeof' ? dx.op.args[0] : null; };
    for (const [subject, text] of [[ty(a), b], [ty(b), a]]) if (subject && !isLit(subject) && isLit(text) && TYPE_TESTS[text.lit]) return { value: subject, type: TYPE_TESTS[text.lit] };
  }
  if (o.op === 'js.truthy' || o.op === 'core.copy') return refinementOf(fn, defs, o.args[0]);
  return null;
}

function solveTypes(fn, opts = {}) {
  const defs = definitions(fn), lat = lattice.map(lattice.types());
  const typeIn = (state, a) => (isLit(a) ? t.ofValue(a.lit) : state.has(a) ? state.get(a) : t.bottom);
  const boundary = () => new Map(fn.params.map(p => [p.id, p.type]));
  const IN = new Map(fn.blocks.map(b => [b.name, new Map()])), OUT = new Map(fn.blocks.map(b => [b.name, new Map()]));
  const preds = predecessors(fn), steps = [];
  const edgeState = (from, e, state) => {
    const target = fn.block(e.block), out = new Map(state);
    const implicit = implicitCount(fn, from, e);
    if (implicit) {
      const p = target.params[0];
      if (e.kind === 'normal') { const o = from.term.op; out.set(p.id, opRegistry[o.op].typeOf(o.args.map(a => typeIn(state, a)), o, fn).meet(p.type)); }
      else out.set(p.id, p.type);
    }
    e.args.forEach((a, i) => { const p = target.params[i + implicit]; if (p) out.set(p.id, typeIn(state, a).meet(p.type)); });
    if (from.term && from.term.kind === 'branch' && (e.kind === 'true' || e.kind === 'false')) {
      const r = refinementOf(fn, defs, from.term.cond);
      if (r && state.has(r.value)) {
        const cur = out.get(r.value) || state.get(r.value);
        if (e.kind === 'true') out.set(r.value, cur.meet(r.type));
        else if (!r.onlyTrue) out.set(r.value, cur.minus(r.type));
      }
    }
    return out;
  };
  const work = fn.blocks.map(b => b.name), queued = new Set(work);
  let visits = 0;
  while (work.length) {
    const name = work.shift(); queued.delete(name); visits++;
    if (visits > 20000) break;
    const b = fn.block(name);
    let inn = name === fn.entry ? boundary() : new Map();
    for (const p of preds.get(name) || []) {
      const from = fn.block(p.from);
      if (p.kind === 'handler') inn = lat.join(inn, edgeState(from, p, IN.get(p.from)));
      else inn = lat.join(inn, edgeState(from, p, OUT.get(p.from)));
    }
    let state = new Map(inn);
    for (const o of b.ops) if (o.result) {
      const d = opRegistry[o.op];
      state.set(o.result, d ? d.typeOf(o.args.map(a => typeIn(state, a)), o, fn) : t.top);
    }
    const changed = !lat.eq(state, OUT.get(name)) || !lat.eq(inn, IN.get(name));
    steps.push({ i: visits, block: name, before: { in: lat.show(IN.get(name)), out: lat.show(OUT.get(name)) }, after: { in: lat.show(inn), out: lat.show(state) }, changed });
    IN.set(name, inn); OUT.set(name, state);
    if (changed) for (const e of successors(fn, b)) if (fn.block(e.block) && !queued.has(e.block)) { work.push(e.block); queued.add(e.block); }
  }
  const global = {};                              // the type at each value's definition
  for (const b of fn.blocks) for (const [k, v] of OUT.get(b.name)) global[k] = global[k] ? global[k].join(v) : v;
  for (const p of fn.params) global[p.id] = p.type;
  const at = (blockName, v) => { const s = OUT.get(blockName); return s && s.has(v) ? s.get(v) : (global[v] || t.top); };
  const inBlock = (blockName, v) => { const s = IN.get(blockName); return s && s.has(v) ? s.get(v) : (global[v] || t.top); };
  const show = m => Object.fromEntries([...m].map(([k, v]) => [k, lat.show(v)]));
  // the type of an operand just before op i of a block
  const before = (blockName, index, a) => {
    if (isLit(a)) return t.ofValue(a.lit);
    const b = fn.block(blockName);
    const state = new Map(IN.get(blockName));
    for (let i = 0; i < Math.min(index, b.ops.length); i++) {
      const o = b.ops[i]; if (o.result) state.set(o.result, opRegistry[o.op].typeOf(o.args.map(x => typeIn(state, x)), o, fn));
    }
    return state.has(a) ? state.get(a) : (global[a] || t.top);
  };
  return {
    kind: 'facts', analysis: 'types', steps, iterations: visits, in: show(IN), out: show(OUT),
    types: Object.fromEntries(Object.entries(global).map(([k, v]) => [k, v.toString()])),
    typeOf: v => global[v] || t.top, at, inBlock, before,
    of: v => ({ type: (global[v] || t.top).toString() }),
    exports: { types: Object.fromEntries(Object.entries(global).map(([k, v]) => [k, v.toString()])) },
  };
}

// ---------------------------------------------------------------- the same solver on plain graphs

function graph({ nodes = [], edges = [] } = {}) {
  return { kind: 'graph', nodes: nodes.map(n => (typeof n === 'string' ? { id: n } : n)), edges: edges.map(e => (Array.isArray(e) ? { from: e[0], to: e[1] } : e)) };
}

function solveGraph(analysis, gr, opts = {}) {
  const lat = analysis.lat, fwd = analysis.direction !== 'backward';
  const state = new Map(gr.nodes.map(n => [n.id, lat.bottom()]));
  const next = id => gr.edges.filter(e => (fwd ? e.from : e.to) === id).map(e => (fwd ? e.to : e.from));
  const prev = id => gr.edges.filter(e => (fwd ? e.to : e.from) === id).map(e => (fwd ? e.from : e.to));
  const start = opts.from ? [opts.from] : gr.nodes.map(n => n.id);
  const work = [...start], steps = [];
  let visits = 0;
  while (work.length) {
    const id = work.shift(); visits++;
    if (visits > 100000) break;
    let inn = lat.bottom();
    for (const p of prev(id)) inn = lat.join(inn, state.get(p));
    if (opts.from && id !== opts.from && prev(id).every(p => lat.eq(state.get(p), lat.bottom()))) continue;
    const node = gr.nodes.find(n => n.id === id);
    const out = analysis.opTransfer ? analysis.opTransfer(node, inn) : inn;
    const changed = !lat.eq(out, state.get(id));
    steps.push({ i: visits, block: id, before: lat.show(state.get(id)), after: lat.show(out), changed });
    if (changed || visits <= start.length) { state.set(id, out); for (const n of next(id)) work.push(n); }
  }
  return { kind: 'facts', analysis: analysis.name, iterations: visits, steps, of: id => lat.show(state.get(id)), state: Object.fromEntries([...state].map(([k, v]) => [k, lat.show(v)])) };
}

graph.scc = gr => {                               // Tarjan's strongly connected components
  let index = 0; const stack = [], on = new Set(), idx = new Map(), low = new Map(), out = [];
  const adj = id => gr.edges.filter(e => e.from === id).map(e => e.to);
  const visit = v => {
    idx.set(v, index); low.set(v, index); index++; stack.push(v); on.add(v);
    for (const w of adj(v)) {
      if (!idx.has(w)) { visit(w); low.set(v, Math.min(low.get(v), low.get(w))); }
      else if (on.has(w)) low.set(v, Math.min(low.get(v), idx.get(w)));
    }
    if (low.get(v) === idx.get(v)) { const comp = []; let w; do { w = stack.pop(); on.delete(w); comp.push(w); } while (w !== v); out.push(comp); }
  };
  for (const n of gr.nodes) if (!idx.has(n.id)) visit(n.id);
  return out;
};

// All the facts the workbench shows for one function.
function analyzeFn(fn) {
  const live = solve(analyses.liveness, fn), types = solve(analyses.types, fn), safe = solveSafepoints(fn), dom = dominators(fn);
  return {
    live: { in: live.in, out: live.out, across: live.across }, types: types.types, safepoints: safe.safepoints, idom: dom.idom,
    iterations: { liveness: live.iterations, types: types.iterations, dominators: dom.rounds },
    raw: { live, types, safe, dom },
  };
}

// ---------------------------------------------------------------- rewrites
// A rewrite matches an operation, checks a side condition and builds a replacement. The
// side condition reads derived permissions and facts; it never restates what an
// operation does. Every attempt is logged as a decision, fired or not, with the reason.

class Rewrite {
  constructor(spec) { Object.assign(this, { name: 'rewrite', matchFn: () => true, whenFn: null, toFn: null }, spec); Object.freeze(this); }
  with(p) { return new Rewrite({ ...this, ...p }); }
  match(f) { return this.with({ matchFn: f }); }
  when(f) { return this.with({ whenFn: f }); }
  to(f) { return this.with({ toFn: f }); }
  yamlTag() { return `rewrite ${this.name}`; }
}
const rewrite = name => new Rewrite({ name });

// A small pattern language for match(): m.op('js.add').resultUnused()
function patternOf(sel = '*') {
  const tests = [s => sel === '*' || s.op.op === sel || (sel.endsWith('.*') && s.op.op.startsWith(sel.slice(0, -1)))];
  const p = {
    resultUnused: () => (tests.push(s => s.unused && !!s.op.result), p),   // an op with a result nobody uses
    noResult: () => (tests.push(s => !s.op.result), p),
    inLoop: () => (tests.push(s => s.inLoop), p),
    hasVariants: () => (tests.push(s => !!(s.def && s.def.narrow)), p),
    test: s => tests.every(f => f(s)),
  };
  return p;
}
const M = { op: patternOf };

function sitesOf(fn) {
  const uses = usesOf(fn), out = [];
  for (const b of fn.blocks) b.ops.forEach((o, i) => out.push({
    fn, block: b, index: i, op: o, id: `${fn.name}/${b.name}/${i}`, def: opRegistry[o.op],
    unused: !o.result || !(uses.get(o.result) || []).length,
  }));
  return out;
}

function siteContext(fn, facts, decisions) {
  return {
    facts,
    perm: (o, extra = {}) => derivePermissions(lookupOp(o.op).behaviour, extra),
    typeAt: (site, a) => facts.types.before(site.block.name, site.index, a),
    variantFor: site => {
      const d = site.def; if (!d || !d.narrow) return null;
      return d.narrow(site.op.args.map(a => facts.types.before(site.block.name, site.index, a)));
    },
    noWritesBetween: (resource, b, i, j) => b.ops.slice(i + 1, j).every(o => !lookupOp(o.op).behaviour.writes.has(resource)),
    decisions,
  };
}

function applyRewrite(fn, rw, facts, decisions) {
  let fired = 0;
  const ctx = siteContext(fn, facts, decisions);
  for (const site of sitesOf(fn).reverse()) {
    if (!site.block.ops.includes(site.op)) continue;
    const m = rw.matchFn(M, site);
    const hit = m === true || (m && m.test && m.test(site));
    if (!hit) continue;
    let ok = true, because = 'matched';
    if (rw.whenFn) {
      const r = rw.whenFn(site, ctx);
      ok = r === true || (r && r.ok === true);
      because = (r && r.because) || (ok ? 'side condition holds' : reasonFor(rw, site, ctx));
    }
    if (ok) {
      const action = rw.toFn(site, ctx);
      const done = performAction(fn, site, action);
      if (done) { fired++; decisions.push({ by: rw.name, at: site.id, op: site.op.op, fired: true, because: done === true ? because : done }); }
    } else decisions.push({ by: rw.name, at: site.id, op: site.op.op, fired: false, because });
  }
  return fired;
}

function reasonFor(rw, site, ctx) {
  const p = derivePermissions(site.def.behaviour, { identityObserved: !site.unused });
  if (/erase|dce|dead/.test(rw.name)) return `perm.erase = ${p.erase}: ${p.because.erase.join('; ')}`;
  if (/hoist/.test(rw.name)) return `perm.hoist = ${p.hoist}: ${p.because.hoist.join('; ')}`;
  return 'side condition does not hold';
}

// Actions a rewrite's to() returns.
const act = {
  erase: () => ({ kind: 'erase' }),
  replaceWith: operand => ({ kind: 'replace', operand }),
  replaceOp: (name, args) => ({ kind: 'replaceOp', name, args }),
};
function performAction(fn, site, a) {
  if (!a) return false;
  const i = site.block.ops.indexOf(site.op);
  if (i < 0) return false;
  if (a.kind === 'erase') { site.block.ops.splice(i, 1); return true; }
  if (a.kind === 'replace') {
    if (site.op.result) replaceUses(fn, site.op.result, a.operand);
    site.block.ops.splice(i, 1); return true;
  }
  if (a.kind === 'replaceOp') {
    if (site.op.op === a.name) return false;
    const before = site.op.op;
    site.op.op = a.name; if (a.args) site.op.args = a.args;
    return `${before} → ${a.name}`;
  }
  return false;
}

// ---- the standard rewrites

const PURE_FOLD = new Set(['num.add', 'num.sub', 'num.mul', 'num.div', 'num.mod', 'num.neg', 'num.lt', 'num.le', 'num.gt', 'num.ge', 'num.eq', 'num.ne',
  'i32.add', 'i32.sub', 'i32.mul', 'i32.lt', 'i32.eq', 'bool.not', 'bool.and', 'bool.or', 'core.copy', 'js.strict_eq', 'js.strict_ne', 'js.typeof', 'js.not', 'js.truthy', 'core.is_number', 'core.is_int32']);
const PRIMITIVE_FOLD = new Set(['js.add', 'js.sub', 'js.mul', 'js.div', 'js.mod', 'js.neg', 'js.lt', 'js.le', 'js.gt', 'js.ge']);
const foldMachine = () => new Machine(new Module([]), {});

const std = {
  constFold: rewrite('const-fold')
    .match((m, s) => s.op.result && s.op.args.length > 0 && s.op.args.every(isLit) && (PURE_FOLD.has(s.op.op) || PRIMITIVE_FOLD.has(s.op.op)))
    .when((s) => ({ ok: true, because: PRIMITIVE_FOLD.has(s.op.op) ? 'primitive literal operands: no user code can run' : 'pure operation on literals' }))
    .to(s => act.replaceWith(lit(lookupOp(s.op.op).step(foldMachine(), s.op.args.map(a => a.lit), s.op)))),
  eraseDead: rewrite('erase-dead-result')
    .match(m => m.op('*').resultUnused())
    .when((s, ctx) => {
      const p = ctx.perm(s.op, { identityObserved: false });
      return { ok: p.erase === true, because: `perm.erase = ${p.erase}: ${p.because.erase.join('; ')}` };
    })
    .to(() => act.erase()),
  naiveDce: rewrite('naive-dce')                    // unsound on purpose: no side condition
    .match(m => m.op('*').resultUnused())
    .to(() => act.erase()),
  narrow: rewrite('narrow-by-facts')
    .match(m => m.op('*').hasVariants())
    .when((s, ctx) => { const v = ctx.variantFor(s); return { ok: !!v, because: v ? `operand types ${s.op.args.map(a => ctx.typeAt(s, a)).join(', ')} select ${v}` : `operand types ${s.op.args.map(a => ctx.typeAt(s, a)).join(', ')} select no variant` }; })
    .to((s, ctx) => act.replaceOp(ctx.variantFor(s))),
  copyProp: rewrite('copy-propagation')
    .match((m, s) => s.op.op === 'core.copy')
    .to(s => act.replaceWith(s.op.args[0])),
  forwardCells: rewrite('forward-store-to-load')
    .match((m, s) => s.op.op === 'cell.load' && !isLit(s.op.args[0]))
    .when((s) => {
      const c = s.op.args[0], ops = s.block.ops;
      for (let j = s.index - 1; j >= 0; j--) {
        const o = ops[j];
        if ((o.op === 'cell.store' && o.args[0] === c) || (o.op === 'cell.new' && o.result === c && o.args.length)) return { ok: true, because: `stored at ${s.fn.name}/${s.block.name}/${j}; nothing writes cells in between`, value: o.op === 'cell.store' ? o.args[1] : o.args[0] };
        const b = lookupOp(o.op).behaviour;
        if (b.writes.has('cells')) return { ok: false, because: `${o.op} at ${s.fn.name}/${s.block.name}/${j} may write cells (${b})` };
      }
      return { ok: false, because: 'no store to this cell earlier in the block' };
    })
    .to((s) => {
      const c = s.op.args[0], ops = s.block.ops;
      for (let j = s.index - 1; j >= 0; j--) {
        const o = ops[j];
        if (o.op === 'cell.store' && o.args[0] === c) return act.replaceWith(o.args[1]);
        if (o.op === 'cell.new' && o.result === c) return act.replaceWith(o.args[0]);
      }
      return null;
    }),
};

// Block-level rewrites: constant branches and unreachable blocks.
function simplifyBranches(fn, decisions) {
  let n = 0;
  for (const b of fn.blocks) {
    if (b.term && b.term.kind === 'branch' && isLit(b.term.cond)) {
      const value = b.term.cond.lit, keep = value ? b.term.t : b.term.f;
      b.term = { kind: 'jump', to: keep }; n++;
      decisions.push({ by: 'simplify-branch', at: `${fn.name}/${b.name}/term`, fired: true, because: `condition is the literal ${litText(value)}; always goes to ${keep.block}` });
    }
  }
  return n;
}
function removeUnreachable(fn, decisions) {
  const dom = dominators(fn);
  const before = fn.blocks.length;
  const dropped = fn.blocks.filter(b => !dom.reachable.has(b.name)).map(b => b.name);
  fn.blocks = fn.blocks.filter(b => dom.reachable.has(b.name));
  for (const name of dropped) decisions.push({ by: 'remove-unreachable', at: `${fn.name}/${name}`, fired: true, because: 'no path from entry' });
  return before - fn.blocks.length;
}

function rewriteSet(...items) {
  const list = items.flat().flatMap(x => (x && x.items ? x.items : [x])).filter(Boolean);
  return {
    kind: 'rewrites', items: list, names: list.map(r => r.name || r),
    with: (...more) => rewriteSet(list, ...more),
    yamlTag: () => `rewrites (${list.map(r => r.name || r).join(', ')})`,
  };
}
const rewrites = (...items) => rewriteSet(...items);
rewrites.canonical = () => rewriteSet(std.copyProp, std.constFold, 'simplify-branch', 'remove-unreachable', std.eraseDead);
rewrites.standard = () => rewriteSet(std.copyProp, std.constFold, 'simplify-branch', 'remove-unreachable', std.narrow, std.forwardCells, std.eraseDead);
rewrites.none = () => rewriteSet();
Object.assign(rewrites, std);

// Run a set to a fixed point (bounded), recomputing type facts between rounds.
function runRewrites(fn, set, decisions = [], maxRounds = 8) {
  let rounds = 0, total = 0;
  for (; rounds < maxRounds; rounds++) {
    let changed = 0;
    for (const r of set.items) {
      if (r === 'simplify-branch') { changed += simplifyBranches(fn, decisions); continue; }
      if (r === 'remove-unreachable') { changed += removeUnreachable(fn, decisions); continue; }
      const facts = { types: solveTypes(fn) };
      changed += applyRewrite(fn, r, facts, decisions);
    }
    total += changed;
    if (!changed) break;
  }
  return { fired: total, rounds: rounds + 1 };
}

// ---------------------------------------------------------------- promote cells: building SSA
// The frontend gives every variable a cell. A cell that only this function reads and
// writes, never escapes, and is not stored in a block that can throw to a handler, can
// become SSA values: each store defines a new value, each load uses the current one, and
// where control flow merges (the iterated dominance frontier of the stores) a block
// parameter joins the incoming values. This is Cytron et al.'s algorithm with block
// parameters in place of phi nodes.

// A cell can become SSA values when only loads and stores in this function use it. One more
// condition comes from exceptions: a handler sees a variable's value at the operation that
// threw, which a block-level exceptional exit cannot pass when the cell is created or
// stored in a protected block. So such a cell stays a cell if any of its loads can run
// after that handler.
function promotableCells(fn) {
  const uses = usesOf(fn), out = [], reach = new Map();
  const reachable = from => {
    if (reach.has(from)) return reach.get(from);
    const seen = new Set([from]), work = [from];
    while (work.length) { const b = fn.block(work.pop()); if (!b) continue; for (const e of successors(fn, b)) if (!seen.has(e.block)) { seen.add(e.block); work.push(e.block); } }
    reach.set(from, seen); return seen;
  };
  const protectedBy = b => (b.onThrow && b.onThrow !== 'unwind' ? b.onThrow : null);
  for (const b of fn.blocks) for (const o of b.ops) {
    if (o.op !== 'cell.new' || !o.result) continue;
    const us = uses.get(o.result) || [];
    if (!us.every(u => !u.edge && !u.term && u.op && u.slot === 0 && (u.op.op === 'cell.load' || u.op.op === 'cell.store'))) continue;
    const handlers = new Set([protectedBy(b), ...us.filter(u => u.op.op === 'cell.store').map(u => protectedBy(u.block))].filter(Boolean));
    const loads = us.filter(u => u.op.op === 'cell.load').map(u => u.block.name);
    if ([...handlers].some(h => loads.some(l => reachable(h).has(l)))) continue;
    out.push(o.result);
  }
  return out;
}

function dominanceFrontiers(fn, idom) {
  const preds = predecessors(fn), df = new Map(fn.blocks.map(b => [b.name, new Set()]));
  for (const b of fn.blocks) {
    const ps = (preds.get(b.name) || []).map(p => p.from);
    if (ps.length < 2) continue;
    for (const p of ps) {
      let runner = p;
      while (runner && runner !== idom[b.name] && runner !== undefined) {
        df.get(runner).add(b.name);
        if (runner === fn.entry) break;
        runner = idom[runner];
      }
    }
  }
  return df;
}

function promoteCells(fn, decisions = []) {
  const cells = promotableCells(fn);
  if (!cells.length) return { promoted: [] };
  const dom = dominators(fn), idom = dom.idom, df = dominanceFrontiers(fn, idom);
  const children = new Map(fn.blocks.map(b => [b.name, []]));
  for (const b of fn.blocks) if (idom[b.name] && b.name !== fn.entry && children.has(idom[b.name])) children.get(idom[b.name]).push(b.name);
  const names = new Map(cells.map(c => [c, c.replace(/^c_?/, '') || c]));
  // Place block parameters at the iterated dominance frontier of each cell's stores.
  const placed = new Map();                       // block → [cell…] in parameter order
  for (const c of cells) {
    const defBlocks = new Set();
    for (const b of fn.blocks) for (const o of b.ops) if ((o.op === 'cell.store' && o.args[0] === c) || (o.op === 'cell.new' && o.result === c)) defBlocks.add(b.name);
    const work = [...defBlocks], has = new Set();
    while (work.length) {
      const x = work.pop();
      for (const y of df.get(x) || []) if (!has.has(y)) {
        has.add(y);
        if (!placed.has(y)) placed.set(y, []);
        placed.get(y).push(c);
        if (!defBlocks.has(y)) work.push(y);
      }
    }
  }
  const paramName = new Map();
  for (const [bname, cs] of placed) {
    const b = fn.block(bname);
    for (const c of cs) { const id = freshName(fn, names.get(c) + '_'); b.params.push({ id, type: t.any }); paramName.set(bname + '|' + c, id); }
  }
  // Rename along the dominator tree.
  const undef = lit(undefined);
  const visit = (bname, current) => {
    const b = fn.block(bname); current = new Map(current);
    for (const c of placed.get(bname) || []) current.set(c, paramName.get(bname + '|' + c));
    const kept = [];
    for (const o of b.ops) {
      if (o.op === 'cell.new' && cells.includes(o.result)) { current.set(o.result, o.args.length ? o.args[0] : undef); continue; }
      if (o.op === 'cell.store' && cells.includes(o.args[0])) { current.set(o.args[0], o.args[1]); continue; }
      if ((o.op === 'cell.load') && cells.includes(o.args[0])) { if (o.result) replaceUses(fn, o.result, current.get(o.args[0]) || undef); continue; }
      kept.push(o);
    }
    b.ops = kept;
    // Append the current values to every edge into a block with placed parameters.
    const append = (edge) => { for (const c of placed.get(edge.block) || []) edge.args.push(current.get(c) || undef); };
    const term = b.term;
    if (term) for (const key of ['to', 't', 'f', 'normal', 'exc']) if (term[key]) append(term[key]);
    if (b.onThrow && b.onThrow !== 'unwind') { b.throwArgs = b.throwArgs || []; for (const c of placed.get(b.onThrow) || []) b.throwArgs.push(current.get(c) || undef); }
    for (const k of children.get(bname) || []) visit(k, current);
  };
  visit(fn.entry, new Map());
  // Loads in blocks not dominated by the cell's definition read the initial value.
  for (const b of fn.blocks) b.ops = b.ops.filter(o => !(o.op === 'cell.load' && cells.includes(o.args[0]) && (o.result && replaceUses(fn, o.result, undef), true)));
  const removed = removeDeadParams(fn);
  for (const c of cells) decisions.push({ by: 'promote-cells', at: `${fn.name}/${c}`, fired: true, because: 'used only by loads and stores in this function' });
  return { promoted: cells, params: paramName.size, removedParams: removed };
}

// A block parameter is live if something other than an edge into a dead parameter uses it.
function removeDeadParams(fn) {
  const isParam = new Map();
  for (const b of fn.blocks) if (b !== fn.blocks[0]) b.params.forEach((p, i) => isParam.set(p.id, { block: b, index: i }));
  const live = new Set(), work = [];
  const mark = v => { if (isParam.has(v) && !live.has(v)) { live.add(v); work.push(v); } };
  // Real uses mark parameters live; an edge argument marks it live only through the target.
  forEachUse(fn, (v, at) => { if (!at.edge) mark(v); });
  const incoming = new Map();                     // param → operands flowing into it
  for (const b of fn.blocks) for (const e of successors(fn, b)) {
    const target = fn.block(e.block); if (!target) continue;
    const implicit = implicitCount(fn, b, e);
    e.args.forEach((a, i) => { const p = target.params[i + implicit]; if (p) { if (!incoming.has(p.id)) incoming.set(p.id, []); incoming.get(p.id).push(a); } });
    if (implicit && target.params[0]) mark(target.params[0].id);  // implicit parameters stay
  }
  while (work.length) for (const a of incoming.get(work.pop()) || []) if (!isLit(a)) mark(a);
  let removed = 0;
  for (const b of fn.blocks) {
    if (b === fn.blocks[0]) continue;
    const dead = b.params.map((p, i) => (!live.has(p.id) ? i : -1)).filter(i => i >= 0);
    if (!dead.length) continue;
    for (const src of fn.blocks) for (const e of realEdges(src)) {
      if (e.edge.block !== b.name) continue;
      const implicit = e.implicit;
      e.edge.args = e.edge.args.filter((_, i) => !dead.includes(i + implicit));
    }
    b.params = b.params.filter((_, i) => !dead.includes(i)); removed += dead.length;
  }
  return removed;
}

function realEdges(b) {                           // the edge objects themselves, for mutation
  const out = [], term = b.term;
  if (term) {
    if (term.kind === 'jump') out.push({ edge: term.to, implicit: 0 });
    if (term.kind === 'branch') out.push({ edge: term.t, implicit: 0 }, { edge: term.f, implicit: 0 });
    if (term.kind === 'invoke') { const d = opRegistry[term.op.op]; out.push({ edge: term.normal, implicit: d && d.results.length ? 1 : 0 }, { edge: term.exc, implicit: 1 }); }
  }
  if (b.onThrow && b.onThrow !== 'unwind') {
    const holder = { get block() { return b.onThrow; }, get args() { return b.throwArgs || []; }, set args(v) { b.throwArgs = v; } };
    out.push({ edge: holder, implicit: 1 });
  }
  return out;
}

// ---------------------------------------------------------------- lowering to the runtime (L2)
// Each operation is bound to how the provider implements it: an inline instruction or a
// call to a runtime helper. The binding keeps the contract's obligations, so the plan
// knows which calls may collect and which may throw through the setjmp protocol.

const ROOT_KINDS = KBIT.object | KBIT.function | KBIT.cell | KBIT.completion | KBIT.string;
const needsRoot = ty => (ty.bits & ROOT_KINDS) !== 0;

function bindOps(fn, providers = {}) {
  const bindings = {};
  const bind = (o, id) => {
    const d = lookupOp(o.op), set = SET_OF(o.op);
    const provider = providers[set] || (set === 'core' ? 'reference' : 'hermes');
    const l = d.lower || {};
    bindings[id] = {
      op: o.op, provider, kind: l.inline ? 'inline' : l.direct ? 'direct' : 'helper',
      name: l.inline || (l.direct ? '@' + o.attrs.callee : l.helper || 'shllvm_' + o.op.replace(/\W/g, '_')), code: l.code,
      collects: d.mayCollect, throws: d.mayThrow, nonlocal: d.obligations.has('nonlocalThrow'),
    };
  };
  for (const b of fn.blocks) {
    b.ops.forEach((o, i) => bind(o, `${fn.name}/${b.name}/${i}`));
    if (b.term && b.term.kind === 'invoke') bind(b.term.op, `${fn.name}/${b.name}/term`);
  }
  return bindings;
}

function chooseReps(fn, types, strategy = 'tagged') {
  const reps = {};
  for (const v of fn.values()) {
    const ty = types.typeOf(v);
    if (strategy === 'unboxWhenProven' && !ty.isBottom && ty.le(t.boolean)) reps[v] = 'bool';
    else if (strategy === 'unboxWhenProven' && !ty.isBottom && ty.le(t.number)) reps[v] = ty.le(t.int32) && false ? 'i32' : 'f64';
    else reps[v] = 'tagged';
  }
  return reps;
}

function printL2(fn, bindings, reps) {
  return printFn(fn, {
    annotate: (b, i) => {
      const bd = bindings[`${fn.name}/${b.name}/${i}`];
      if (!bd) return '';
      const parts = [bd.kind === 'inline' ? `inline ${bd.name}` : bd.kind === 'direct' ? `direct call ${bd.name}` : `call ${bd.name}${bd.code ? '(' + bd.code + ')' : ''}`];
      if (bd.collects) parts.push('collects');
      if (bd.throws) parts.push(bd.nonlocal ? 'throws (setjmp)' : 'throws');
      const o = i === 'term' ? b.term.op : b.ops[i];
      if (o && o.result && reps[o.result] && reps[o.result] !== 'tagged') parts.push(`${o.result}: ${reps[o.result]}`);
      return parts.join(' · ');
    },
  });
}

// ---------------------------------------------------------------- execution plans (L3)
// A plan says, for every collecting point, which managed values must be reachable by the
// collector, and in which root slot each one sits. Strategies choose the slots; one
// checker judges every plan by the same invariant.

const FIXED_SLOTS = 2;                             // scratch and discard, as in the Hermes emitter
const NATIVE_FRAME_LIMIT = 1024;                   // the emitter's admission limit, in slots

function safepointSites(fn, bindings) {
  const out = [];
  for (const b of fn.blocks) {
    b.ops.forEach((o, i) => { const id = `${fn.name}/${b.name}/${i}`; if (bindings[id] && bindings[id].collects) out.push({ id, block: b, index: i, op: o }); });
    if (b.term && b.term.kind === 'invoke') { const id = `${fn.name}/${b.name}/term`; if (bindings[id] && bindings[id].collects) out.push({ id, block: b, index: 'term', op: b.term.op }); }
  }
  return out;
}

function maxOutgoingArgs(fn) {
  let n = 1;
  const visit = o => { if (o.op === 'js.call') n = Math.max(n, o.args.length - 1); if (o.op === 'js.call_method') n = Math.max(n, o.args.length - 1); if (o.op === 'core.call' || o.op === 'js.closure') n = Math.max(n, o.args.length); };
  for (const b of fn.blocks) { b.ops.forEach(visit); if (b.term && b.term.kind === 'invoke') visit(b.term.op); }
  return n;
}

// What a collecting point needs rooted: managed values live across it, and the managed
// operands it borrows (the helper reads them after it may have collected).
function requiredRoots(fn, live, types, site) {
  const across = live.across[site.id] || [];
  const borrowed = site.op.args.filter(a => !isLit(a));
  const need = new Set();
  for (const v of [...across, ...borrowed]) if (needsRoot(types.typeOf(v))) need.add(v);
  return [...need].sort();
}

const ROOT_STRATEGIES = {
  distinct(fn, ctx) {                              // one slot per value, as today's emitter does
    const slotOf = {}; let n = 0;
    const used = new Set(); forEachUse(fn, v => used.add(v));
    for (const v of fn.values()) if (used.has(v) && needsRoot(ctx.types.typeOf(v))) slotOf[v] = n++;
    return { slotOf, rootSlots: n, storage: 'native stack' };
  },
  stackReuse(fn, ctx) {                            // colour the values rooted at the same points
    // Greedy colouring in order of first need: each value takes the smallest slot that no value
    // needed at one of the same safepoints already holds. Per safepoint, a bitmap of used slots.
    const slotOf = {}, order = [], seen = new Set(), sitesOf = new Map();
    const needs = ctx.sites.map(s => ctx.required(s));
    needs.forEach((need, k) => { for (const a of need) { if (!seen.has(a)) { seen.add(a); order.push(a); sitesOf.set(a, []); } sitesOf.get(a).push(k); } });
    const words = Math.ceil((order.length + 1) / 32) + 1;
    const used = needs.map(() => new Uint32Array(words));
    let n = 0;
    const taken = new Uint32Array(words);
    for (const v of order) {
      taken.fill(0);
      for (const k of sitesOf.get(v)) { const u = used[k]; for (let w = 0; w < words; w++) taken[w] |= u[w]; }
      let slot = 0; while (taken[slot >>> 5] & (1 << (slot & 31))) slot++;
      slotOf[v] = slot; n = Math.max(n, slot + 1);
      for (const k of sitesOf.get(v)) used[k][slot >>> 5] |= 1 << (slot & 31);
    }
    return { slotOf, rootSlots: n, storage: 'native stack' };
  },
  arena(fn, ctx, params = {}) {                    // one slot per managed value, in runtime-owned chunks
    const d = ROOT_STRATEGIES.distinct(fn, ctx);
    return { ...d, storage: 'arena', chunk: params.chunk || kib(16), budget: params.budget || mib(4) };
  },
  none() { return { slotOf: {}, rootSlots: 0, storage: 'none (a demonstration of a missing plan)' }; },
};

class Strategy {
  // A lambda strategy wraps the slot's default (ctx.default); it inherits the default's
  // declared compatibility, and the plan checker verifies whatever plan it returns.
  constructor(slot, name, params = {}, fnImpl = null, wraps = null) { this.slot = slot; this.name = name; this.params = params; this.fnImpl = fnImpl; this.wraps = wraps; Object.freeze(this); }
  get compatName() { return this.fnImpl && this.wraps ? this.wraps : this.name; }
  toString() { return this.fnImpl ? (this.name === 'custom' ? `lambda(${this.wraps || 'custom'})` : this.name) : (Object.keys(this.params).length ? `${this.name}(${Object.entries(this.params).map(([k, v]) => `${k} ${v}`).join(', ')})` : this.name); }
  toJSON() { return this.toString(); }
  yamlTag() { return `${this.slot} ${this.toString()}`; }
}
const strat = (slot, name, params) => new Strategy(slot, name, params);

const roots = {
  distinct: p => strat('roots', 'distinct', p), stackReuse: p => strat('roots', 'stackReuse', p),
  arena: (p = {}) => strat('roots', 'arena', p), none: () => strat('roots', 'none'),
};
const exceptions = { setjmp: () => strat('exceptions', 'setjmp'), statusReturn: () => strat('exceptions', 'statusReturn'), landingPads: () => strat('exceptions', 'landingPads') };
const representation = { tagged: () => strat('representation', 'tagged'), unboxWhenProven: () => strat('representation', 'unboxWhenProven') };

function planFunction(fn, ctx0) {
  const { live, types, bindings, rootsStrategy, exceptionStrategy } = ctx0;
  const sites = safepointSites(fn, bindings);
  const required = s => requiredRoots(fn, live, types, s);
  const ctx = { types, live, sites, required };
  const runNamed = (s) => {
    const name = s.name || 'stackReuse';
    const impl = ROOT_STRATEGIES[name];
    if (!impl) throw new StrataError(`unknown root strategy ${name}`);
    return { strategy: s.toString ? s.toString() : name, ...impl(fn, ctx, s.params || {}) };
  };
  let chosen;
  if (rootsStrategy && rootsStrategy.fnImpl) {
    const base = strat('roots', rootsStrategy.wraps || 'stackReuse');
    const r = rootsStrategy.fnImpl(fn, { ...ctx, default: () => runNamed(base), run: s => runNamed(typeof s === 'string' ? strat('roots', s) : s), strategies: roots });
    chosen = r instanceof Strategy ? runNamed(r) : { strategy: rootsStrategy.toString(), ...r };
  } else chosen = runNamed(rootsStrategy || roots.stackReuse());
  // The checker: every required value has a slot, and no two required values share one.
  const safepoints = {}, missing = [];
  let peakLive = 0;
  for (const s of sites) {
    const need = required(s), rooted = [], miss = [], bySlot = new Map();
    for (const v of need) {
      const slot = chosen.slotOf[v];
      if (slot === undefined) { miss.push(v); continue; }
      if (bySlot.has(slot)) { miss.push(v); continue; }
      bySlot.set(slot, v); rooted.push(v);
    }
    peakLive = Math.max(peakLive, need.length);
    safepoints[s.id] = { op: s.op.op, live: (live.across[s.id] || []).slice(), required: need, rooted, missing: miss };
    const acrossHere = new Set(live.across[s.id] || []);
    for (const v of miss) missing.push({ value: v, at: s.id, op: s.op.op, how: acrossHere.has(v) ? 'live across' : 'borrowed by',
      why: chosen.slotOf[v] === undefined ? 'no root assigned' : `shares slot ${chosen.slotOf[v]} with ${bySlot.get(chosen.slotOf[v])}, which is also needed here` });
  }
  const argSlots = maxOutgoingArgs(fn);
  const frameSlots = chosen.storage === 'arena' ? chosen.rootSlots : chosen.rootSlots + FIXED_SLOTS + argSlots;
  const slotsList = [];
  for (const [v, s] of Object.entries(chosen.slotOf)) { if (!slotsList[s]) slotsList[s] = { slot: s, values: [] }; slotsList[s].values.push(v); }
  const unwind = [];
  for (const b of fn.blocks) {
    if (b.onThrow && b.onThrow !== 'unwind') unwind.push({ at: `${fn.name}/${b.name}`, handler: b.onThrow, strategy: exceptionStrategy.name, restores: ['root chain', 'managed frame', ...(chosen.storage === 'arena' ? ['arena mark'] : [])] });
    if (b.term && b.term.kind === 'invoke') unwind.push({ at: `${fn.name}/${b.name}/term`, handler: b.term.exc.block, strategy: exceptionStrategy.name, restores: ['root chain', 'managed frame', ...(chosen.storage === 'arena' ? ['arena mark'] : [])] });
  }
  const plan = {
    kind: 'plan', fn: fn.name, strategy: chosen.strategy, storage: chosen.storage,
    rootSlots: chosen.rootSlots, fixedSlots: chosen.storage === 'arena' ? 0 : FIXED_SLOTS, argSlots, frameSlots,
    frameBytes: chosen.storage === 'arena' ? 32 + 8 * chosen.rootSlots : 8 * frameSlots,
    peakLive, slots: slotsList.filter(Boolean), slotOf: chosen.slotOf, safepoints, missing, unwind,
    limit: chosen.storage === 'native stack' ? { max: NATIVE_FRAME_LIMIT, measured: frameSlots, ok: frameSlots <= NATIVE_FRAME_LIMIT } : chosen.storage === 'arena' ? { budget: String(chosen.budget || mib(4)), bytes: 32 + 8 * chosen.rootSlots, ok: (32 + 8 * chosen.rootSlots) <= (chosen.budget ? chosen.budget.n : 4194304) } : { ok: true },
  };
  return plan;
}

function printL3(fn, bindings, plan) {
  const slot = v => (plan.slotOf[v] !== undefined ? `s${plan.slotOf[v]}` : null);
  const head = [`; plan for ${fn.name}: ${plan.strategy}, ${plan.storage}`,
    `; frame: ${plan.rootSlots} root slots${plan.fixedSlots ? ` + ${plan.fixedSlots} fixed + ${plan.argSlots} argument` : ''} = ${plan.frameSlots} slots, ${plan.frameBytes} B`,
    ...plan.slots.map(s => `;   s${s.slot}: ${s.values.join(', ')}`)];
  const body = printFn(fn, {
    annotate: (b, i) => {
      const id = `${fn.name}/${b.name}/${i}`, sp = plan.safepoints[id];
      if (!sp) { const bd = bindings[id]; return bd && bd.kind !== 'inline' ? `call ${bd.name}` : ''; }
      const r = sp.rooted.map(v => `${slot(v)}=${v}`).join(' ');
      return `safepoint · rooted ${r || 'nothing'}${sp.missing.length ? ' · MISSING ' + sp.missing.join(', ') : ''}`;
    },
  });
  const unwind = plan.unwind.map(u => `; unwind ${u.at} → ${u.handler}: ${u.strategy}, restores ${u.restores.join(', ')}`);
  return [...head, body, ...unwind].join('\n');
}

// ---------------------------------------------------------------- LLVM IR text
// The shape of the existing Hermes backend: one function `define internal i64 @f(ptr %shr)`,
// a frame of root slots from shllvm_enter, helpers that write their result through an
// out pointer to a slot, numbers unboxed with bitcast for inline double arithmetic.

// Constants that are not numbers or immediates live in a string table shared by the
// module, as in Hermes; shllvm_constant(out, shr, index) materialises entry `index`.
const constantIndex = (pool, v) => { const k = typeof v === 'string' ? JSON.stringify(v) : String(v); if (!pool.has(k)) pool.set(k, pool.size); return pool.get(k); };
const isImmediate = v => typeof v === 'number' || typeof v === 'boolean' || v === undefined || v === null;

function emitLLVM(fn, bindings, plan, reps = {}, pool = new Map()) {
  const lines = [], decls = new Set(), tmp = { n: 0 };
  const T = () => `%t${tmp.n++}`;
  const declare = (name, sig) => decls.add(`declare ${sig.ret} @${name}(${sig.args.join(', ')})`);
  const slotPtr = v => (plan.slotOf[v] !== undefined ? `%s${plan.slotOf[v]}` : `%r.${safeName(v)}`);
  const regs = new Set(fn.values().filter(v => plan.slotOf[v] === undefined));
  const nArgs = plan.argSlots;
  lines.push(`define internal i64 @${safeName(fn.name)}(ptr %shr) {`, 'entry:');
  declare('_sh_check_native_stack_overflow', { ret: 'void', args: ['ptr'] });
  lines.push('  call void @_sh_check_native_stack_overflow(ptr %shr)');
  declare('shllvm_frame_size', { ret: 'i64', args: ['i32'] });
  lines.push(`  %size = call i64 @shllvm_frame_size(i32 ${plan.rootSlots + FIXED_SLOTS})`);
  lines.push('  %storage = alloca i8, i64 %size, align 16', `  %argv = alloca [${nArgs} x i64], align 8`);
  declare('shllvm_enter', { ret: 'ptr', args: ['ptr', 'ptr', 'i32', 'i32', 'i32'] });
  lines.push(`  %frame = call ptr @shllvm_enter(ptr %shr, ptr %storage, i32 ${plan.rootSlots + FIXED_SLOTS}, i32 ${nArgs}, i32 0)`);
  declare('shllvm_roots', { ret: 'ptr', args: ['ptr'] });
  lines.push('  %roots = call ptr @shllvm_roots(ptr %storage)');
  for (let i = 0; i < plan.rootSlots; i++) lines.push(`  %s${i} = getelementptr i64, ptr %roots, i32 ${i}`);
  lines.push(`  %scratch = getelementptr i64, ptr %roots, i32 ${plan.rootSlots}`, `  %discard = getelementptr i64, ptr %roots, i32 ${plan.rootSlots + 1}`);
  for (const v of regs) lines.push(`  %r.${safeName(v)} = alloca i64, align 8                 ; ${v}: not rooted`);
  const extraLiteralsAt = lines.length;           // allocas for a third, fourth… literal operand go here
  const params = new Map();
  fn.params.forEach((p, i) => {
    declare('shllvm_param', { ret: 'void', args: ['ptr', 'ptr', 'i32'] });
    lines.push(`  call void @shllvm_param(ptr ${slotPtr(p.id)}, ptr %frame, i32 ${i})`);
  });
  const hasTry = fn.blocks.some(b => (b.onThrow && b.onThrow !== 'unwind') || (b.term && b.term.kind === 'invoke'));
  if (hasTry) {
    declare('shllvm_try_size', { ret: 'i64', args: [] }); declare('shllvm_try_begin', { ret: 'ptr', args: ['ptr', 'ptr'] }); declare('_setjmp', { ret: 'i32', args: ['ptr'] });
    lines.push('  %trysize = call i64 @shllvm_try_size()', '  %try_storage = alloca i8, i64 %trysize, align 16', '  %try_state = alloca i32, align 4',
      '  store volatile i32 0, ptr %try_state, align 4', '  %buffer = call ptr @shllvm_try_begin(ptr %shr, ptr %try_storage)',
      '  %status = call i32 @_setjmp(ptr %buffer) returns_twice', '  %exceptional = icmp ne i32 %status, 0',
      `  br i1 %exceptional, label %catch.dispatch, label %b.${safeName(fn.entry)}`);
  } else lines.push(`  br label %b.${safeName(fn.entry)}`);
  // A literal operand is written to a fixed slot just before the helper reads it: the first
  // to %scratch, a second to %discard, which stays free until the helper writes its result;
  // any further ones to stack temporaries %lit2, %lit3… (constants need no root).
  const literalSlots = ['%scratch', '%discard']; let literalUse = 0, maxLiterals = 2;
  const literalSlot = k => { if (k < 2) return literalSlots[k]; maxLiterals = Math.max(maxLiterals, k + 1); return `%lit${k}`; };
  const writeConstant = (a, target) => {
    if (isImmediate(a.lit)) { lines.push(`  store i64 ${boxBits(a.lit)}, ptr ${target}       ; ${a}`); return target; }
    declare('shllvm_constant', { ret: 'void', args: ['ptr', 'ptr', 'i32'] });
    lines.push(`  call void @shllvm_constant(ptr ${target}, ptr %shr, i32 ${constantIndex(pool, a.lit)})          ; ${a}`);
    return target;
  };
  const constSlot = a => writeConstant(a, literalSlot(literalUse++));
  const ptrOf = a => (isLit(a) ? constSlot(a) : slotPtr(a));
  const storeArgv = list => list.forEach((a, k) => {
    const p = T(); lines.push(`  ${p} = getelementptr i64, ptr %argv, i32 ${k}`);
    if (isLit(a)) { writeConstant(a, p); return; }
    const x = T(); lines.push(`  ${x} = load i64, ptr ${slotPtr(a)}, align 8`, `  store i64 ${x}, ptr ${p}, align 8`);
  });
  const unitIndex = name => (plan.unitIndex && plan.unitIndex[name] !== undefined ? plan.unitIndex[name] : 0);
  ptrOf.literal = writeConstant; ptrOf.reset = () => { literalUse = 0; };
  const tries = new Map(); let tryN = 0;
  for (const b of fn.blocks) {
    lines.push(`b.${safeName(b.name)}:`);
    // Every block of a function with a try states its region: its handler's number, or 0 so
    // that a throw outside every region unwinds to the caller instead of re-entering a handler.
    const stateOf = blk => (blk.onThrow && blk.onThrow !== 'unwind' ? (tries.has(blk.onThrow) || tries.set(blk.onThrow, ++tryN), tries.get(blk.onThrow)) : 0);
    if (b.onThrow && b.onThrow !== 'unwind') lines.push(`  store volatile i32 ${stateOf(b)}, ptr %try_state, align 4    ; protected: a throw goes to ${b.onThrow}`);
    else if (hasTry && b.name !== fn.entry) lines.push('  store volatile i32 0, ptr %try_state, align 4    ; not protected: a throw unwinds to the caller');
    b.ops.forEach((o, i) => {
      const id = `${fn.name}/${b.name}/${i}`, bd = bindings[id];
      ptrOf.reset();
      lines.push(`  ; ${o.result ? o.result + ' = ' : ''}${opText(o)}`);
      if (bd.kind === 'inline' && /^f/.test(bd.name)) {
        const vals = o.args.map(a => { const x = T(), y = T(); if (isLit(a)) { lines.push(`  ${y} = fadd double 0.0, ${numLit(a.lit)}`); return y; } lines.push(`  ${x} = load i64, ptr ${slotPtr(a)}, align 8`, `  ${y} = bitcast i64 ${x} to double`); return y; });
        const r = T();
        if (bd.name.startsWith('fcmp')) {
          const c = T(); lines.push(`  ${c} = ${bd.name} double ${vals[0]}, ${vals[1]}`, `  ${r} = select i1 ${c}, i64 ${boxBits(true)}, i64 ${boxBits(false)}`);
        } else if (bd.name === 'fneg') {
          const c = T(); lines.push(`  ${c} = fneg double ${vals[0]}`, `  ${r} = bitcast double ${c} to i64`);
        } else { const c = T(); lines.push(`  ${c} = ${bd.name} double ${vals[0]}, ${vals[1]}`, `  ${r} = bitcast double ${c} to i64`); }
        if (o.result) lines.push(`  store i64 ${r}, ptr ${slotPtr(o.result)}, align 8`);
        return;
      }
      if (bd.kind === 'inline') {
        const r = T();
        if (o.args[0] !== undefined) { const x = T(); lines.push(`  ${x} = load i64, ptr ${ptrOf(o.args[0])}, align 8`, `  ${r} = add i64 ${x}, 0                         ; ${bd.name}`); }
        if (o.result) lines.push(`  store i64 ${r}, ptr ${slotPtr(o.result)}, align 8`);
        return;
      }
      if (bd.kind === 'direct') {                 // a known callee: arguments through argv, then a direct call
        storeArgv(o.args);
        declare('shllvm_push_args', { ret: 'void', args: ['ptr', 'ptr', 'i32', 'ptr'] });
        lines.push(`  call void @shllvm_push_args(ptr %shr, ptr %frame, i32 ${o.args.length}, ptr %argv)`);
        declare(safeName(o.attrs.callee), { ret: 'i64', args: ['ptr'] });
        const r = T(); lines.push(`  ${r} = call i64 @${safeName(o.attrs.callee)}(ptr %shr)      ; may collect`);
        if (o.result) lines.push(`  store i64 ${r}, ptr ${slotPtr(o.result)}, align 8`);
        return;
      }
      if (o.op === 'js.closure') {               // the function's index and its captured cells
        storeArgv(o.args);
        declare('shllvm_closure', { ret: 'void', args: ['ptr', 'ptr', 'ptr', 'i32', 'i32', 'ptr'] });
        lines.push(`  call void @shllvm_closure(ptr ${o.result ? slotPtr(o.result) : '%discard'}, ptr %shr, ptr %frame, i32 ${unitIndex(o.attrs.callee)}, i32 ${o.args.length}, ptr %argv)      ; @${o.attrs.callee} · may collect`);
        return;
      }
      emitHelper(lines, declare, bd, o, ptrOf, slotPtr, nArgs, T);
    });
    const term = b.term;
    ptrOf.reset();
    const copyEdge = (e, target) => {
      const tb = fn.block(e.block); if (!tb) return;
      const implicit = tb.params.length - e.args.length;
      const loaded = e.args.map(a => { const x = T(); lines.push(`  ${x} = load i64, ptr ${ptrOf(a)}, align 8`); return x; });
      loaded.forEach((x, k) => lines.push(`  store i64 ${x}, ptr ${slotPtr(tb.params[k + implicit].id)}, align 8`));
    };
    switch (term.kind) {
      case 'jump': copyEdge(term.to); lines.push(`  br label %b.${safeName(term.to.block)}`); break;
      case 'branch': {
        declare('shllvm_truthy', { ret: 'i32', args: ['ptr'] });
        const c = T(), d = T(); lines.push(`  ${c} = call i32 @shllvm_truthy(ptr ${ptrOf(term.cond)})`, `  ${d} = icmp ne i32 ${c}, 0`);
        const tl = `e.${safeName(b.name)}.t`, fl = `e.${safeName(b.name)}.f`;
        lines.push(`  br i1 ${d}, label %${tl}, label %${fl}`, `${tl}:`); copyEdge(term.t); lines.push(`  br label %b.${safeName(term.t.block)}`, `${fl}:`); copyEdge(term.f); lines.push(`  br label %b.${safeName(term.f.block)}`);
        break;
      }
      case 'return': { const x = T(); declare('shllvm_leave', { ret: 'void', args: ['ptr', 'ptr'] }); lines.push(`  ${x} = load i64, ptr ${ptrOf(term.value)}, align 8`, '  call void @shllvm_leave(ptr %shr, ptr %frame)', `  ret i64 ${x}`); break; }
      case 'throw': declare('shllvm_throw', { ret: 'void', args: ['ptr', 'ptr'] }); lines.push(`  call void @shllvm_throw(ptr %shr, ptr ${ptrOf(term.value)})`, '  unreachable'); break;
      case 'unreachable': lines.push('  unreachable'); break;
      case 'invoke': {
        const bd = bindings[`${fn.name}/${b.name}/term`];
        if (!tries.has(term.exc.block)) tries.set(term.exc.block, ++tryN);
        lines.push(`  store volatile i32 ${tries.get(term.exc.block)}, ptr %try_state, align 4    ; invoke: a throw goes to ${term.exc.block}`);
        emitHelper(lines, declare, bd, { ...term.op, result: fn.block(term.normal.block).params[0] && opRegistry[term.op.op].results.length ? fn.block(term.normal.block).params[0].id : null }, ptrOf, slotPtr, nArgs, T);
        lines.push(`  store volatile i32 ${stateOf(b)}, ptr %try_state, align 4    ; back to this block's region`);
        copyEdge(term.normal); lines.push(`  br label %b.${safeName(term.normal.block)}`); break;
      }
    }
  }
  if (hasTry) {
    declare('shllvm_catch_value', { ret: 'void', args: ['ptr', 'ptr'] }); declare('shllvm_rethrow', { ret: 'void', args: ['ptr'] });
    lines.push('catch.dispatch:', '  %state = load volatile i32, ptr %try_state, align 4', '  switch i32 %state, label %catch.rethrow [');
    for (const [h, n] of tries) lines.push(`    i32 ${n}, label %h.${safeName(h)}`);
    lines.push('  ]', 'catch.rethrow:', '  call void @shllvm_rethrow(ptr %shr)', '  unreachable');
    for (const [h] of tries) {
      const hb = fn.block(h);
      lines.push(`h.${safeName(h)}:`, `  call void @shllvm_catch_value(ptr ${hb && hb.params[0] ? slotPtr(hb.params[0].id) : '%discard'}, ptr %shr)`, `  br label %b.${safeName(h)}`);
    }
  }
  lines.push('}');
  if (maxLiterals > 2) lines.splice(extraLiteralsAt, 0, ...Array.from({ length: maxLiterals - 2 }, (_, i) => `  %lit${i + 2} = alloca i64, align 8                 ; a literal operand beyond the first two`));
  return { text: lines.join('\n'), declarations: [...decls].sort() };
}

function emitHelper(lines, declare, bd, o, ptrOf, slotPtr, nArgs, T) {
  const out = o.result ? slotPtr(o.result) : '%discard';
  const name = bd.name;
  if (name === 'shllvm_call') {
    const method = o.op === 'js.call_method';
    const [f, self, ...args] = method ? [o.args[0], o.args[0], ...o.args.slice(2)] : o.args;
    if (method) {                                    // the callee is the property, read first
      declare('shllvm_get', { ret: 'void', args: ['ptr', 'ptr', 'ptr', 'ptr'] });
      lines.push(`  call void @shllvm_get(ptr %scratch, ptr %shr, ptr ${ptrOf(o.args[0])}, ptr ${ptrOf(o.args[1])})      ; may collect`);
    }
    args.forEach((a, k) => {                         // arguments go straight into argv
      const p = T(); lines.push(`  ${p} = getelementptr i64, ptr %argv, i32 ${k}`);
      if (isLit(a)) { ptrOf.literal(a, p); return; }
      const x = T(); lines.push(`  ${x} = load i64, ptr ${slotPtr(a)}, align 8`, `  store i64 ${x}, ptr ${p}, align 8`);
    });
    declare(name, { ret: 'void', args: ['ptr', 'ptr', 'ptr', 'ptr', 'ptr', 'ptr', 'i32', 'ptr'] });
    // The method sits in %scratch, so a literal `this` (only for plain calls) also uses %scratch.
    const calleePtr = method ? '%scratch' : ptrOf(f);
    const thisPtr = method ? ptrOf(self) : (isLit(self) ? ptrOf.literal(self, '%discard') : ptrOf(self));
    lines.push(`  call void @shllvm_call(ptr ${out}, ptr %shr, ptr %frame, ptr ${calleePtr}, ptr ${thisPtr}, ptr null, i32 ${args.length}, ptr %argv)      ; may collect`);
    return;
  }
  const args = o.args.map(a => `ptr ${ptrOf(a)}`);
  const sig = ['ptr', 'ptr', ...o.args.map(() => 'ptr')];
  declare(name, { ret: 'void', args: bd.code ? ['ptr', 'ptr', 'i32', ...o.args.map(() => 'ptr')] : sig });
  const code = bd.code ? `, i32 ${opCodeNumber(bd.code)}` : '';
  lines.push(`  call void @${name}(ptr ${out}, ptr %shr${code}${args.length ? ', ' + args.join(', ') : ''})${bd.collects ? '      ; may collect' : ''}`);
}

const OPCODES = ['add', 'sub', 'mul', 'div', 'mod', 'lt', 'le', 'gt', 'ge', 'strict_eq', 'strict_ne', 'neg', 'typeof', 'print', 'queueMicrotask', 'setTimeout', 'Promise.resolve'];
const opCodeNumber = code => Math.max(0, OPCODES.indexOf(code));
const safeName = s => String(s).replace(/[^\w.]/g, '_');
const numLit = n => (Number.isFinite(n) ? (Number.isInteger(n) ? n.toFixed(1) : String(n)) : (Number.isNaN(n) ? '0x7FF8000000000000' : n > 0 ? '0x7FF0000000000000' : '0xFFF0000000000000'));
function boxBits(v) {                              // Hermes NaN-boxing: doubles as themselves, the rest tagged
  if (typeof v === 'number') { const b = new DataView(new ArrayBuffer(8)); b.setFloat64(0, v); return '0x' + b.getBigUint64(0).toString(16).toUpperCase().padStart(16, '0'); }
  if (v === true) return '0xFFF9000000000001';
  if (v === false) return '0xFFF9000000000000';
  if (v === null) return '0xFFF8C00000000000';
  return '0xFFF8800000000000';                     // undefined
}

// A structural check of the emitted text: labels defined once, every block terminated,
// every local defined before use, every called function declared.
function checkLLVM(text, declarations = []) {
  const errors = [], lines = text.split('\n').map(l => l.replace(/;.*$/, ''));
  const callable = new Set(declarations.map(d => /@([\w.]+)\(/.exec(d)[1]));
  for (const l of lines) { const m = /^define [^@]*@([\w.]+)\(/.exec(l.trim()); if (m) callable.add(m[1]); }
  const defined = new Set(['%shr']), labels = new Set();
  lines.forEach(l => { const m = /^\s*(%[\w.]+)\s*=/.exec(l); if (m) defined.add(m[1]); const lb = /^([\w.]+):\s*$/.exec(l.trim()); if (lb) { if (labels.has(lb[1])) errors.push({ message: `label ${lb[1]} defined twice` }); labels.add(lb[1]); } });
  let open = false, last = '';
  lines.forEach((raw, i) => {
    const line = raw.trim(); if (!line) return;
    if (/^define /.test(line)) { open = false; return; }
    if (/^[\w.]+:$/.test(line)) { if (open && !/^(br|ret|unreachable|switch|\])/.test(last)) errors.push({ line: i + 1, message: `the block before ${line} does not end in a terminator` }); open = true; last = ''; return; }
    for (const m of line.matchAll(/label %([\w.]+)/g)) if (!labels.has(m[1])) errors.push({ line: i + 1, message: `branch to unknown label %${m[1]}` });
    const rest = line.replace(/label %[\w.]+/g, '').replace(/^%[\w.]+\s*=/, '');
    for (const m of rest.matchAll(/%[\w.]+/g)) if (!defined.has(m[0])) errors.push({ line: i + 1, message: `${m[0]} is used but never defined` });
    for (const m of line.matchAll(/call [\w]+ @([\w.]+)\(/g)) if (!callable.has(m[1])) errors.push({ line: i + 1, message: `@${m[1]} is called but not declared` });
    if (line !== '}') last = line;
  });
  return { ok: errors.length === 0, errors: errors.slice(0, 20) };
}

// ---------------------------------------------------------------- WebAssembly for the core profile
// Functions that use only numbers, booleans and direct calls become a real Wasm module.
// Wasm wants structured control flow, so the CFG becomes a dispatch loop: a local holds
// the next block's index and br_table jumps to its code. Edge arguments are pushed on the
// operand stack, then stored into the target's parameters: a parallel copy for free.

const WASM_OPS = {
  'num.add': [0xa0], 'num.sub': [0xa1], 'num.mul': [0xa2], 'num.div': [0xa3], 'num.neg': [0x9a],
  'num.lt': [0x63], 'num.gt': [0x64], 'num.le': [0x65], 'num.ge': [0x66], 'num.eq': [0x61], 'num.ne': [0x62],
  'bool.not': [0x45], 'bool.and': [0x71], 'bool.or': [0x72],
  'i32.add': [0x6a], 'i32.sub': [0x6b], 'i32.mul': [0x6c], 'i32.lt': [0x48], 'i32.eq': [0x46],
};
const WAT_NAMES = { 0xa0: 'f64.add', 0xa1: 'f64.sub', 0xa2: 'f64.mul', 0xa3: 'f64.div', 0x9a: 'f64.neg', 0x63: 'f64.lt', 0x64: 'f64.gt', 0x65: 'f64.le', 0x66: 'f64.ge', 0x61: 'f64.eq', 0x62: 'f64.ne', 0x45: 'i32.eqz', 0x71: 'i32.and', 0x72: 'i32.or', 0x6a: 'i32.add', 0x6b: 'i32.sub', 0x6c: 'i32.mul', 0x48: 'i32.lt_s', 0x46: 'i32.eq' };
const F64 = 0x7c, I32 = 0x7f;

function wasmEligible(module, fn, types) {
  for (const b of fn.blocks) {
    for (const o of b.ops) {
      if (WASM_OPS[o.op] || o.op === 'num.mod' || o.op === 'core.copy') continue;
      if (o.op === 'host.print') { if (o.args.every(a => types.typeOf(a).le(t.number.join(t.boolean)) || (isLit(a) && typeof a.lit !== 'string'))) continue; return `host.print of a value that is not a number or boolean in ${b.name}`; }
      if (o.op === 'core.call') { const c = module.fn(o.attrs.callee); if (c && c !== fn && typeof wasmEligible(module, c, solveTypes(c)) === 'string') return `calls @${o.attrs.callee}, which is not in the core profile`; continue; }
      return `${o.op} in ${b.name} is outside the core profile (numbers, booleans, direct calls)`;
    }
    if (b.term.kind === 'invoke' || b.term.kind === 'throw') return `${b.term.kind} in ${b.name}: Wasm here has no exceptions`;
  }
  const used = usesOf(fn);
  for (const v of fn.values()) {
    if (!used.has(v) && fn.params.some(p => p.id === v)) continue;   // an unused parameter (such as `this`) is passed as 0
    const ty = types.typeOf(v); if (!ty.isBottom && !ty.le(t.number.join(t.boolean))) return `${v}: ${ty} is not a number or boolean`;
  }
  return true;
}

function encodeWasm(module, names) {
  const leb = n => { const out = []; do { let b = n & 0x7f; n >>>= 7; if (n) b |= 0x80; out.push(b); } while (n); return out; };
  const sleb = n => { const out = []; for (;;) { const b = n & 0x7f; n >>= 7; if ((n === 0 && !(b & 0x40)) || (n === -1 && (b & 0x40))) { out.push(b); return out; } out.push(b | 0x80); } };
  const str = s => [...leb(s.length), ...[...s].map(c => c.charCodeAt(0))];
  const vec = items => [...leb(items.length), ...items.flat()];
  const section = (id, body) => [id, ...leb(body.length), ...body];
  const f64 = v => { const b = new DataView(new ArrayBuffer(8)); b.setFloat64(0, v, true); return [...new Uint8Array(b.buffer)]; };
  const imports = [['print_num', [F64], []], ['print_bool', [I32], []], ['print_end', [], []], ['fmod', [F64, F64], [F64]]];
  const fns = names.map(n => module.fn(n));
  const typesOf = new Map(fns.map(f => [f.name, solveTypes(f)]));
  const vt = (f, v) => { const ty = typesOf.get(f.name).typeOf(v); return ty.le(t.boolean) && !ty.isBottom ? I32 : F64; };
  const sigs = [...imports.map(([, p, r]) => [p, r]), ...fns.map(f => [f.params.map(p => vt(f, p.id)), [f.result.le(t.boolean) && !f.result.isBottom ? I32 : F64]])];
  const typeSec = vec(sigs.map(([p, r]) => [0x60, ...vec(p.map(x => [x])), ...vec(r.map(x => [x]))]));
  const importSec = vec(imports.map(([name], i) => [...str('env'), ...str(name), 0x00, ...leb(i)]));
  const funcSec = vec(fns.map((f, i) => leb(imports.length + i)));
  const exportSec = vec(fns.map((f, i) => [...str(f.name), 0x00, ...leb(imports.length + i)]));
  const index = new Map(fns.map((f, i) => [f.name, imports.length + i]));
  const wat = [];
  const bodies = fns.map(f => {
    const locals = [], localIndex = new Map(), w = [];
    f.params.forEach((p, i) => localIndex.set(p.id, i));
    const extra = f.values().filter(v => !localIndex.has(v));
    extra.forEach((v, i) => { localIndex.set(v, f.params.length + i); locals.push(vt(f, v)); });
    const blk = f.params.length + extra.length; locals.push(I32);
    const code = [], n = f.blocks.length, bi = new Map(f.blocks.map((b, i) => [b.name, i]));
    const ind = d => '  '.repeat(d);
    w.push(`(func $${f.name} (export "${f.name}") ${f.params.map(p => `(param $${p.id} ${vt(f, p.id) === I32 ? 'i32' : 'f64'})`).join(' ')} (result ${sigs[index.get(f.name)][1][0] === I32 ? 'i32' : 'f64'})`);
    extra.forEach(v => w.push(`  (local $${v} ${vt(f, v) === I32 ? 'i32' : 'f64'})`)); w.push('  (local $blk i32)');
    const push = (a, depth, want) => {
      if (isLit(a)) {
        if (typeof a.lit === 'boolean' || want === I32) { code.push(0x41, ...sleb(a.lit ? 1 : 0)); w.push(ind(depth) + `i32.const ${a.lit ? 1 : 0}`); }
        else { code.push(0x44, ...f64(Number(a.lit))); w.push(ind(depth) + `f64.const ${a.lit}`); }
        return;
      }
      code.push(0x20, ...leb(localIndex.get(a))); w.push(ind(depth) + `local.get $${a}`);
    };
    code.push(0x03, 0x40); w.push('  (loop $dispatch');
    for (let k = n - 1; k >= 0; k--) { code.push(0x02, 0x40); w.push(ind(2 + (n - 1 - k)) + `(block $${f.blocks[k].name}`); }
    code.push(0x20, ...leb(blk), 0x0e, ...leb(n), ...f.blocks.flatMap((_, i) => leb(i)), ...leb(n - 1));
    w.push(ind(n + 2) + `(br_table ${f.blocks.map(b => '$' + b.name).join(' ')} (local.get $blk))`);
    f.blocks.forEach((b, k) => {
      code.push(0x0b);
      const d = 1 + (n - 1 - k);
      w.push(ind(d + 1) + `) ;; ${b.name}`);
      for (const o of b.ops) {
        if (o.op === 'host.print') {
          for (const a of o.args) { const isBool = isLit(a) ? typeof a.lit === 'boolean' : vt(f, a) === I32; push(a, d + 1, isBool ? I32 : F64); code.push(0x10, ...leb(isBool ? 1 : 0)); w.push(ind(d + 1) + `call $${isBool ? 'print_bool' : 'print_num'}`); }
          code.push(0x10, ...leb(2)); w.push(ind(d + 1) + 'call $print_end'); continue;
        }
        if (o.op === 'core.call') { o.args.forEach(a => push(a, d + 1)); code.push(0x10, ...leb(index.get(o.attrs.callee))); w.push(ind(d + 1) + `call $${o.attrs.callee}`); }
        else if (o.op === 'num.mod') { o.args.forEach(a => push(a, d + 1, F64)); code.push(0x10, ...leb(3)); w.push(ind(d + 1) + 'call $fmod'); }
        else if (o.op === 'core.copy') push(o.args[0], d + 1);
        else { const want = /^(bool|i32)\./.test(o.op) ? I32 : F64; o.args.forEach(a => push(a, d + 1, want)); code.push(...WASM_OPS[o.op]); w.push(ind(d + 1) + WAT_NAMES[WASM_OPS[o.op][0]]); }
        if (o.result) { code.push(0x21, ...leb(localIndex.get(o.result))); w.push(ind(d + 1) + `local.set $${o.result}`); }
        else if (o.op === 'core.call') { code.push(0x1a); w.push(ind(d + 1) + 'drop'); }
      }
      const goto = (e, depth, extra) => {          // extra: 1 inside an if
        const tb = f.block(e.block);
        e.args.forEach((a, i) => push(a, depth, vt(f, tb.params[i].id)));
        for (let i = tb.params.length - 1; i >= 0; i--) { code.push(0x21, ...leb(localIndex.get(tb.params[i].id))); w.push(ind(depth) + `local.set $${tb.params[i].id}`); }
        code.push(0x41, ...sleb(bi.get(e.block)), 0x21, ...leb(blk), 0x0c, ...leb(n - 1 - k + extra)); w.push(ind(depth) + `(local.set $blk (i32.const ${bi.get(e.block)}))`, ind(depth) + `br $dispatch`);
      };
      const term = b.term;
      if (term.kind === 'jump') goto(term.to, d + 1, 0);
      else if (term.kind === 'branch') {
        push(term.cond, d + 1, I32); code.push(0x04, 0x40); w.push(ind(d + 1) + 'if');
        goto(term.t, d + 2, 1); code.push(0x05); w.push(ind(d + 1) + 'else');
        goto(term.f, d + 2, 1); code.push(0x0b); w.push(ind(d + 1) + 'end');
      } else if (term.kind === 'return') { push(term.value, d + 1, sigs[index.get(f.name)][1][0]); code.push(0x0f); w.push(ind(d + 1) + 'return'); }
      else { code.push(0x00); w.push(ind(d + 1) + 'unreachable'); }
    });
    code.push(0x0b, 0x00, 0x0b); w.push('  ) ;; end dispatch', '  unreachable)');
    wat.push(w.join('\n'));
    const localDecls = vec(locals.map(x => [0x01, x]));
    const body = [...localDecls, ...code];
    return [...leb(body.length), ...body];
  });
  const codeSec = vec(bodies.map(b => [b]).map(x => x[0]));
  const bin = [0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00, ...section(1, typeSec), ...section(2, importSec), ...section(3, funcSec), ...section(7, exportSec), ...section(10, codeSec)];
  const watText = '(module\n  (import "env" "print_num" (func $print_num (param f64)))\n  (import "env" "print_bool" (func $print_bool (param i32)))\n  (import "env" "print_end" (func $print_end))\n  (import "env" "fmod" (func $fmod (param f64 f64) (result f64)))\n' + wat.map(x => x.split('\n').map(l => '  ' + l).join('\n')).join('\n') + '\n)';
  return { bytes: new Uint8Array(bin), wat: watText };
}

function runWasm(module, names, entry, args = []) {
  const { bytes, wat } = encodeWasm(module, names);
  const output = [], trace = [];
  let line = [];
  const env = {
    print_num: x => line.push(x), print_bool: x => line.push(!!x),
    print_end: () => { output.push(line.map(v => (Object.is(v, -0) ? '0' : String(v))).join(' ')); trace.push({ type: 'print', values: line }); line = []; },
    fmod: (a, b) => a % b,
  };
  const mod = new WebAssembly.Module(bytes);
  const inst = new WebAssembly.Instance(mod, { env });
  const t0 = now();
  const raw = inst.exports[entry](...args);
  const fnDef = module.fn(entry);
  const value = fnDef.result.le(t.boolean) && !fnDef.result.isBottom ? !!raw : raw;
  return { kind: 'run', mode: 'wasm', outcome: { kind: 'normal', value, display: String(value) }, output, trace, events: output.map((l, i) => ({ n: i, type: 'print', line: l })), steps: 0, records: [], metrics: { steps: 0, bytes: bytes.length, ms: round(now() - t0, 3) }, wat, bytes: bytes.length };
}

// ---------------------------------------------------------------- sources

const source = {
  // Core IR text is recognised by its first line that is not a comment: `fn name(`.
  text: (text, opts = {}) => {
    const name = opts.name || 'program.js';
    const first = String(text).split('\n').map(l => l.replace(/(\/\/|;).*$/, '').trim()).find(Boolean) || '';
    const lang = opts.lang || (/\.ir$/.test(name) || /^fn\s+[\w$.]+\s*\(/.test(first) ? 'ir' : 'js');
    return { kind: 'source', text: String(text), name, lang };
  },
  ir: (text, opts = {}) => ({ kind: 'source', text: String(text), name: opts.name || 'program.ir', lang: 'ir' }),
};

// ---------------------------------------------------------------- passes

class Pass {
  constructor(spec) { Object.assign(this, { src: null, dst: null, needs: [], gives: [], kills: [], body: null }, spec); Object.freeze(this); }
  with(p) { return new Pass({ ...this, ...p }); }
  from(l) { return this.with({ src: l }); }
  to(l) { return this.with({ dst: l }); }
  requires(...f) { return this.with({ needs: f.flat() }); }
  provides(...f) { return this.with({ gives: f.flat() }); }
  invalidates(...f) { return this.with({ kills: f.flat() }); }
  run(f) { return this.with({ body: f }); }
  then(next) { return seqPass([this, next]); }
  hash() { return hashString(stable({ n: this.name, from: this.src, to: this.dst, needs: this.needs, gives: this.gives, kills: this.kills, parts: this.parts ? this.parts.map(p => p.name) : null })); }
  yamlTag() { return `pass ${this.name}${this.src ? ` (${this.src}→${this.dst || this.src})` : ''}`; }
}
const pass = name => new Pass({ name });
function seqPass(parts) {
  const flat = parts.flatMap(p => (p.parts ? p.parts : [p])).filter(p => p.name !== 'identity');
  return new Pass({ name: flat.map(p => p.name).join(' ; '), parts: flat, src: flat[0] && flat[0].src, dst: flat.length ? flat[flat.length - 1].dst : null,
    needs: flat.length ? flat[0].needs : [], gives: flat.flatMap(p => p.gives), kills: [] });
}
pass.identity = new Pass({ name: 'identity' });

// The standard passes. Each runs on the compilation state and may add to it.
const STD_PASSES = {
  frontend: pass('frontend').from('L0').to('L1').provides('core-ir').run((st, cfg) => {
    const src = st.source;
    if (src instanceof Fn) st.module = new Module([src.clone()], { main: src.name });
    else if (src instanceof Module) st.module = src.clone();
    else if (src.lang === 'ir') { const parsed = parseIR(src.text); st.module = parsed instanceof Module ? parsed : new Module([parsed], { main: parsed.name }); }
    else {
      if (!root.strata.frontend) throw new StrataError('the JavaScript frontend (frontend.js) is not loaded');
      st.module = root.strata.frontend.compile(src.text, { name: src.name });
    }
    // Assumptions about parameter types (what a JIT speculates from profiles). They are not
    // checked here: a real tier guards each one and deoptimises when it fails.
    const assumed = [];
    for (const [fname, ps] of Object.entries(cfg.assume || {})) {
      const fn = st.module.fn(fname);
      if (!fn) { st.diagnostics.push({ severity: 'warning', kind: 'assume', message: `assume: no function ${fname}`, at: { fn: fname } }); continue; }
      for (const [pname, ty] of Object.entries(ps)) {
        const prm = fn.params.find(x => x.id === pname);
        if (!prm) { st.diagnostics.push({ severity: 'warning', kind: 'assume', message: `assume: ${fname} has no parameter ${pname}`, at: { fn: fname } }); continue; }
        prm.type = ty instanceof Type ? ty : t.parse(ty);
        assumed.push(`${fname}.${pname}: ${prm.type}`);
        st.decisions.push({ by: 'assume', at: `${fname}/${pname}`, fired: true, because: `assumed ${pname}: ${prm.type}, unchecked; a JIT would guard this and deoptimise when it fails` });
      }
    }
    st.levels['L1.cells'] = st.module.toString();
    return `${st.module.functions.size} functions${assumed.length ? ' · assumed ' + assumed.join(', ') : ''}`;
  }),
  promoteCells: pass('promote-cells').from('L1').to('L1').requires('core-ir').provides('ssa').run((st, cfg) => {
    if (cfg.frontend.promote === false) return 'skipped (frontend promote: false)';
    let n = 0;
    for (const fn of st.module.functions.values()) n += promoteCells(fn, st.decisions).promoted.length;
    st.levels['L1.ssa'] = st.module.toString();
    return `${n} cells promoted`;
  }),
  verify: pass('verify').from('L1').to('L1').requires('core-ir').provides('verified').run((st) => {
    const r = verify(st.module);
    st.diagnostics.push(...r.diagnostics);
    if (!r.ok) throw new StrataError('the core IR does not verify', { diagnostics: r.diagnostics, quiet: true });
    return 'ok';
  }),
  rewrite: pass('rewrite').from('L1').to('L1').requires('verified').invalidates('analyses').run((st, cfg) => {
    let fired = 0;
    for (const fn of st.module.functions.values()) fired += runRewrites(fn, cfg.rewrites, st.decisions).fired;
    const r = verify(st.module);
    if (!r.ok) { st.diagnostics.push(...r.diagnostics.map(d => ({ ...d, message: 'after rewrites: ' + d.message }))); throw new StrataError('a rewrite broke the IR', { quiet: true }); }
    return `${fired} rewrites fired (${cfg.rewrites.names.join(', ') || 'none'})`;
  }),
  analyze: pass('analyze').from('L1').to('L1').requires('verified').provides('liveness', 'safepoints', 'types', 'dominators').run((st) => {
    for (const fn of st.module.functions.values()) st.facts[fn.name] = analyzeFn(fn);
    const it = Object.values(st.facts).reduce((n, f) => n + f.iterations.liveness, 0);
    return `liveness ${it} block visits`;
  }),
  lowerRuntime: pass('lower-runtime').from('L1').to('L2').requires('verified', 'types').provides('runtime-bound').run((st, cfg) => {
    for (const fn of st.module.functions.values()) {
      st.bindings[fn.name] = bindOps(fn, cfg.providers);
      st.reps[fn.name] = chooseReps(fn, st.facts[fn.name].raw.types, cfg.representation.name || cfg.representation);
    }
    return 'bound to providers';
  }),
  planRoots: pass('plan-roots').from('L2').to('L3').requires('runtime-bound', 'liveness', 'safepoints').provides('root-plan', 'unwind-plan').run((st, cfg) => {
    let slotsTotal = 0;
    for (const fn of st.module.functions.values()) {
      const f = st.facts[fn.name];
      const plan = planFunction(fn, { live: f.raw.live, types: f.raw.types, bindings: st.bindings[fn.name], rootsStrategy: cfg.roots, exceptionStrategy: cfg.exceptions });
      st.plans[fn.name] = plan; slotsTotal += plan.rootSlots;
    }
    return `${slotsTotal} root slots in ${st.module.functions.size} functions`;
  }),
  checkPlan: pass('check-plan').from('L3').to('L3').requires('root-plan').run((st, cfg) => {
    let problems = 0;
    for (const plan of Object.values(st.plans)) {
      for (const m of plan.missing) { problems++; st.diagnostics.push({ severity: cfg.checks.gcSafety === false ? 'warning' : 'error', kind: 'gc-safety', rule: 'root-missing', message: `${m.value} is ${m.how || 'live across'} ${m.op} at ${m.at} but ${m.why}`, at: { fn: plan.fn, op: m.at }, value: m.value }); }
      if (plan.limit && plan.limit.ok === false) { problems++; st.diagnostics.push({ severity: 'error', kind: 'admission', message: plan.storage === 'arena' ? `${plan.fn} needs ${plan.limit.bytes} B of activation storage, over the arena budget ${plan.limit.budget}` : `${plan.fn} exceeds the ${NATIVE_FRAME_LIMIT}-slot native frame limit (${plan.rootSlots} roots + ${plan.fixedSlots} fixed + ${plan.argSlots} arguments = ${plan.frameSlots} slots, strategy ${plan.strategy})`, at: { fn: plan.fn } }); }
    }
    return problems ? `${problems} problems` : 'every collecting point roots what it needs';
  }),
  emitLLVM: pass('emit-llvm').from('L3').to('LLVM').requires('root-plan').run((st, cfg) => {
    let bad = 0;
    st.constants = new Map();                     // the module's string table
    const unitIndex = Object.fromEntries([...st.module.functions.keys()].map((n, i) => [n, i]));
    for (const fn of st.module.functions.values()) {
      st.plans[fn.name].unitIndex = unitIndex;
      const out = emitLLVM(fn, st.bindings[fn.name], st.plans[fn.name], st.reps[fn.name], st.constants);
      st.llvm[fn.name] = out;
      if (cfg.checks.llvm !== false) { const c = checkLLVM(out.text, out.declarations); out.check = c; if (!c.ok) { bad++; st.diagnostics.push({ severity: 'warning', kind: 'llvm-check', message: `LLVM text for ${fn.name}: ${c.errors[0].message}`, at: { fn: fn.name } }); } }
    }
    return bad ? `${bad} functions fail the structural check` : 'textual LLVM IR, structurally checked';
  }),
};

// ---------------------------------------------------------------- pipelines
// A pipeline is an immutable value. Every slot takes four forms: nothing (the default),
// partial parameters, a named strategy, or a lambda whose context offers the default.

const DEFAULTS = {
  profile: 'js', frontend: { promote: true }, assume: {}, providers: {}, rewrites: null, representation: 'tagged',
  roots: null, exceptions: null, materializer: 'llvm.orc', target: 'x86_64-linux-gnu', checks: { verify: true, gcSafety: true, llvm: true }, budget: {}, passes: null, raw: {}, stopAfter: null,
};

function slotValue(slot, x, prev) {
  if (x === undefined || x === null) return null;
  if (x instanceof Strategy) return x;
  if (typeof x === 'function') return new Strategy(slot, x.strategyName || 'custom', {}, x, (prev && !prev.fnImpl ? prev.name : null) || defaultStrategy(slot).name);
  if (typeof x === 'string') return strat(slot, x);
  if (typeof x === 'object') {
    if (slot === 'roots' && x.reuse === false) return roots.distinct();
    if (slot === 'roots' && x.reuse === true) return roots.stackReuse();
    const base = prev || defaultStrategy(slot);
    return strat(slot, base.name, { ...base.params, ...x });
  }
  throw new StrataError(`cannot use ${typeof x} as a ${slot} strategy`);
}
const defaultStrategy = slot => ({ roots: roots.stackReuse(), exceptions: exceptions.setjmp(), representation: representation.tagged() }[slot]);

class Pipeline {
  constructor(cfg = {}) { this.cfg = Object.freeze({ ...DEFAULTS, ...cfg }); this.kind = 'pipeline'; Object.freeze(this); }
  _with(p) { return new Pipeline({ ...this.cfg, ...p }); }
  profile(p) { return this._with({ profile: p }); }
  assume(map) {                                    // { fnName: { param: type } }, merged
    const next = { ...this.cfg.assume };
    for (const [f, ps] of Object.entries(map || {})) next[f] = { ...(next[f] || {}), ...ps };
    return this._with({ assume: next });
  }
  frontend(opts) { return this._with({ frontend: { ...this.cfg.frontend, ...(opts && opts.cfg ? opts.cfg : opts) } }); }
  provide(set, provider) { return this._with({ providers: { ...this.cfg.providers, ...(typeof set === 'string' ? { [set]: provider.name || provider } : set) } }); }
  rewrites(x) {
    if (typeof x === 'function' && !(x instanceof Rewrite)) return this._with({ rewrites: x(this.resolved().rewrites) });
    if (x instanceof Rewrite) x = rewriteSet(x);
    return this._with({ rewrites: x || null });
  }
  representation(x) { return this._with({ representation: slotValue('representation', x, this.cfg.representation) }); }
  roots(x) { return this._with({ roots: slotValue('roots', x, this.cfg.roots) }); }
  exceptions(x) { return this._with({ exceptions: slotValue('exceptions', x, this.cfg.exceptions) }); }
  materialize(m) { return this._with({ materializer: m.name || m, target: (m && m.target) || this.cfg.target }); }
  checks(c) { return this._with({ checks: { ...this.cfg.checks, ...c } }); }
  budget(b) { return this._with({ budget: { ...this.cfg.budget, ...b } }); }
  passes(list) { return this._with({ passes: list }); }
  insert(p, where = {}) {
    const list = (this.cfg.passes || defaultPassList(this.resolved())).slice();
    const anchor = where.after || where.before;
    const i = anchor ? list.findIndex(x => x.name === anchor) : list.length - 1;
    if (anchor && i < 0) throw new StrataError(`no pass ${anchor} in the pipeline`);
    list.splice(where.before ? i : i + 1, 0, p);
    return this._with({ passes: list });
  }
  stopAfter(level) { return this._with({ stopAfter: level }); }
  use(...presets) { return presets.flat().reduce((p, f) => (f ? f(p) || p : p), this); }
  with(f) { return f(this) || this; }
  set(k, v) { return this._with({ raw: { ...this.cfg.raw, [k]: v } }); }
  get(slot) { return this.resolved()[slot]; }
  resolved() {
    const c = this.cfg;
    return { ...c, rewrites: c.rewrites || rewrites.canonical(), roots: c.roots || roots.stackReuse(), exceptions: c.exceptions || exceptions.setjmp(),
      representation: c.representation instanceof Strategy ? c.representation : strat('representation', c.representation || 'tagged') };
  }
  passList() {
    const r = this.resolved();
    let list = r.passes || defaultPassList(r);
    if (r.stopAfter) {
      const rank = l => ['L0', 'L1', 'L2', 'L3', 'LLVM'].indexOf(l);
      const limit = rank(r.stopAfter);
      list = list.filter(p => rank(p.dst || p.src || 'L0') <= limit);
    }
    return list;
  }
  check() {
    const diags = [], have = new Set(), inserted = [];
    for (const p of this.passList()) {
      const missing = p.needs.filter(n => !have.has(n));
      if (missing.length) diags.push({ severity: 'error', kind: 'pass-requirements', pass: p.name, missing, message: `${p.name} needs ${missing.join(', ')}, which no earlier pass provides` });
      for (const g of p.gives) have.add(g);
      for (const k of p.kills) { if (k === 'analyses') ['liveness', 'safepoints', 'types', 'dominators'].forEach(x => have.delete(x)); else have.delete(k); }
    }
    const r = this.resolved();
    const c = compat(r.roots, r.exceptions);
    if (c.ok === false) diags.push({ severity: 'error', kind: 'strategy', message: c.reason });
    if (c.ok === 'unknown') diags.push({ severity: 'error', kind: 'strategy', message: c.reason });
    if (r.exceptions.name !== 'setjmp') {
      const hermesSets = ['js.value', 'js.object', 'js.function', 'js.control'].filter(s => !r.providers[s] || r.providers[s] === 'hermes');
      if (hermesSets.length) diags.push({ severity: 'error', kind: 'strategy', message: `exceptions: ${r.exceptions.name} needs helpers that report errors without longjmp, but ${hermesSets.join(', ')} ${hermesSets.length > 1 ? 'are' : 'is'} provided by Hermes, whose helpers throw nonlocally; keep setjmp or provide those sets yourself` });
    }
    return { ok: !diags.some(d => d.severity === 'error'), diagnostics: diags, inserted };
  }
  summary() {
    const r = this.resolved();
    const providers = { core: 'reference' };
    for (const s of ['js.value', 'js.object', 'js.function', 'js.control']) providers[s] = r.providers[s] || 'hermes';
    return {
      profile: r.profile, frontend: `strata.frontend (acorn) · promote cells: ${r.frontend.promote !== false}`, providers,
      rewrites: r.rewrites.names.join(', ') || 'none', ordering: 'ordered blocks + contracts',
      analyses: 'liveness, safepoints, types, dominators (one solver)',
      strategies: { representation: String(r.representation), roots: String(r.roots), exceptions: String(r.exceptions) },
      materializer: `${r.materializer} · ${r.target} · textual LLVM IR`, checks: r.checks, raw: r.raw,
      assume: Object.entries(r.assume || {}).flatMap(([f, ps]) => Object.entries(ps).map(([k, ty]) => `${f}.${k}: ${ty}`)),
      passes: this.passList().map(p => p.name),
    };
  }
  hash() { return hashString(stable({ ...this.summary(), passes: this.passList().map(p => p.hash()), lambdas: [this.cfg.roots, this.cfg.exceptions].filter(s => s && s.fnImpl).map(s => String(s.fnImpl)) })); }
  yamlTag() { return `pipeline ${this.hash().slice(0, 6)}`; }
}
// pipeline({ roots: 'none', rewrites: g.rewrites.standard() }) goes through the slot methods,
// so a configuration object means the same as the chained calls.
const pipeline = (cfg = {}) => {
  let p = new Pipeline({});
  for (const [k, v] of Object.entries(cfg || {})) {
    if (typeof p[k] === 'function' && !['check', 'summary', 'hash', 'resolved', 'passList', 'get', 'set', 'with', 'use', 'insert'].includes(k)) p = p[k](v);
    else p = p.set(k, v);
  }
  return p;
};

function defaultPassList(r) {
  const P = STD_PASSES;
  return [P.frontend, P.promoteCells, P.verify, P.rewrite, P.analyze, P.lowerRuntime, P.planRoots, P.checkPlan, P.emitLLVM];
}

function compat(r, e) {
  const rn = r ? (r.compatName || r.name) : 'stackReuse', en = e ? (e.compatName || e.name) : 'setjmp';
  const key = `${rn}|${en}`;
  if (DECLARED_PAIRS.has(key)) return { ok: true, ...DECLARED_PAIRS.get(key) };
  return { ok: 'unknown', reason: `roots ${rn} with exceptions ${en}: no declared compatible pair; declare one with g.compat.declare(roots, exceptions, { requires, tests }) after tracing throw, catch, collection and suspension` };
}
const DECLARED_PAIRS = new Map([
  ['distinct|setjmp', { evidence: 'the current Hermes protocol: _sh_catch_no_pop restores locals and the frame together' }],
  ['stackReuse|setjmp', { evidence: 'same protocol; slots are plain frame storage' }],
  ['arena|setjmp', { requires: 'the arena mark saved in every catch checkpoint', evidence: 'declared, traced in the workbench (L-presets)' }],
  ['none|setjmp', { evidence: 'a demonstration: nothing is rooted, so the plan checker reports every missing root' }],
  ['distinct|statusReturn', { requires: 'helpers that return a status', evidence: 'declared' }],
  ['stackReuse|statusReturn', { requires: 'helpers that return a status', evidence: 'declared' }],
]);
compat.declare = (r, e, info = {}) => { DECLARED_PAIRS.set(`${r.compatName || r.name || r}|${e.compatName || e.name || e}`, info); return { ok: true, ...info }; };

// ---------------------------------------------------------------- compile and the Program

function compile(pipe, src) {
  pipe = pipe || pipeline();
  if (typeof src === 'string') src = source.text(src);
  const r = pipe.resolved();
  const st = { source: src, module: null, levels: {}, facts: {}, plans: {}, bindings: {}, reps: {}, llvm: {}, diagnostics: [], trace: [], decisions: [] };
  const chk = pipe.check();
  st.diagnostics.push(...chk.diagnostics);
  const t0 = now();
  if (chk.ok) {
    for (const p of pipe.passList()) {
      const ts = now();
      let note;
      try { note = p.body ? p.body(st, r) : 'no body'; }
      catch (e) {
        if (!e.quiet) st.diagnostics.push({ severity: 'error', kind: e.kind || 'pass', message: e.message, at: e.loc ? { file: src.name, line: e.loc.line, col: e.loc.col } : { pass: p.name } });
        st.trace.push({ pass: p.name, level: `${p.src || ''}${p.dst && p.dst !== p.src ? '→' + p.dst : ''}`, ms: round(now() - ts, 2), note: 'stopped: ' + e.message });
        break;
      }
      st.trace.push({ pass: p.name, level: `${p.src || ''}${p.dst && p.dst !== p.src ? '→' + p.dst : ''}`, ms: round(now() - ts, 2), note: note || '' });
    }
  }
  return new Program(pipe, st, round(now() - t0, 2));
}

class Program {
  constructor(pipe, st, ms) {
    this.kind = 'program'; this.pipeline = pipe; this.st = st; this.compileMs = ms;
    this.name = st.source && st.source.name || (st.module && st.module.main) || 'program';
    this.source = st.source && st.source.text !== undefined ? st.source.text : (st.module ? st.module.toString() : '');
    this.diagnostics = st.diagnostics; this.trace = st.trace; this.decisions = st.decisions;
    this.module = st.module;
  }
  get ok() { return !this.diagnostics.some(d => d.severity === 'error') && !!this.module; }
  functions() { if (!this.module) return []; const n = this.module.names(); const m = this.module.main; return [m, ...n.filter(x => x !== m)]; }
  fnOf(name) { const f = this.module && this.module.fn(name || this.module.main); if (!f) throw new StrataError(`no function ${name}`); return f; }
  ir(level = 'L1', opts = {}) {
    const fmt = opts.format || 'text', names = opts.fn ? [opts.fn] : this.functions();
    if (level === 'L0') return this.source;
    if (!this.module) return '; nothing compiled: ' + (this.diagnostics[0] ? this.diagnostics[0].message : 'no module');
    if (level === 'L1.cells' || level === 'L1.ssa') {
      const text = this.st.levels[level] || '; this level was not produced';
      return opts.fn ? extractFn(text, opts.fn) : text;
    }
    if (level === 'L1') return fmt === 'json' ? JSON.stringify(names.map(n => fnToJSON(this.fnOf(n))), null, 1) : names.map(n => printFn(this.fnOf(n))).join('\n\n');
    if (level === 'L2') { if (!this.st.bindings[names[0]]) return '; L2 was not produced'; return fmt === 'json' ? JSON.stringify(Object.fromEntries(names.map(n => [n, this.st.bindings[n]])), null, 1) : names.map(n => printL2(this.fnOf(n), this.st.bindings[n], this.st.reps[n] || {})).join('\n\n'); }
    if (level === 'L3') { if (!this.st.plans[names[0]]) return '; L3 was not produced'; return fmt === 'json' ? JSON.stringify(Object.fromEntries(names.map(n => [n, this.plan(n)])), null, 1) : names.map(n => printL3(this.fnOf(n), this.st.bindings[n], this.st.plans[n])).join('\n\n'); }
    if (level === 'LLVM') {
      if (!this.st.llvm[names[0]]) return '; LLVM IR was not produced';
      const decls = [...new Set(names.flatMap(n => this.st.llvm[n].declarations))].sort();
      const table = [...(this.st.constants || new Map())].map(([k, i]) => `;   ${i}: ${k}`);
      return [`; ModuleID = '${this.name}'`, `target triple = "${this.pipeline.resolved().target}"`, '', ...(table.length ? ['; string table (shllvm_constant index: value)', ...table, ''] : []), ...decls, '', ...names.map(n => this.st.llvm[n].text)].join('\n');
    }
    if (level === 'WAT') return this.wasm(opts.fn).wat;
    return `; unknown level ${level}`;
  }
  wasm(fnName) {
    const names = this.functions(), ok = [], reasons = {};
    for (const n of names) { const r = wasmEligible(this.module, this.fnOf(n), this.st.facts[n] ? this.st.facts[n].raw.types : solveTypes(this.fnOf(n))); if (r === true) ok.push(n); else reasons[n] = r; }
    if (!ok.length) return { ok: [], reasons, wat: `;; no function is in the core profile the Wasm backend accepts\n${Object.entries(reasons).map(([n, r]) => `;; ${n}: ${r}`).join('\n')}` };
    const enc = encodeWasm(this.module, ok);
    return { ok, reasons, wat: enc.wat + (Object.keys(reasons).length ? '\n' + Object.entries(reasons).map(([n, r]) => `;; not compiled: ${n}: ${r}`).join('\n') : ''), bytes: enc.bytes };
  }
  cfg(fnName, level = 'L1') {
    const fn = this.fnOf(fnName), bd = this.st.bindings[fn.name] || {};
    const opView = (o, id) => {
      const d = opRegistry[o.op];
      return { id, text: (o.result ? o.result + ' = ' : '') + opText(o), op: o.op, args: o.args.map(operandText), results: o.result ? [o.result] : [], invoke: id.endsWith('/term'), mayThrow: !!(d && d.mayThrow), safepoint: !!(bd[id] ? bd[id].collects : d && d.mayCollect), loc: o.loc };
    };
    return {
      name: fn.name, entry: fn.entry, params: fn.params.map(p => ({ id: p.id, type: String(p.type) })), meta: fn.meta,
      blocks: fn.blocks.map(b => ({
        name: b.name, params: b.params.map(p => ({ id: p.id, type: String(p.type) })), onThrow: b.onThrow, throwArgs: (b.throwArgs || []).map(operandText),
        ops: b.ops.map((o, i) => opView(o, `${fn.name}/${b.name}/${i}`)),
        term: { kind: b.term.kind, text: termText(b.term), op: b.term.kind === 'invoke' ? opView(b.term.op, `${fn.name}/${b.name}/term`) : null,
          edges: successors(fn, b).map(e => ({ to: e.block, args: e.args.map(operandText), kind: e.kind })) },
      })),
    };
  }
  facts(fnName) {
    const f = this.st.facts[this.fnOf(fnName).name] || analyzeFn(this.fnOf(fnName));
    return { live: f.live, types: f.types, safepoints: f.safepoints, idom: f.idom, iterations: f.iterations };
  }
  steps(fnName, analysis = 'liveness') {
    const fn = this.fnOf(fnName), f = this.st.facts[fn.name] || analyzeFn(fn);
    return analysis === 'types' ? f.raw.types.steps : f.raw.live.steps;
  }
  plan(fnName) {
    const p = this.st.plans[this.fnOf(fnName).name];
    if (!p) return null;
    const { slotOf, ...rest } = p;
    return { ...rest, reps: this.st.reps[p.fn] || {} };
  }
  perm(opId) {
    const site = this.site(opId);
    if (!site) throw new StrataError(`no operation ${opId}`);
    const d = lookupOp(site.op.op);
    const uses = usesOf(site.fn);
    const unused = !site.op.result || !(uses.get(site.op.result) || []).length;
    const p = derivePermissions(d.behaviour, { identityObserved: !unused });
    return { op: site.op.op, text: opText(site.op), contract: { behaviour: d.behaviour.toString(), obligations: d.obligations.toString() }, resultUnused: unused, ...p };
  }
  site(opId) {
    const [fname, bname, idx] = String(opId).split('/');
    const fn = this.module && this.module.fn(fname); if (!fn) return null;
    const b = fn.block(bname); if (!b) return null;
    if (idx === 'term') return b.term.kind === 'invoke' ? { fn, block: b, index: 'term', op: b.term.op } : { fn, block: b, index: 'term', op: { op: 'term', args: [], result: null }, term: b.term };
    const o = b.ops[Number(idx)]; return o ? { fn, block: b, index: Number(idx), op: o } : null;
  }
  why(target) {
    target = String(target);
    if (target.startsWith('slot:')) {
      const [fname, s] = target.slice(5).split('/');
      const plan = this.st.plans[fname]; if (!plan) return { error: `no plan for ${fname}` };
      const values = Object.entries(plan.slotOf).filter(([, k]) => String(k) === s).map(([v]) => v);
      const points = Object.entries(plan.safepoints).filter(([, sp]) => sp.rooted.some(v => values.includes(v)));
      return { slot: Number(s), fn: fname, values, strategy: plan.strategy, rootedAt: points.map(([id, sp]) => `${id} ${sp.op}: ${sp.rooted.filter(v => values.includes(v)).join(', ')}`),
        because: values.length > 1 ? 'these values are never required at the same collecting point, so they can share it' : 'live across a collecting call (or borrowed by one)' };
    }
    if (target.split('/').length === 3) {
      const site = this.site(target); if (!site) return { error: `no operation ${target}` };
      const plan = this.st.plans[site.fn.name], sp = plan && plan.safepoints[target];
      return { op: target, text: site.op.op === 'term' ? termText(site.term) : opText(site.op), contract: site.op.op === 'term' ? null : lookupOp(site.op.op).contract,
        liveAcross: (this.st.facts[site.fn.name] && this.st.facts[site.fn.name].live.across[target]) || [], safepoint: sp || null,
        decisions: this.decisions.filter(d => d.at === target) };
    }
    const [fname, v] = target.includes(':') ? target.split(':') : [null, target];
    for (const fn of this.module.functions.values()) {
      if (fname && fn.name !== fname) continue;
      const defs = definitions(fn); if (!defs.has(v)) continue;
      const d = defs.get(v), f = this.st.facts[fn.name], plan = this.st.plans[fn.name];
      return { value: v, fn: fn.name, defined: d.kind === 'op' ? `${fn.name}/${d.block}/${d.index} ${opText(d.op)}` : `${d.kind} of ${d.block}`, type: f ? f.types[v] : undefined,
        liveAcross: f ? Object.entries(f.live.across).filter(([, s]) => s.includes(v)).map(([k]) => k) : [], slot: plan && plan.slotOf[v] !== undefined ? plan.slotOf[v] : null,
        uses: (usesOf(fn).get(v) || []).map(u => `${fn.name}/${u.block.name}/${u.term ? 'term' : u.index}`) };
    }
    return { error: `nothing called ${target}` };
  }
  find(pred) {
    const out = [];
    for (const fn of this.module.functions.values()) for (const b of fn.blocks) b.ops.forEach((o, i) => { const s = { id: `${fn.name}/${b.name}/${i}`, fn: fn.name, block: b.name, index: i, op: o.op, text: opText(o), result: o.result }; if (!pred || pred(s)) out.push(s); });
    return out;
  }
  summary() {
    const s = this.pipeline.summary();
    const counts = { functions: 0, blocks: 0, ops: 0, values: 0 };
    if (this.module) for (const fn of this.module.functions.values()) { counts.functions++; counts.blocks += fn.blocks.length; counts.ops += fn.blocks.reduce((n, b) => n + b.ops.length + 1, 0); counts.values += fn.values().length; }
    return { ...s, counts, ok: this.ok, compileMs: this.compileMs, errors: this.diagnostics.filter(d => d.severity === 'error').length };
  }
  metrics() {
    const plans = Object.values(this.st.plans);
    return { compileMs: this.compileMs, functions: this.module ? this.module.functions.size : 0, rootSlots: plans.reduce((n, p) => n + p.rootSlots, 0),
      maxFrameSlots: plans.reduce((n, p) => Math.max(n, p.frameSlots), 0), peakLive: plans.reduce((n, p) => Math.max(n, p.peakLive), 0),
      ops: this.summary().counts.ops, rewritesFired: this.decisions.filter(d => d.fired && d.by !== 'promote-cells' && d.by !== 'assume').length,
      cellsPromoted: this.decisions.filter(d => d.fired && d.by === 'promote-cells').length, errors: this.diagnostics.filter(d => d.severity === 'error').length };
  }
  run(opts = {}) {
    if (!this.module) return { kind: 'run', mode: opts.mode || 'spec', outcome: { kind: 'error', message: 'nothing compiled' }, output: [], trace: [], events: [], records: [], steps: 0, metrics: {}, error: { message: 'nothing compiled' } };
    const mode = opts.mode || 'spec';
    const steps = opts.budget && opts.budget.n !== undefined ? opts.budget.n : opts.steps || opts.budget || 200000;
    const entryFn = this.module.fn(opts.entry || this.module.main);
    const entryArgs = entryFn && opts.args ? this.argsFor(entryFn, opts.args) : opts.args;
    if (mode === 'wasm') {
      const entry = opts.entry || this.module.main, w = this.wasm();
      if (!w.ok.includes(entry)) return { kind: 'run', mode: 'wasm', outcome: { kind: 'error', message: `wasm: ${entry} is not in the core profile: ${w.reasons[entry]}` }, output: [], trace: [], events: [], records: [], steps: 0, metrics: {}, error: { message: `${entry}: ${w.reasons[entry]}` } };
      try { return runWasm(this.module, w.ok, entry, (entryArgs || []).map(a => (a === undefined ? 0 : a))); }
      catch (e) { return { kind: 'run', mode: 'wasm', outcome: { kind: 'error', message: e.message }, output: [], trace: [], events: [], records: [], steps: 0, metrics: {}, error: { message: e.message } }; }
    }
    if (mode === 'plan' && !Object.keys(this.st.plans).length) return { kind: 'run', mode, outcome: { kind: 'error', message: 'no execution plan: the pipeline stopped before plan-roots' }, output: [], trace: [], events: [], records: [], steps: 0, metrics: {}, error: { message: 'no plan' } };
    const plans = {};
    for (const [n, p] of Object.entries(this.st.plans)) plans[n] = { safepoints: p.safepoints, slotOf: p.slotOf, frameSlots: p.frameSlots };
    const r = runModule(this.module, { mode, plans, gc: opts.gc || 'off', budget: steps, entry: opts.entry, args: entryArgs, jobs: opts.jobs, recordLimit: opts.recordLimit });
    return r;
  }
  // A function from the JavaScript frontend takes its captured cells and `this` first;
  // run({ entry, args }) passes JavaScript arguments, so the rest are filled in.
  argsFor(fn, args) {
    const js = fn.meta && fn.meta.jsParams !== undefined;
    if (!js) return args;
    const lead = fn.params.length - fn.meta.jsParams;
    if (fn.params.slice(0, lead).some(p => p.type.has && p.type.has('cell'))) throw new StrataError(`${fn.name} captures variables, so it cannot be run on its own; run the function that creates it`);
    return [...Array(lead).fill(undefined), ...args];
  }
  get artifact() {
    const r = this.pipeline.resolved();
    return { kind: 'artifact', abi: 'strata-abi/1', target: r.target, relocatable: true,
      requires: { roots: String(r.roots), exceptions: String(r.exceptions), calls: 'hermesNative', runtime: 'hermes static_h f837b9d' },
      functions: Object.values(this.st.plans).map(p => ({ name: p.fn, rootSlots: p.rootSlots, frameSlots: p.frameSlots, argumentSlots: p.argSlots })),
      hash: this.module ? this.module.hash() : null, program: this };
  }
  yamlTag() { return `[Program ${this.name}: ${this.ok ? 'ok' : this.diagnostics.filter(d => d.severity === 'error').length + ' errors'}, ${this.module ? this.module.functions.size : 0} functions]`; }
  toJSON() { return { kind: 'program', name: this.name, ok: this.ok, summary: this.summary() }; }
}

function extractFn(text, name) {
  const start = text.indexOf(`fn ${name}(`);
  if (start < 0) return text;
  const end = text.indexOf('\n}', start);
  return text.slice(start, end + 2);
}

// ---------------------------------------------------------------- semantics and profiles
// A profile names which operation sets a program may use and which observations a
// correctness claim preserves. The specification runs a program under a profile.

const PROFILES = {
  core: { sets: ['core'], observes: ['output', 'outcome'] },
  'js-sync': { sets: ['core', 'js.value', 'js.object', 'js.function'], observes: ['output', 'outcome', 'thrown value', 'object identity', 'heap mutation seen later'] },
  'js-async': { sets: ['core', 'js.value', 'js.object', 'js.function', 'js.control'], observes: ['output', 'outcome', 'thrown value', 'object identity', 'heap mutation seen later', 'job order'] },
};
PROFILES.js = PROFILES['js-async'];

class Profile {
  constructor(name, spec) { this.name = name; this.sets = spec.sets; this.observes = spec.observes; Object.freeze(this); }
  le(o) { return this.sets.every(s => o.sets.includes(s)); }
  admits(opName) { return this.sets.includes(SET_OF(opName)); }
  and(other) { const o = typeof other === 'string' ? profile(other) : other; return new Profile(`${this.name}+${o.name}`, { sets: [...new Set([...this.sets, ...o.sets])], observes: [...new Set([...this.observes, ...o.observes])] }); }
  check(module) {
    const bad = [];
    for (const fn of module.functions.values()) for (const b of fn.blocks) for (const o of [...b.ops, ...(b.term && b.term.kind === 'invoke' ? [b.term.op] : [])]) if (!this.admits(o.op)) bad.push(`${o.op} in ${fn.name}/${b.name}`);
    return bad;
  }
  toString() { return this.name; }
  yamlTag() { return `profile ${this.name} (${this.sets.join(', ')})`; }
}
function profile(name) {
  if (name instanceof Profile) return name;
  if (!PROFILES[name]) throw new StrataError(`unknown profile ${name}; known: ${Object.keys(PROFILES).join(', ')}`);
  return new Profile(name, PROFILES[name]);
}
profile.define = (name, spec) => { PROFILES[name] = { sets: spec.admits || spec.sets, observes: spec.observes || ['output', 'outcome'] }; return profile(name); };

class Semantics {
  constructor(p = 'js') { this.prof = profile(p); Object.freeze(this); }
  profile(p) { return new Semantics(p); }
  coverage() { return { owned: this.prof.sets, delegated: [], note: 'every reference step in this profile is implemented by the engine itself' }; }
  run(target, opts = {}) {
    const module = toModule(target);
    const bad = this.prof.check(module);
    if (bad.length) return { kind: 'run', mode: 'spec', outcome: { kind: 'error', message: `outside profile ${this.prof.name}: ${bad[0]}` }, output: [], trace: [], events: [], records: [], steps: 0, metrics: {}, error: { message: `outside profile ${this.prof.name}: ${bad.slice(0, 3).join('; ')}` } };
    return runModule(module, { mode: 'spec', budget: opts.steps || 200000, args: opts.args, entry: opts.entry, jobs: opts.jobs });
  }
  yamlTag() { return `semantics (${this.prof.name})`; }
}

function toModule(target) {
  if (target instanceof Module) return target;
  if (target instanceof Fn) return new Module([target], { main: target.name });
  if (target && target.kind === 'program') return target.module;
  if (target && target.kind === 'source') return compile(pipeline().passes([STD_PASSES.frontend, STD_PASSES.promoteCells, STD_PASSES.verify]), target).module;
  if (typeof target === 'string') return toModule(source.text(target));
  throw new StrataError('run takes a function, a module, a program or a source');
}

function refines(target, src, opts = {}) {
  const run = x => (x && x.kind === 'run' ? x : x && x.kind === 'program' ? x.run({ mode: opts.mode || 'spec', gc: opts.gc }) : new Semantics(opts.profile || 'js').run(x, opts));
  const a = run(target), b = run(src);
  const eq = observeEqual(a, b);
  return { ok: eq.equal === true, method: 'one behaviour each (the engine is deterministic)', detail: eq, target: a.output, source: b.output };
}

// ---------------------------------------------------------------- the engine
// One engine owns one execution domain: a heap, the job queues, and the code it admitted.
// Admission is a check before any code runs; code stays until the engine closes.

class AdmissionError extends Error { constructor(m, d) { super(m); this.name = 'AdmissionError'; Object.assign(this, d); } }

class Engine {
  constructor(opts = {}) {
    this.opts = opts; this.mode = opts.mode || 'spec';
    this.machine = new Machine(new Module([]), { mode: this.mode, gc: opts.gc || 'off', budget: opts.budget || 2000000, recordLimit: 0 });
    this.units = []; this.closed = false; this.state = 'ready';
    this.require = opts.strategies || null;
  }
  check() { if (this.closed) { const e = new Error('the engine is closed'); e.name = 'EngineClosed'; throw e; } }
  admit(x) {
    this.check();
    const art = x && x.kind === 'artifact' ? x : x && x.kind === 'program' ? x.artifact : null;
    if (!art) throw new AdmissionError('admit takes a program or an artifact', { reason: 'not an artifact', ranCode: false });
    const prog = art.program;
    if (!prog.ok) throw new AdmissionError(`${prog.name} did not compile: ${(prog.diagnostics.find(d => d.severity === 'error') || {}).message}`, { reason: 'compile errors', ranCode: false });
    if (this.require) for (const [k, v] of Object.entries(this.require)) if (art.requires[k] && String(v) !== art.requires[k] && !art.requires[k].startsWith(String(v))) throw new AdmissionError(`strategy mismatch: ${k} is ${art.requires[k]} in the artifact and ${v} in the engine`, { reason: 'strategy mismatch', field: k, ranCode: false });
    const unit = this.units.length + 1, prefix = `u${unit}.`;
    const rename = new Map(prog.module.names().map(n => [n, prefix + n]));
    const fns = [...prog.module.functions.values()].map(f => {
      const c = f.clone(); c.name = rename.get(f.name);
      for (const b of c.blocks) for (const o of [...b.ops, ...(b.term && b.term.kind === 'invoke' ? [b.term.op] : [])]) if (o.attrs && o.attrs.callee && rename.has(o.attrs.callee)) o.attrs.callee = rename.get(o.attrs.callee);
      return c;
    });
    for (const f of fns) this.machine.module.functions.set(f.name, f);
    for (const [n, p] of Object.entries(prog.st.plans)) {
      const sp = {}; for (const [k, v] of Object.entries(p.safepoints)) sp[k.replace(n + '/', prefix + n + '/')] = v;
      this.machine.plans[prefix + n] = { safepoints: sp, slotOf: p.slotOf, frameSlots: p.frameSlots };
    }
    this.units.push({ unit, name: prog.name, main: prefix + prog.module.main, functions: fns.length, retained: true, codeBytes: fns.reduce((s, f) => s + f.blocks.reduce((k, b) => k + 16 * (b.ops.length + 1), 0), 0) });
    return { kind: 'code', id: unit, name: prog.name, yamlTag: () => `code #${unit} ${prog.name}` };
  }
  evaluateScript(code) {
    this.check();
    const u = this.units[(code.id || code) - 1]; if (!u) throw new Error(`no code ${code.id || code}`);
    this.state = 'executing';
    const outcome = this.machine.runMain(u.main);
    this.state = 'ready';
    return { kind: 'evaluation', state: outcome.kind === 'normal' ? 'fulfilled' : outcome.kind === 'throw' ? 'rejected' : outcome.kind, value: outcome.value !== undefined ? this.machine.display(outcome.value) : undefined, error: outcome.message };
  }
  runJobs({ budget } = {}) { this.check(); const n = budget ? (budget.n !== undefined ? budget.n : budget) : 10000; const r = this.machine.runJobs(n); return { ran: r.ran, remaining: r.remaining !== undefined ? r.remaining : this.machine.microtasks.length + this.machine.timers.length }; }
  run(program, opts = {}) {
    const code = this.admit(program);
    const ev = this.evaluateScript(code);
    const jobsOut = this.runJobs({ budget: opts.budget || jobs(10000) });
    return { state: ev.state, output: this.output(), jobsRun: jobsOut.ran, remaining: jobsOut.remaining, error: ev.error, collections: this.machine.metrics.collections };
  }
  output() { return this.machine.output.slice(); }
  metrics() {
    const m = this.machine.metrics;
    return { code: { admittedUnits: this.units.length, codeBytes: this.units.reduce((s, u) => s + u.codeBytes, 0), retained: this.units.filter(u => u.retained).length },
      heap: { objects: this.machine.heap.size, allocations: m.allocations }, jobs: { ran: m.jobs, pending: this.machine.microtasks.length + this.machine.timers.length }, collections: m.collections, steps: this.machine.steps };
  }
  snapshot() { return { state: this.closed ? 'closed' : this.state, units: this.units.map(({ unit, name, functions, retained }) => ({ unit, name, functions, retained })), globals: [...this.machine.globals.keys()] }; }
  close() { this.check(); this.closed = true; this.state = 'closed'; return 'closed: runtime destroyed, then code released'; }
  yamlTag() { return `[Engine ${this.closed ? 'closed' : this.units.length + ' units'}]`; }
}

// ---------------------------------------------------------------- lifecycle state machines
// Labelled transition systems; a product synchronizes machines on the labels they share.

class LTS {
  constructor(name, trans = new Map(), current = null, finals = [], initial = null) { this.name = name; this.trans = trans; this.current = current; this.finals = finals; this.initial = initial; Object.freeze(this); }
  state(s) { const tr = new Map(this.trans); if (!tr.has(s)) tr.set(s, new Map()); return new LTS(this.name, tr, s, this.finals, this.initial || s); }
  on(label, to) {
    const tr = new Map([...this.trans].map(([k, v]) => [k, new Map(v)]));
    tr.get(this.current).set(label, to); if (!tr.has(to)) tr.set(to, new Map());
    return new LTS(this.name, tr, this.current, this.finals, this.initial);
  }
  final(...ss) { return new LTS(this.name, this.trans, this.current, [...this.finals, ...ss], this.initial); }
  retarget(s, label, to) { return this.state(s).on(label, to); }
  alphabet() { const a = new Set(); for (const m of this.trans.values()) for (const l of m.keys()) a.add(l); return a; }
  yamlTag() { return `machine ${this.name} (${this.trans.size} states)`; }
}
const machine = name => new LTS(name);
machine.product = (...ms) => ({ kind: 'product', machines: ms, invariants: [], invariant(name, pred) { return { ...this, invariants: [...this.invariants, { name, pred }] }; }, yamlTag() { return `product of ${ms.map(m => m.name).join(', ')}`; } });

function checkMachine(prod, { depth = 12 } = {}) {
  const ms = prod.machines, alpha = ms.map(m => m.alphabet());
  const labels = new Set(alpha.flatMap(a => [...a]));
  const start = ms.map(m => m.initial), key = s => s.join('|');
  const seen = new Map([[key(start), null]]), queue = [[start, []]];
  let transitions = 0;
  const view = s => Object.fromEntries(ms.map((m, i) => [m.name, s[i]]));
  while (queue.length) {
    const [s, path] = queue.shift();
    for (const inv of prod.invariants) if (!inv.pred(view(s))) return { ok: false, violated: inv.name, trace: path, state: view(s), states: seen.size };
    if (path.length >= depth) continue;
    for (const l of labels) {
      const next = s.slice(); let possible = true, moved = false;
      ms.forEach((m, i) => {
        if (!alpha[i].has(l)) return;
        const to = m.trans.get(s[i]) && m.trans.get(s[i]).get(l);
        if (to === undefined) possible = false; else { next[i] = to; moved = true; }
      });
      if (!possible || !moved) continue;
      transitions++;
      if (!seen.has(key(next))) { seen.set(key(next), s); queue.push([next, [...path, `${l} → ${ms.map((m, i) => next[i]).join(', ')}`]]); }
    }
  }
  return { ok: true, states: seen.size, transitions };
}

// ---------------------------------------------------------------- laws, generators, shrinking
// A law is a property checked on generated inputs; a failure comes back with the
// smallest counterexample the shrinker found.

function sampleBehaviour(r) {
  const pickSome = list => list.filter(() => r.chance(0.3));
  if (r.chance(0.08)) return fx.unknown;
  return new Behaviour({ reads: pickSome(USER_RESOURCES), writes: pickSome(USER_RESOURCES), fresh: r.chance(0.3), throws: r.chance(0.3), diverges: r.chance(0.15), callsUser: r.chance(0.1), host: r.chance(0.1) ? ['print'] : [] });
}

const law = {
  vectorSpace(unit, { samples = 1000, seed = 1 } = {}) {
    const r = rng(seed);
    for (let i = 0; i < samples; i++) {
      const a = unit(r.int(-1000, 1000)), b = unit(r.int(-1000, 1000)), c = unit(r.int(-1000, 1000)), k = r.int(-9, 9);
      if (!a.add(b).add(c).eq(a.add(b.add(c))) || !a.add(b).eq(b.add(a)) || !a.add(b).mul(k).eq(a.mul(k).add(b.mul(k)))) return { name: `vectorSpace(${unit.unitName})`, ok: false, samples: i + 1, counterexample: { a, b, c, k } };
    }
    return { name: `vectorSpace(${unit.unitName})`, ok: true, samples };
  },
  lattice(L, { samples = 2000, seed = 1, universe } = {}) {
    // Join-semilattice laws by sampling: commutative, associative, idempotent, and the
    // order agreeing with join (a ⊑ b exactly when a ⊔ b = b). Meet absorption if there is a meet.
    const r = rng(seed);
    const isTypes = L === t || L.parse || (L && L.name === 'types');
    const J = isTypes ? (a, b) => a.join(b) : L.join, LE = isTypes ? (a, b) => a.le(b) : L.le, EQ = isTypes ? (a, b) => a.eq(b) : L.eq;
    const M = isTypes ? (a, b) => a.meet(b) : L.meet;
    const show = isTypes ? String : (L.show || String);
    let sample;
    if (isTypes) sample = () => Type.of(r.int(0, (1 << KINDS.length) - 1));
    else if (L.name === 'powerset') { const U = [...(universe || L.universe || ['a', 'b', 'c', 'd'])]; sample = () => new Set(U.filter(() => r.chance(0.5))); }
    else if (L.name === 'flat') { const vs = L.values.length ? L.values : [0, 1, 2]; sample = () => (r.chance(0.15) ? L.BOT : r.chance(0.15) ? L.TOP : r.pick(vs)); }
    else if (L.name === 'interval') sample = () => (r.chance(0.1) ? null : (x => [x, x + r.int(0, 20)])(r.int(-20, 20)));
    else if (L.sample) sample = () => L.sample(r);
    else throw new StrataError(`law.lattice: no way to sample ${L.name || 'this lattice'}; give it a sample(rng) function`);
    const name = `lattice(${isTypes ? 'types' : L.name})`;
    for (let i = 0; i < samples; i++) {
      const a = sample(), b = sample(), c = sample();
      const checks = [['commutative', EQ(J(a, b), J(b, a))], ['associative', EQ(J(J(a, b), c), J(a, J(b, c)))], ['idempotent', EQ(J(a, a), a)],
        ['order agrees with join', LE(a, b) === EQ(J(a, b), b)]];
      if (M) checks.push(['meet absorbs join', EQ(M(a, J(a, b)), a)]);
      const bad = checks.find(([, ok]) => !ok);
      if (bad) return { name, ok: false, samples: i + 1, counterexample: { law: bad[0], a: show(a), b: show(b), c: show(c) } };
    }
    return { name, ok: true, samples };
  },
  join(F = fx, { samples = 2000, seed = 1 } = {}) {
    const r = rng(seed);
    for (let i = 0; i < samples; i++) {
      const a = sampleBehaviour(r), b = sampleBehaviour(r), c = sampleBehaviour(r);
      const bad = [['associative', a.join(b).join(c).eq(a.join(b.join(c)))], ['commutative', a.join(b).eq(b.join(a))], ['idempotent', a.join(a).eq(a)],
        ['unit none', a.join(fx.none).eq(a)], ['top unknown', a.join(fx.unknown).eq(fx.unknown)]].find(([, ok]) => !ok);
      if (bad) return { name: 'join(fx)', ok: false, samples: i + 1, counterexample: { law: bad[0], a: String(a), b: String(b), c: String(c) } };
    }
    return { name: 'join(fx)', ok: true, samples, note: 'associative, commutative, idempotent; none is the unit, unknown the top' };
  },
  antitone(P = null, { samples = 5000, seed = 1 } = {}) {
    const r = rng(seed);
    for (let i = 0; i < samples; i++) {
      const a = sampleBehaviour(r), b = a.join(sampleBehaviour(r));
      const pa = derivePermissions(a), pb = derivePermissions(b);
      const bad = PERMS.find(k => PERM_RANK(pb[k]) > PERM_RANK(pa[k]));
      if (bad) return { name: 'antitone(perm)', ok: false, samples: i + 1, counterexample: { permission: bad, smaller: String(a), larger: String(b), smallerSays: pa[bad], largerSays: pb[bad] } };
    }
    return { name: 'antitone(perm)', ok: true, samples, note: 'more behaviour never grants a permission' };
  },
  monotone(an, { samples = 500, seed = 1, corpus } = {}) {
    const r = rng(seed);
    const fns = (corpus || [gen.coreIR({ seed }), gen.coreIR({ seed: seed + 1 })]).map(x => (x instanceof Fn ? x : toModule(x).fn(toModule(x).main)));
    const rule = an.edgeRule || edgeRules.substituteBlockArgs();
    for (let i = 0; i < samples; i++) {
      const fn = r.pick(fns), b = r.pick(fn.blocks), universe = fn.values();
      const x = new Set(universe.filter(() => r.chance(0.3))), y = new Set([...x, ...universe.filter(() => r.chance(0.3))]);
      const f = s => (an.opTransfer ? b.ops.slice().reverse().reduce((acc, o) => an.opTransfer(o, acc, { fn, block: b }), s) : livenessBlock(fn, b, s, () => new Set(), rule));
      const fx1 = f(x), fy = f(y);
      if (![...fx1].every(v => fy.has(v))) return { name: `monotone(${an.name})`, ok: false, samples: i + 1, counterexample: { block: `${fn.name}/${b.name}`, x: [...x].sort(), y: [...y].sort(), fx: [...fx1].sort(), fy: [...fy].sort(), violation: 'x ⊑ y but f(x) ⋢ f(y)' } };
    }
    return { name: `monotone(${an.name})`, ok: true, samples };
  },
  refines(target, { corpus = [], samples = 0, seed = 1, mode, gc = 'stress', pipeline: base } = {}) {
    const items = [...corpus.map(c => (typeof c === 'string' ? source.text(c) : c))];
    for (let i = 0; i < samples; i++) items.push(gen.js({ seed: seed + i }));
    const name = target instanceof Rewrite ? `refines(${target.name})` : target && target.kind === 'rewrites' ? `refines(${target.names.join(' + ') || 'no rewrites'})`
      : target instanceof Pipeline ? 'refines(pipeline plan)' : `refines(${target})`;
    let checked = 0;
    for (const item of items) {
      const verdict = refinesOne(target, item, { mode, gc, base });
      checked++;
      if (!verdict.ok) {
        let minimized = null;
        if (item.statements) {
          const small = shrink(item.statements, sts => !refinesOne(target, gen.fromStatements(sts), { mode, gc, base }).ok);
          minimized = gen.fromStatements(small).text;
        }
        return { name, ok: false, samples: checked, counterexample: { source: item.text, before: verdict.before, after: verdict.after, detail: verdict.detail }, minimized };
      }
    }
    return { name, ok: true, samples: checked, note: 'spec run before and after compared observation by observation' };
  },
  idempotent(set = rewrites.canonical(), { corpus, seed = 1, samples = 50 } = {}) {
    const items = corpus || Array.from({ length: samples }, (_, i) => gen.coreIR({ seed: seed + i }));
    for (const item of items) {
      const fns = item instanceof Fn ? [item] : [...toModule(item).functions.values()];
      for (const f0 of fns) {
        const once = f0.clone(); runRewrites(once, set);
        const twice = once.clone(); runRewrites(twice, set);
        if (once.hash() !== twice.hash()) return { name: 'idempotent(rewrites)', ok: false, counterexample: { fn: f0.name, once: printFn(once), twice: printFn(twice) } };
      }
    }
    return { name: 'idempotent(rewrites)', ok: true, samples: items.length };
  },
  roundTrip({ samples = 100, seed = 1 } = {}) {
    for (let i = 0; i < samples; i++) {
      const f = gen.coreIR({ seed: seed + i });
      const back = parseIR(printFn(f));
      if (back.hash() !== f.hash()) return { name: 'roundTrip(text)', ok: false, samples: i + 1, counterexample: { printed: printFn(f), reparsed: printFn(back) } };
      const viaJSON = fnFromJSON(JSON.parse(JSON.stringify(fnToJSON(f))));
      if (viaJSON.hash() !== f.hash()) return { name: 'roundTrip(json)', ok: false, samples: i + 1 };
    }
    return { name: 'roundTrip(text and JSON)', ok: true, samples };
  },
  variant(variant, general, { samples = 3000, seed = 1, values } = {}) {
    const v = typeof variant === 'string' ? lookupOp(variant) : variant.def || variant, gdef = typeof general === 'string' ? lookupOp(general) : general.def || general;
    const r = rng(seed), m = new Machine(new Module([]));
    const pool = values || [0, -0, 1, -1, 0.5, 2 ** 31 - 1, -(2 ** 31), 2 ** 53, NaN, Infinity, -Infinity, 1e-300, 3, 7];
    for (let i = 0; i < samples; i++) {
      const args = v.operands.map(ty => (ty.le(t.number) ? (ty.le(t.int32) ? r.int(-2147483648, 2147483647) : r.pick(pool)) : ty.le(t.boolean) ? r.chance(0.5) : r.pick(pool)));
      let a, b;
      try { a = v.step(m, args, { attrs: {} }); } catch (e) { a = 'throws'; }
      try { b = gdef.step(m, args, { attrs: {} }); } catch (e) { b = 'throws'; }
      if (!Object.is(a, b)) return { name: `variant(${v.name} of ${gdef.name})`, ok: false, samples: i + 1, counterexample: { args, variant: a, general: b } };
    }
    return { name: `variant(${v.name} of ${gdef.name})`, ok: true, samples, note: `operands drawn from ${v.operands.join(', ')}` };
  },
  declared(set, opts = {}) {
    const out = [];
    for (const d of set.defs.values()) {
      if (d.laws.commutative) out.push(law.algebra(d, 'commutative', opts));
      if (d.laws.associative) out.push(law.algebra(d, 'associative', opts));
    }
    return { name: `declared(${set.name})`, ok: out.every(x => x.ok), results: out };
  },
  algebra(d, which, { samples = 2000, seed = 1 } = {}) {
    const r = rng(seed), m = new Machine(new Module([]));
    const val = () => (d.operands[0].le(t.int32) ? r.int(-2147483648, 2147483647) : r.pick([0.1, 0.2, 0.3, 1e16, -1e16, 1, 3, -0, 0.5]));
    for (let i = 0; i < samples; i++) {
      const a = val(), b = val(), c = val(), f = (x, y) => d.step(m, [x, y], { attrs: {} });
      const ok = which === 'commutative' ? Object.is(f(a, b), f(b, a)) : Object.is(f(f(a, b), c), f(a, f(b, c)));
      if (!ok) return { name: `${which}(${d.name})`, ok: false, samples: i + 1, counterexample: { a, b, c, left: which === 'commutative' ? f(a, b) : f(f(a, b), c), right: which === 'commutative' ? f(b, a) : f(a, f(b, c)) } };
    }
    return { name: `${which}(${d.name})`, ok: true, samples };
  },
};

function refinesOne(target, item, { mode, gc, base } = {}) {
  const p0 = (base || pipeline()).rewrites(rewrites.none());
  const before = compile(p0, item).run({ mode: 'spec' });
  let after;
  if (target instanceof Rewrite || (target && target.kind === 'rewrites')) after = compile(p0.rewrites(target instanceof Rewrite ? rewriteSet(target) : target), item).run({ mode: 'spec' });
  else if (target instanceof Pipeline) after = compile(target, item).run({ mode: mode || 'plan', gc });
  else if (target instanceof Strategy) after = compile(p0.roots(target), item).run({ mode: 'plan', gc });
  else throw new StrataError('refines takes a rewrite, a rewrite set, a pipeline or a root strategy');
  if (before.outcome.kind === 'error') return { ok: true, skipped: true };
  const eq = observeEqual(after, before);
  return { ok: eq.equal === true, before: before.output.concat(before.outcome.kind === 'throw' ? ['(uncaught ' + before.outcome.display + ')'] : []), after: after.output.concat(after.outcome.kind === 'throw' ? ['(uncaught ' + after.outcome.display + ')'] : after.outcome.kind === 'error' ? ['(error: ' + after.outcome.message + ')'] : []), detail: eq };
}

// Delta debugging, one statement at a time: drop each statement while the failure stays.
function shrink(items, fails) {
  let cur = items.slice(), changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < cur.length; i++) {
      const trial = cur.slice(0, i).concat(cur.slice(i + 1));
      if (trial.length && fails(trial)) { cur = trial; changed = true; break; }
    }
  }
  return cur;
}

const gen = {
  // Random numeric core IR: arithmetic, a diamond, a bounded loop, prints.
  coreIR({ seed = 1, size = 6 } = {}) {
    const r = rng(seed);
    return fnBuilder(`gen${seed}`, { a: t.number, b: t.number }, t.number, (f, { a, b }) => {
      const pickOp = () => r.pick(['num.add', 'num.sub', 'num.mul']);
      let vals = [a, b];
      f.entry($ => {
        for (let i = 0; i < r.int(1, size); i++) vals.push($.op(pickOp(), r.pick(vals), r.chance(0.3) ? $.const(r.int(-3, 9)) : r.pick(vals)));
        const c = $.op('num.lt', r.pick(vals), r.pick(vals));
        $.branch(c, f.to('left', r.pick(vals)), f.to('right', r.pick(vals)));
      });
      f.block('left', { x: t.number }, ($, { x }) => $.jump(f.to('loop', $.const(0), $.op(pickOp(), x, $.const(r.int(1, 5))))));
      f.block('right', { y: t.number }, ($, { y }) => $.jump(f.to('loop', $.const(0), y)));
      f.block('loop', { i: t.number, acc: t.number }, ($, { i, acc }) => $.branch($.op('num.lt', i, $.const(r.int(1, 4))), f.to('body', i, acc), f.to('done', acc)));
      f.block('body', { i: t.number, acc: t.number }, ($, { i, acc }) => {
        const nacc = $.op(pickOp(), acc, r.chance(0.5) ? i : $.const(r.int(1, 3)));
        if (r.chance(0.5)) $.op('host.print', nacc);
        $.jump(f.to('loop', $.op('num.add', i, $.const(1)), nacc));
      });
      f.block('done', { z: t.number }, ($, { z }) => { $.op('host.print', z); $.ret(z); });
    });
  },
  // Random JavaScript statements over a few templates, kept as a list so they can shrink.
  js({ seed = 1, size = 7 } = {}) {
    const r = rng(seed), sts = [];
    sts.push('let cell = { n: 0 };');
    sts.push(`const r = { get x() { cell.n += 1; ${r.chance(0.5) ? 'throw cell;' : 'return cell.n;'} } };`);
    const pool = [
      () => `try { r.x; } catch (e) { print('caught', e === cell, cell.n); }`,
      () => `print(cell.n + ${r.int(1, 9)});`,
      () => `let k${r.int(0, 99)} = [1, 2, 3].length + cell.n;`,
      () => `for (let i = 0; i < ${r.int(1, 4)}; i++) { cell.n = cell.n + i; }`,
      () => `const f${r.int(0, 99)} = () => cell.n * 2; print(f${0}());`.replace(/f(\d+) = /, 'f0 = '),
      () => `queueMicrotask(() => print('job', cell.n));`,
      () => `if (cell.n > ${r.int(0, 3)}) { print('big'); } else { print('small'); }`,
      () => `try { r.x; print('no throw'); } finally { print('finally', cell.n); }`,
    ];
    for (let i = 0; i < size; i++) sts.push(r.pick(pool)());
    return gen.fromStatements(sts);
  },
  fromStatements(sts) { return { kind: 'source', lang: 'js', name: 'generated.js', text: sts.join('\n'), statements: sts.slice() }; },
  values() { return [0, -0, 1, -1, 0.5, NaN, Infinity, 2 ** 31, '', 'a', '1', true, false, null, undefined]; },
};

// ---------------------------------------------------------------- designs, objectives, search

class Param { constructor(values, opts = {}) { this.values = values; this.def = opts.default; this.when = opts.when || null; Object.freeze(this); } }
const param = {
  choice: (values, opts = {}) => new Param(values, opts),
  range: (lo, hi, { step = 1, ...opts } = {}) => { const v = []; for (let x = lo; x <= hi + 1e-9; x += step) v.push(round(x, 6)); return new Param(v, opts); },
};

class Design {
  constructor(params, fn, opts = {}) { this.params = params; this.fn = fn; this.constraints = opts.constraints || []; this.objective = opts.objective || null; this.kind = 'design'; Object.freeze(this); }
  defaults() { const o = {}; for (const [k, p] of Object.entries(this.params)) if (!p.when || p.when(o)) o[k] = p.def !== undefined ? p.def : p.values[(p.values.length - 1) >> 1]; return o; }
  points() {
    let out = [{}];
    for (const [k, p] of Object.entries(this.params)) {
      const next = [];
      for (const pt of out) { if (p.when && !p.when(pt)) next.push(pt); else for (const v of p.values) next.push({ ...pt, [k]: v }); }
      out = next;
    }
    return out.filter(pt => this.constraints.every(c => c(pt, this)));
  }
  size() {
    const raw = Object.values(this.params).reduce((n, p) => n * p.values.length, 1);
    return { raw, points: this.points().length };
  }
  at(pt = {}) { return this.fn({ ...this.defaults(), ...pt }); }
  where(pred) { return new Design(this.params, this.fn, { constraints: [...this.constraints, pred], objective: this.objective }); }
  map(f) { return new Design(this.params, p => f(this.fn(p)), { constraints: this.constraints, objective: this.objective }); }
  sample({ n = 4, seed = 1 } = {}) { const r = rng(seed), pts = this.points(); return Array.from({ length: Math.min(n, pts.length) }, () => pts.splice(Math.floor(r() * pts.length), 1)[0]); }
  yamlTag() { return `design (${this.points().length} points)`; }
}
const design = (params, fn, opts) => new Design(params, fn, opts);
const constraint = { compatible: () => (pt, d) => { const p = d.fn({ ...d.defaults(), ...pt }); return p.check().ok; } };

const METRICS = {
  steps: { dir: 'min', unit: 'steps', of: r => r.run.steps }, collections: { dir: 'min', unit: 'count', of: r => r.run.metrics.collections || 0 },
  rootSlots: { dir: 'min', unit: 'slots', of: r => r.program.metrics().rootSlots }, maxFrameSlots: { dir: 'min', unit: 'slots', of: r => r.program.metrics().maxFrameSlots },
  peakLive: { dir: 'min', unit: 'slots', of: r => r.program.metrics().peakLive }, peakRootSlots: { dir: 'min', unit: 'slots', of: r => r.run.metrics.peakRootSlots || 0 },
  rootBytes: { dir: 'min', unit: 'B', of: r => r.run.metrics.rootBytes || 0 }, compileMs: { dir: 'min', unit: 'ms', of: r => r.program.compileMs },
  ops: { dir: 'min', unit: 'count', of: r => r.program.metrics().ops }, rewritesFired: { dir: 'max', unit: 'count', of: r => r.program.metrics().rewritesFired },
};
const metric = (name, of, opts = {}) => { METRICS[name] = { dir: opts.dir || 'min', unit: opts.unit || '', of, about: opts.about }; return name; };
metric.list = () => Object.entries(METRICS).map(([k, m]) => `${k} (${m.dir}, ${m.unit})`);

const objective = {
  require: (...checks) => ({ kind: 'objective', requires: checks, then(o) { return { ...o, requires: checks, label: `${o.label}, requiring ${checks.join(', ')}` }; }, key: () => 0, label: `feasibility: ${checks.join(', ')}` }),
  minimize: m => ({ kind: 'objective', label: `minimize ${m}`, key: row => row[m] }),
  maximize: m => ({ kind: 'objective', label: `maximize ${m}`, key: row => -row[m] }),
  weighted: w => ({ kind: 'objective', label: 'weighted ' + Object.entries(w).map(([k, v]) => `${v}·${k}`).join(' + '), key: row => Object.entries(w).reduce((s, [k, v]) => s + (Array.isArray(v) ? v[0] * row[k] / (v[1] && v[1].per ? v[1].per.n || v[1].per : 1) : v * row[k]) * (METRICS[k] && METRICS[k].dir === 'max' ? -1 : 1), 0) }),
  lexicographic: list => ({ kind: 'objective', label: 'lexicographic ' + list.map(x => (Array.isArray(x) ? x[0] : x)).join(' then '), compare: (a, b) => {
    for (const item of list) {
      const [k, o] = Array.isArray(item) ? item : [item, {}];
      const tol = o.tolerance ? (o.tolerance.n !== undefined ? o.tolerance.n : o.tolerance) : 0;
      const d = (a[k] - b[k]) * (METRICS[k] && METRICS[k].dir === 'max' ? -1 : 1);
      if (Math.abs(d) > tol) return d;
    }
    return 0;
  } }),
  pareto: ms => ({ kind: 'objective', label: 'pareto ' + ms.join(', '), pareto: ms }),
};

function feasible(row, requires = []) {
  for (const c of requires) {
    if (c === 'correct' && !row.correct) return { ok: false, reason: 'output differs from the specification' };
    if (c === 'admitted' && !row.admitted) return { ok: false, reason: row.reason || 'did not compile' };
    if (typeof c === 'function' && !c(row)) return { ok: false, reason: 'a requirement failed' };
  }
  return { ok: true };
}

function rank(results, obj) {
  const rows = results.rows.map(r => ({ ...r, feasible: r.feasible !== false && feasible(r, obj.requires || []).ok }));
  const ok = rows.filter(r => r.feasible), bad = rows.filter(r => !r.feasible);
  if (obj.pareto) {
    // Each metric in its own direction (rewritesFired is better larger). The frontier comes
    // first, marked onFrontier, then the dominated points, then the infeasible ones.
    const sign = m => (METRICS[m] && METRICS[m].dir === 'max' ? -1 : 1);
    const dom = (a, b) => obj.pareto.every(m => sign(m) * a[m] <= sign(m) * b[m]) && obj.pareto.some(m => sign(m) * a[m] < sign(m) * b[m]);
    const frontier = ok.filter(a => !ok.some(b => dom(b, a)));
    const rest = ok.filter(r => !frontier.includes(r));
    const ranked = [...frontier.map(r => ({ ...r, onFrontier: true })), ...rest.map(r => ({ ...r, onFrontier: false })), ...bad.map(r => ({ ...r, onFrontier: false }))];
    return { ranked, frontier: frontier.map(r => r.point) };
  }
  ok.sort(obj.compare || ((a, b) => obj.key(a) - obj.key(b)));
  const ranked = [...ok, ...bad];
  ranked.best = ok[0]; return ranked;
}
rank.disagreement = (results, a, b) => {
  const ra = rank(results, a), rb = rank(results, b);
  return { [a.label]: ra.map(r => r.point), [b.label]: rb.map(r => r.point), winners: { first: ra[0] && ra[0].point, second: rb[0] && rb[0].point }, disagree: !!(ra[0] && rb[0] && ra[0].point !== rb[0].point) };
};

const label = pt => Object.entries(pt).map(([k, v]) => `${k}=${v instanceof Quantity ? v : typeof v === 'object' && v !== null ? (v.name || JSON.stringify(v)) : v}`).join(' ');

function evaluatePoint(pipe, corpus, runOpts = {}) {
  const agg = { admitted: true, correct: true, steps: 0, collections: 0, rootSlots: 0, maxFrameSlots: 0, peakLive: 0, peakRootSlots: 0, rootBytes: 0, compileMs: 0, ops: 0, rewritesFired: 0 };
  for (const item of corpus) {
    const program = compile(pipe, item);
    if (!program.ok) { agg.admitted = false; agg.reason = (program.diagnostics.find(d => d.severity === 'error') || {}).message; continue; }
    const run = program.run({ mode: runOpts.mode || 'plan', gc: runOpts.gc || 'stress' });
    const spec = program.run({ mode: 'spec' });
    if (observeEqual(run, spec).equal !== true) agg.correct = false;
    for (const [k, m] of Object.entries(METRICS)) { const v = m.of({ program, run }); agg[k] = (k === 'maxFrameSlots' || k === 'peakLive' || k === 'peakRootSlots' || k === 'rootBytes') ? Math.max(agg[k] || 0, v) : (agg[k] || 0) + v; }
  }
  agg.compileMs = round(agg.compileMs, 2);
  return agg;
}

const search = {
  grid(d, { corpus = [], objective: obj, run } = {}) {
    obj = obj || d.objective || objective.minimize('steps');
    const rows = d.points().map(pt => ({ point: label(pt), params: pt, ...evaluatePoint(d.at(pt), corpus, run) }));
    return makeResults(rows, obj, `grid over ${Object.keys(d.params).join(', ')}`);
  },
  random(d, { budget = 6, seed = 1, ...rest } = {}) {
    const pts = d.sample({ n: budget, seed });
    const obj = rest.objective || d.objective || objective.minimize('steps');
    return makeResults(pts.map(pt => ({ point: label(pt), params: pt, ...evaluatePoint(d.at(pt), rest.corpus || [], rest.run) })), obj, `random sample of ${budget}`);
  },
};

function makeResults(rows, obj, title) {
  const ranked = rank({ rows }, obj);
  const best = Array.isArray(ranked) ? ranked.best : ranked.ranked[0];
  const columns = [{ key: 'point', label: 'point' }, { key: 'feasible', label: 'feasible' }, { key: 'admitted', label: 'admitted' }, { key: 'correct', label: 'correct' },
    ...['rootSlots', 'maxFrameSlots', 'peakLive', 'collections', 'steps', 'compileMs'].map(k => ({ key: k, label: k, unit: METRICS[k].unit }))];
  const list = Array.isArray(ranked) ? ranked : ranked.ranked;
  return { kind: 'results', title, objective: obj.label || 'objective', columns, rows: list.map(r => ({ ...r, params: undefined })), best: best ? best.point : null,
    frontier: ranked.frontier, note: `ranked by ${obj.label || 'objective'}; infeasible points last`, table() { return this.rows; } };
}

function table(rows, { title = 'table', columns } = {}) {
  const cols = columns || Object.keys(rows[0] || {}).map(k => ({ key: k, label: k }));
  return { kind: 'results', title, columns: cols.map(c => (typeof c === 'string' ? { key: c, label: c } : c)), rows, note: '' };
}

// ---------------------------------------------------------------- decision records and processes

class Decision {
  constructor(spec) { Object.assign(this, { question: '', ctx: '', opts: [], ev: [], sought: null, chosen: null, overturn: null, st: 'proposed' }, spec); Object.freeze(this); }
  _w(p) { return new Decision({ ...this, ...p }); }
  context(s) { return this._w({ ctx: s }); }
  options(o) { return this._w({ opts: o }); }
  evidence(e) { return this._w({ ev: e }); }
  counterexampleSought(s) { return this._w({ sought: s }); }
  choose(c) { return this._w({ chosen: c }); }
  overturnIf(s) { return this._w({ overturn: s }); }
  status(s) { return this._w({ st: s }); }
  check() {
    const issues = [];
    if (this.opts.length < 2) issues.push('fewer than two options compared');
    if (!this.ev.length) issues.push('no evidence');
    if (!this.sought) issues.push('no counterexample sought');
    if (!this.chosen) issues.push('nothing chosen');
    if (!this.overturn) issues.push('nothing would overturn it');
    return { ok: !issues.length, issues };
  }
  toJSON() { return { question: this.question, status: this.st, context: this.ctx, options: this.opts, evidence: this.ev, counterexampleSought: this.sought, choice: this.chosen, overturnIf: this.overturn }; }
  toYAML() { return this.toJSON(); }
}
const decision = q => new Decision({ question: q });

class Process {
  constructor(name, steps = [], meta = {}) { this.name = name; this.steps = steps; this.meta = meta; Object.freeze(this); }
  _add(kind, name, spec = {}) { return new Process(this.name, [...this.steps, { kind, name, ...spec }], this.meta); }
  step(n, s) { return this._add('step', n, s); }
  diverge(n, s) { return this._add('diverge', n, s); }
  converge(n, s) { return this._add('converge', n, s); }
  critique(n, s) { return this._add('critique', n, s); }
  loop(n, s) { return this._add('loop', n, s); }
  check({ requires = [] } = {}) {
    const produced = this.steps.flatMap(s => [].concat(s.produces || [])).map(p => (p instanceof Decision ? p.question : typeof p === 'string' ? p : p && p.name));
    const issues = requires.filter(r => !produced.includes(r)).map(r => `no step produces "${r}"`);
    for (const s of this.steps) if (s.kind === 'diverge' && !this.steps.some(c => c.kind === 'converge' && c.name === s.name)) issues.push(`"${s.name}" diverges and never converges`);
    return { ok: !issues.length, issues, steps: this.steps.length };
  }
  toYAML() { return { name: this.name, steps: this.steps.map(s => `${s.kind} ${s.name}${s.week ? ' (week ' + s.week + ')' : ''}`) }; }
}
const process_ = (name, meta) => new Process(name, [], meta || {});

// ---------------------------------------------------------------- running a preset's script

async function runScript(code, scope, { timeoutMs = 25000 } = {}) {
  const logs = [];
  const log = (...xs) => logs.push(xs.map(x => (typeof x === 'string' ? x : toYAML(x).replace(/\n/g, ' '))).join(' '));
  const sc = { ...scope, log, console: { log, warn: (...x) => log('warn:', ...x), error: (...x) => log('error:', ...x) } };
  const names = Object.keys(sc).filter(k => /^[A-Za-z_$][\w$]*$/.test(k));
  const t0 = now();
  let timer = null;
  try {
    const f = new Function(...names, '"use strict";\nreturn (async () => {\n' + code + '\n})();\n//# sourceURL=main.js');
    const value = await Promise.race([f(...names.map(k => sc[k])), new Promise((_, rej) => { timer = setTimeout(() => rej(new Error(`main.js timed out after ${timeoutMs / 1000} s`)), timeoutMs); })]);
    clearTimeout(timer);
    return { ok: true, ms: round(now() - t0, 1), value, logs };
  } catch (e) {
    clearTimeout(timer);
    const m = /main\.js:(\d+)/.exec(e.stack || '');
    return { ok: false, ms: round(now() - t0, 1), logs, error: { message: e.message, line: m ? Number(m[1]) - 2 : null, name: e.name } };
  }
}

function presetScope(files = {}, { log } = {}) {
  return {
    g, strata: root.strata, bytes, kib, mib, slots, jobs, ms, count, t,
    files: Object.freeze({ ...files }),
    source: (name = 'program.js') => {
      if (files[name] === undefined) throw new StrataError(`no file ${name} in this preset`);
      return source.text(files[name], { name });
    },
    print: (...xs) => (log ? log(...xs) : undefined),
  };
}

function classify(value) {
  if (!value || typeof value !== 'object') return { other: value };
  if (value.kind === 'program') return { program: value };
  if (value.kind === 'run') return { run: value };
  if (value.kind === 'laws') return { laws: value };
  if (value.kind === 'results') return { results: value };
  if (value.name && typeof value.ok === 'boolean' && (value.samples !== undefined || value.counterexample)) return { laws: { kind: 'laws', laws: [value] } };
  const out = {};
  for (const k of ['program', 'run', 'laws', 'results']) if (value[k]) out[k] = value[k];
  if (out.laws && Array.isArray(out.laws)) out.laws = { kind: 'laws', laws: out.laws };
  if (out.results && Array.isArray(out.results)) out.results = table(out.results);
  if (!Object.keys(out).length) out.other = value;
  else { const rest = Object.fromEntries(Object.entries(value).filter(([k]) => !['program', 'run', 'laws', 'results'].includes(k))); if (Object.keys(rest).length) out.other = rest; }
  return out;
}

// ---------------------------------------------------------------- the g namespace

const opApi = Object.assign(name => opBuilder(name), {
  narrow: narrowOp,
  opaque: (name, attrs = {}) => new OpDef({ name, variadic: true, results: [t.any], behaviour: fx.unknown, obligations: ob.join(ob.mayCollect, ob.nonlocalThrow, ob.writeBarrier), about: 'an opaque escape: behaviour unknown, every obligation assumed' }),
});
const permApi = Object.assign((op, facts) => permsOf(op, facts), {
  explain: (op, which, facts = {}) => { const p = permsOf(op, facts); return { allowed: p[which], because: p.because[which], note: which === 'erase' ? 'an unused result alone is not sufficient' : undefined }; },
  commute: (a, b) => {
    const A = (typeof a === 'string' ? lookupOp(a) : a.def || a).behaviour, B = (typeof b === 'string' ? lookupOp(b) : b.def || b).behaviour;
    const clash = [...A.writes].filter(r => B.writes.has(r) || B.reads.has(r)).concat([...B.writes].filter(r => A.reads.has(r)));
    if (A.callsUser || B.callsUser) return { allowed: false, because: 'one of them may run user code' };
    if (clash.length) return { allowed: false, because: `they conflict on ${[...new Set(clash)].join(', ')}` };
    if (A.throws && B.throws) return { allowed: false, because: 'both may throw: swapping changes which error escapes' };
    return { allowed: true, because: 'no shared resource is written' };
  },
});

const g = {
  version: VERSION,
  t, rep, fx, ob, lit,
  ops, opsets, op: opApi, opset: Object.assign((name, meta) => new OpSet(name, [], meta), { union: opsetUnion }), perm: permApi,
  contract: { table: list => list.map(d => { const x = typeof d === 'string' ? lookupOp(d) : d.def || d; const p = derivePermissions(x.behaviour); return { op: x.name, behaviour: String(x.behaviour), obligations: String(x.obligations), permissions: PERMS.filter(k => p[k] === true).join(', ') || (PERMS.some(k => p[k] !== false) ? 'conditional' : 'none') }; }) },
  resource: (name, { within } = {}) => name,
  fn: fnBuilder, module: (...fns) => new Module(fns), ir: { parse: parseIR, text: x => (x instanceof Module ? x.toString() : printFn(x)), json: { encode: x => JSON.stringify(fnToJSON(x)), decode: s => fnFromJSON(JSON.parse(s)) } },
  verify, dominators,
  semantics: () => new Semantics('js'), profile, observe: { equal: observeEqual }, refines,
  lattice, analysis: Object.assign(analysisBuilder, analyses), solve, edge: edgeRules, widen, graph,
  rewrite, rewrites, act, pass: Object.assign(pass, { ...Object.fromEntries(Object.entries(STD_PASSES)) }), pipeline, compile, source,
  promoteCells: fn => promoteCells(fn),
  roots, exceptions, representation, compat, strategy: { name: (s, n) => new Strategy(s.slot, n, s.params, s.fnImpl, s.wraps) },
  lower: { bindings: bindOps, plan: planFunction, needsRoot },
  llvm: { orc: (o = {}) => ({ name: 'llvm.orc', target: o.target || 'x86_64-linux-gnu' }), aot: (o = {}) => ({ name: 'llvm.aot', target: o.target || 'x86_64-linux-gnu', output: o.output }), check: checkLLVM },
  target: { host64: 'x86_64-linux-gnu', linuxX64: 'x86_64-linux-gnu', riscv32: 'riscv32-unknown-elf' },
  wasm: { encode: encodeWasm, eligible: wasmEligible },
  layout, limit: (name, spec) => ({ name, ...spec, check: x => { const m = spec.measure(x); return { ok: m.le(spec.max), measured: String(m), max: String(spec.max), asBytes: m.unit === 'slots' ? { measured: String(layout.host64.bytes(m)), max: String(layout.host64.bytes(spec.max)) } : undefined }; } }),
  engine: (opts) => new Engine(opts), machine, check: { machine: checkMachine },
  law, laws: list => ({ kind: 'laws', laws: list.flatMap(x => (x.results ? [x, ...x.results] : [x])) }), gen, shrink,
  design, param, constraint, metric, metrics: { list: metric.list }, objective, rank, search, table,
  decision, process: process_,
  hermes: { provider: set => ({ name: 'hermes', set }) }, reference: { provider: set => ({ name: 'reference', set }) },
  units: { bytes, kib, mib, slots, jobs, ms, count },
};

const strataApi = {
  version: VERSION, g, yaml: toYAML, runScript, presetScope, classify,
  internals: { lit, Lit, Fn, Module, t, StrataError, lookupOp, opRegistry, printFn, parseIR, Machine, runModule, analyzeFn, solveTypes, observeEqual, verify },
};

root.strata = Object.assign(root.strata || {}, strataApi);
if (typeof module !== 'undefined' && module.exports) module.exports = root.strata;
})(typeof globalThis !== 'undefined' ? globalThis : this);
