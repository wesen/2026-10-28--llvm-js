/* Strata Workbench: the Stage, the control-flow graph drawn as a drafting sheet (SVG).
   The look follows Form Skate Stage: paper ground, ink hairlines, Plex Mono labels, hatching for tone,
   one hue per overlay by meaning, a title block bottom right. */
(function (root) {
  'use strict';
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const CW = 5.75;          // Plex Mono 9.5 px advance
  const LINE = 14, HEAD = 18, PADX = 9, PADY = 5;
  const RANK_GAP = 52, COL_GAP = 34, LANE = 11;
  const r1 = v => Math.round(v * 10) / 10;
  const cut = (s, n) => (s = String(s), s.length > n ? s.slice(0, n - 1) + '…' : s);

  /** The overlays, their hue and what they show (the Show ▾ menu lists them in this order). */
  const OVERLAYS = [
    { name: 'live', hue: 'blue', label: 'Live values', about: 'values live across each op, live-in on block headers' },
    { name: 'safepoints', hue: 'amber', label: 'Safepoints', about: 'ops that may collect (contract obligation mayCollect)' },
    { name: 'types', hue: 'mut', label: 'Types', about: 'the type fact of each value' },
    { name: 'roots', hue: 'violet', label: 'Roots', about: 'root slots of the execution plan at each safepoint' },
    { name: 'path', hue: 'blue', label: 'Path', about: 'blocks and edges the last run took, visits per block' },
    { name: 'exceptional', hue: 'teal', label: 'Exceptional edges', about: 'edges a throw takes, drawn in teal' },
    { name: 'stale', hue: 'rec', label: 'Stale and missing', about: 'uses of moved objects and missing roots' },
    { name: 'iteration', hue: 'ghost', label: 'Fixed-point iteration', about: 'the block and sets of the selected iteration' },
  ];

  function lineId(cfg, b, i) {
    if (i === 'term') return (b.term && b.term.id) || `${cfg.name}/${b.name}/term`;
    const op = b.ops[i];
    return (op && op.id) || `${cfg.name}/${b.name}/${i}`;
  }

  function pathInfo(cfg, run, upto) {
    const visits = new Map(), edges = new Set(); let last = null;
    if (!run || !Array.isArray(run.records)) return { visits, edges, last };
    let prev = null;
    for (const r of run.records) {
      if (upto != null && r.n > upto) break;
      if (r.fn !== cfg.name) { if (prev && prev.fn === cfg.name && r.depth <= prev.depth) prev = null; continue; }
      if (!prev || prev.block !== r.block || prev.depth !== r.depth) {
        visits.set(r.block, (visits.get(r.block) || 0) + 1);
        if (prev && prev.depth === r.depth && prev.block !== r.block) edges.add(prev.block + '>' + r.block);
      }
      prev = r; last = r;
    }
    return { visits, edges, last };
  }
  function recLineId(cfg, r) {
    if (r == null) return null;
    if (typeof r.op === 'string' && r.op.includes('/')) return r.op;
    if (typeof r.op === 'number') return `${cfg.name}/${r.block}/${r.op}`;
    return null;
  }

  function annotations(cfg, b, opts) {
    // per line: header, ops…, term → [{ text, cls }]
    const ov = opts.overlays || new Set();
    const f = opts.facts || {}, live = f.live || {}, types = f.types || {};
    const plan = opts.plan || {};
    const sp = new Set(f.safepoints || []);
    const slotOf = new Map();
    for (const s of plan.slots || []) for (const v of s.values || []) slotOf.set(v, s.slot);
    const sps = Array.isArray(plan.safepoints) ? plan.safepoints : Object.keys(plan.safepoints || {}).map(id => Object.assign({}, plan.safepoints[id], { op: id }));
    const planAt = new Map(sps.map(p => [p.op, p]));
    const stale = new Map();
    if (opts.run && Array.isArray(opts.run.events)) for (const e of opts.run.events) {
      if (e.type !== 'stale') continue;
      const at = typeof e.at === 'string' ? e.at : e.at && e.at.fn ? `${e.at.fn}/${e.at.block}/${e.at.op}` : null;
      if (at) stale.set(at, (stale.get(at) || []).concat(e.value || e.id || e.message || 'stale'));
    }
    const step = opts.step && opts.step.block === b.name ? opts.step : null;
    const lines = [];
    // header
    const h = [];
    if (ov.has('live') && live.in && live.in[b.name] && live.in[b.name].length) h.push({ text: 'in ' + live.in[b.name].join(' '), cls: 'blue' });
    if (ov.has('types')) { const ts = (b.params || []).map(p => types[p.id] ? `${p.id}:${types[p.id]}` : '').filter(Boolean); if (ts.length) h.push({ text: ts.join(' '), cls: 'mut' }); }
    if (ov.has('iteration') && step && step.after) h.push({ text: 'in ' + (step.after.in || []).join(' '), cls: 'ghost' });
    lines.push(h);
    const opLine = (id, op) => {
      const a = [];
      if (ov.has('live') && live.across && live.across[id] && live.across[id].length) a.push({ text: '↳ ' + live.across[id].join(' '), cls: 'blue' });
      if (ov.has('safepoints') && sp.has(id)) a.push({ text: 'gc', cls: 'amber' });
      if (ov.has('types') && op && op.results) { const ts = op.results.map(r => types[r] ? `${r}:${types[r]}` : '').filter(Boolean); if (ts.length) a.push({ text: ts.join(' '), cls: 'mut' }); }
      if (ov.has('roots') && planAt.has(id)) { const p = planAt.get(id); const ro = (p.rooted || []).map(v => `${v}→s${slotOf.has(v) ? slotOf.get(v) : '?'}`); if (ro.length) a.push({ text: ro.join(' '), cls: 'violet' }); }
      if (ov.has('stale') && planAt.has(id) && (planAt.get(id).missing || []).length) a.push({ text: 'missing ' + planAt.get(id).missing.join(' '), cls: 'rec' });
      if (ov.has('stale') && stale.has(id)) { const all = stale.get(id), uniq = [...new Set(all.map(String))]; a.push({ text: 'stale ' + uniq.join(' ') + (all.length > uniq.length ? ' ×' + all.length : ''), cls: 'rec' }); }
      return a;
    };
    b.ops.forEach((op, i) => lines.push(opLine(lineId(cfg, b, i), op)));
    const t = opLine(lineId(cfg, b, 'term'), b.term && b.term.kind === 'invoke' ? b.term : null);
    if (ov.has('iteration') && step && step.after) t.push({ text: 'out ' + (step.after.out || []).join(' '), cls: 'ghost' });
    lines.push(t);
    return lines;
  }

  function layout(cfg, opts) {
    const blocks = cfg.blocks || [];
    const by = new Map(blocks.map(b => [b.name, b]));
    const succ = b => ((b.term && b.term.edges) || []).map(e => e.to).filter(n => by.has(n));
    // reachability and back edges (DFS from entry)
    const reach = new Set(), state = new Map(), back = new Set(), disc = new Map();
    const stack = [];
    const dfs = start => {
      // iterative DFS to classify back edges
      const it = [[start, 0]]; state.set(start, 1); disc.set(start, disc.size); reach.add(start); stack.push(start);
      while (it.length) {
        const top = it[it.length - 1]; const [n, k] = top; const ss = succ(by.get(n));
        if (k < ss.length) {
          top[1]++; const s = ss[k];
          if (!state.has(s)) { state.set(s, 1); disc.set(s, disc.size); reach.add(s); it.push([s, 0]); }
          else if (state.get(s) === 1) back.add(n + '>' + s);
        } else { state.set(n, 2); it.pop(); }
      }
    };
    if (by.has(cfg.entry)) dfs(cfg.entry);
    for (const b of blocks) if (!state.has(b.name)) { state.set(b.name, 1); disc.set(b.name, disc.size); dfs2(b.name); }
    function dfs2(n) { // unreachable components: order only
      const st = [n];
      while (st.length) { const x = st.pop(); state.set(x, 2); for (const s of succ(by.get(x))) if (!state.has(s)) { state.set(s, 1); disc.set(s, disc.size); st.push(s); } }
    }
    // ranks: longest path over forward edges
    const rank = new Map(); const indeg = new Map(blocks.map(b => [b.name, 0]));
    const fwd = b => succ(b).filter(s => !back.has(b.name + '>' + s) && s !== b.name);
    for (const b of blocks) for (const s of fwd(b)) indeg.set(s, indeg.get(s) + 1);
    const q = blocks.filter(b => indeg.get(b.name) === 0).map(b => b.name).sort((a, c) => disc.get(a) - disc.get(c));
    if (by.has(cfg.entry)) { const i = q.indexOf(cfg.entry); if (i > 0) { q.splice(i, 1); q.unshift(cfg.entry); } }
    for (const n of q) rank.set(n, 0);
    while (q.length) {
      const n = q.shift();
      for (const s of fwd(by.get(n))) {
        rank.set(s, Math.max(rank.get(s) || 0, rank.get(n) + 1));
        indeg.set(s, indeg.get(s) - 1); if (indeg.get(s) === 0) q.push(s);
      }
    }
    for (const b of blocks) if (!rank.has(b.name)) rank.set(b.name, 0);
    // unreachable blocks go below everything
    const maxReach = Math.max(0, ...[...reach].map(n => rank.get(n)));
    for (const b of blocks) if (!reach.has(b.name)) rank.set(b.name, maxReach + 1 + (rank.get(b.name) || 0));
    // sizes
    const geo = new Map();
    for (const b of blocks) {
      const ann = annotations(cfg, b, opts);
      const params = (b.params || []).map(p => p.id).join(', ');
      const text = [`${b.name}(${params})`, ...b.ops.map(o => o.text), (b.term && b.term.text) || ''];
      const shown = text.map((t, i) => cut(t, i === 0 ? 72 : 64));
      const annText = ann.map(a => a.map(x => x.text).join('  '));
      const annShown = annText.map(t => cut(t, 54));
      const textW = Math.max(...shown.map(t => t.length)) * CW;
      const annW = Math.max(0, ...annShown.map(t => t.length)) * CW;
      const w = Math.max(120, Math.ceil(PADX * 2 + textW + (annW ? 14 + annW : 0)));
      const h = PADY + HEAD + LINE * (b.ops.length + 1) + PADY;
      geo.set(b.name, { b, w, h, text: shown, ann, annShown, textW, rank: rank.get(b.name), x: 0, y: 0, reach: reach.has(b.name) });
    }
    // order within ranks: discovery, then one barycentre pass over forward predecessors
    const ranks = [];
    for (const g of geo.values()) (ranks[g.rank] = ranks[g.rank] || []).push(g);
    for (const r of ranks) if (r) r.sort((a, c) => disc.get(a.b.name) - disc.get(c.b.name));
    const place = () => {
      for (const r of ranks) {
        if (!r) continue;
        const total = r.reduce((s, g) => s + g.w, 0) + COL_GAP * (r.length - 1);
        let x = -total / 2;
        for (const g of r) { g.x = x; x += g.w + COL_GAP; }
      }
    };
    place();
    const preds = new Map();
    for (const b of blocks) for (const s of fwd(b)) (preds.get(s) || preds.set(s, []).get(s)).push(b.name);
    for (let pass = 0; pass < 2; pass++) {
      for (const r of ranks) {
        if (!r) continue;
        const bc = g => { const p = preds.get(g.b.name) || []; return p.length ? p.reduce((s, n) => s + geo.get(n).x + geo.get(n).w / 2, 0) / p.length : g.x + g.w / 2; };
        r.forEach(g => { g._bc = bc(g); });
        r.sort((a, c) => a._bc - c._bc);
      }
      place();
    }
    let y = 0;
    for (const r of ranks) { if (!r) continue; const h = Math.max(...r.map(g => g.h)); for (const g of r) g.y = y; y += h + RANK_GAP; }
    return { geo, back, reach, rank };
  }

  function edgeList(cfg) {
    const out = [];
    for (const b of cfg.blocks || []) {
      const es = (b.term && b.term.edges) || [];
      es.forEach((e, k) => out.push({ from: b.name, to: e.to, kind: e.kind || 'jump', args: e.args || [], k, n: es.length }));
    }
    return out;
  }

  /** draw(el, opts) → { width, height } and the sheet in el. opts: cfg, facts, plan, run, step, overlays, selection,
   *  current (line id to mark), upto (record n), zoom, fn, level, title. */
  function draw(el, opts) {
    const cfg = opts.cfg;
    if (!cfg || !cfg.blocks || !cfg.blocks.length) { el.innerHTML = ''; return { width: 0, height: 0 }; }
    const ov = opts.overlays || new Set();
    const L = layout(cfg, opts);
    const { geo, back } = L;
    const all = [...geo.values()];
    let minX = Math.min(...all.map(g => g.x)), maxX = Math.max(...all.map(g => g.x + g.w));
    const maxY = Math.max(...all.map(g => g.y + g.h));
    const edges = edgeList(cfg).filter(e => geo.has(e.to));
    // lanes: back edges on the left, long forward edges on the right
    let leftLanes = 0, rightLanes = 0;
    for (const e of edges) {
      const a = geo.get(e.from), t = geo.get(e.to);
      e.back = back.has(e.from + '>' + e.to) || e.from === e.to || t.rank <= a.rank;
      if (e.back) e.lane = leftLanes++;
      else if (t.rank - a.rank > 1) e.lane = rightLanes++;
    }
    const marginL = 30 + leftLanes * LANE, marginR = 30 + rightLanes * LANE, marginT = 34;
    const shiftX = marginL - minX;
    for (const g of all) { g.x += shiftX; g.y += marginT; }
    minX += shiftX; maxX += shiftX;
    // incoming forward edges per target, for spreading the arrival points
    const inc = new Map();
    for (const e of edges) if (!e.back) (inc.get(e.to) || inc.set(e.to, []).get(e.to)).push(e);
    for (const [, list] of inc) { list.sort((p, q) => (geo.get(p.from).x - geo.get(q.from).x) || p.k - q.k); list.forEach((e, j) => { e.j = j; e.m = list.length; }); }
    const path = pathInfo(cfg, opts.run, opts.upto);
    const tb = { w: 236, rows: 5 };
    const sheetW = Math.max(maxX + marginR, tb.w + 40, 520);
    const sheetH = Math.max(maxY + marginT + 40 + tb.rows * 15 + 16, 300);
    const zoom = opts.zoom || 1;
    const parts = [];
    const hueOf = { blue: 's-blue', amber: 's-amber', violet: 's-violet', teal: 's-teal', rec: 's-rec', ghost: 's-ghost', mut: 's-mut', ink: 's-ink' };
    parts.push(`<svg class="sheet" xmlns="http://www.w3.org/2000/svg" width="${r1(sheetW * zoom)}" height="${r1(sheetH * zoom)}" viewBox="0 0 ${r1(sheetW)} ${r1(sheetH)}" role="img" aria-label="Control-flow graph of ${esc(cfg.name)}">`);
    parts.push(`<defs>
<pattern id="st-grid" patternUnits="userSpaceOnUse" width="20" height="20"><path d="M20 0H0V20" fill="none" class="s-grid" stroke-width="0.6"/></pattern>
<pattern id="st-major" patternUnits="userSpaceOnUse" width="100" height="100"><rect width="100" height="100" fill="url(#st-grid)"/><path d="M100 0H0V100" fill="none" class="s-major" stroke-width="0.6"/></pattern>
<pattern id="st-hatch" patternUnits="userSpaceOnUse" width="6" height="6"><path d="M-1,7 L7,-1 M-1,1 L1,-1 M5,7 L7,5" fill="none" class="s-shadow" stroke-width="0.6"/></pattern>
${['ink', 'mut', 'blue', 'teal', 'rec', 'ghost', 'acc'].map(h => `<marker id="st-arrow-${h}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 1L10 5L0 9z" class="f-${h}"/></marker>`).join('')}
</defs>`);
    parts.push(`<rect class="f-bg" x="0" y="0" width="${r1(sheetW)}" height="${r1(sheetH)}"/><rect fill="url(#st-major)" x="0" y="0" width="${r1(sheetW)}" height="${r1(sheetH)}"/>`);
    // edges
    const edgeSvg = [];
    for (const e of edges) {
      const a = geo.get(e.from), t = geo.get(e.to);
      const sx = a.x + a.w * (e.k + 1) / (e.n + 1), sy = a.y + a.h;
      let d, lx = sx + 4, ly = sy + 11;
      if (e.back) {
        const laneX = minX - 14 - e.lane * LANE;
        const ty = t.y + HEAD / 2 + PADY;
        d = `M${r1(sx)} ${r1(sy)}V${r1(sy + 10 + (e.lane % 3) * 3)}H${r1(laneX)}V${r1(ty)}H${r1(t.x - 1)}`;
      } else {
        const ex = t.x + t.w * ((e.j || 0) + 1) / ((e.m || 1) + 1), ey = t.y;
        const midY = ey - 16 - (e.j || 0) * 4;
        if (t.rank - a.rank > 1) {
          const laneX = maxX + 14 + e.lane * LANE;
          d = `M${r1(sx)} ${r1(sy)}V${r1(sy + 12)}H${r1(laneX)}V${r1(midY)}H${r1(ex)}V${r1(ey - 1)}`;
        } else d = `M${r1(sx)} ${r1(sy)}V${r1(midY)}H${r1(ex)}V${r1(ey - 1)}`;
      }
      const thr = e.kind === 'throw';
      const taken = ov.has('path') && path.edges.has(e.from + '>' + e.to);
      const hue = thr ? (ov.has('exceptional') ? 'teal' : 'mut') : 'ink';
      edgeSvg.push(`<g class="edge${thr ? ' thr' : ''}" data-edge="${esc(e.from + '>' + e.to)}"><path d="${d}" fill="none" class="${hueOf[hue] || 's-ink'}" stroke-width="1"${thr ? ' stroke-dasharray="4 3"' : ''} marker-end="url(#st-arrow-${hue})"/>`
        + (taken ? `<path d="${d}" fill="none" class="s-blue" stroke-width="2" opacity="0.85"/>` : '')
        + (e.kind !== 'jump' || e.args.length ? `<text class="lbl8 ${thr && ov.has('exceptional') ? 't-teal' : 't-mut'}" x="${r1(lx)}" y="${r1(ly)}">${esc(cut((e.kind !== 'jump' ? e.kind : '') + (e.args.length ? ` (${e.args.join(', ')})` : ''), 30))}</text>` : '')
        + `</g>`);
    }
    parts.push(edgeSvg.join(''));
    // blocks
    const selId = opts.selection || null;
    const current = opts.current || (path.last ? recLineId(cfg, path.last) : null);
    for (const g of all) {
      const b = g.b, bid = `${cfg.name}/${b.name}`;
      const selected = selId === bid;
      const visits = path.visits.get(b.name) || 0;
      parts.push(`<g class="blk${g.reach ? '' : ' unreach'}" data-id="${esc(bid)}">`);
      parts.push(`<rect class="f-bg s-ink" x="${r1(g.x)}" y="${r1(g.y)}" width="${r1(g.w)}" height="${r1(g.h)}" stroke-width="${selected ? 0 : 1.2}"/>`);
      if (!g.reach) parts.push(`<rect fill="url(#st-hatch)" x="${r1(g.x)}" y="${r1(g.y)}" width="${r1(g.w)}" height="${r1(g.h)}"/>`);
      parts.push(`<line class="s-ink" x1="${r1(g.x)}" x2="${r1(g.x + g.w)}" y1="${r1(g.y + PADY + HEAD - 3)}" y2="${r1(g.y + PADY + HEAD - 3)}" stroke-width="0.55" opacity="0.7"/>`);
      // lines
      const lineY = i => g.y + PADY + HEAD + LINE * i + 10; // baseline of op line i (0-based)
      const hdrY = g.y + PADY + 12;
      const ids = [bid, ...b.ops.map((o, i) => lineId(cfg, b, i)), lineId(cfg, b, 'term')];
      ids.forEach((id, i) => {
        const top = i === 0 ? g.y : g.y + PADY + HEAD - 3 + LINE * (i - 1);
        const hgt = i === 0 ? PADY + HEAD - 3 : LINE;
        const isSel = i > 0 && selId === id;
        const isCur = i > 0 && current === id;
        const yb = i === 0 ? hdrY : lineY(i - 1);
        if (isSel) parts.push(`<rect class="f-sel" x="${r1(g.x + 1)}" y="${r1(top + 0.5)}" width="${r1(g.w - 2)}" height="${r1(hgt)}"/><rect class="f-acc" x="${r1(g.x + 1)}" y="${r1(top + 0.5)}" width="2" height="${r1(hgt)}"/>`);
        if (isCur) parts.push(`<rect class="s-blue" fill="none" x="${r1(g.x + 2)}" y="${r1(top + 1)}" width="${r1(g.w - 4)}" height="${r1(hgt - 1)}" stroke-width="1"/>`);
        const cls = i === 0 ? 'lbl95 b t-ink' : (i === ids.length - 1 ? 'lbl95 t-ink term' : 'lbl95 t-ink');
        parts.push(`<g class="ln" data-id="${esc(i === 0 ? bid : id)}"><rect class="hit" x="${r1(g.x)}" y="${r1(top)}" width="${r1(g.w)}" height="${r1(hgt)}" fill="transparent"/>`);
        parts.push(`<text class="${cls}" x="${r1(g.x + PADX)}" y="${r1(yb)}">${esc(g.text[i])}</text>`);
        const ann = g.ann[i] || [];
        if (ann.length) {
          let ax = g.x + PADX + g.textW + 14;
          for (const a of ann) {
            const t = cut(a.text, 40);
            parts.push(`<text class="lbl8 t-${a.cls}" x="${r1(ax)}" y="${r1(yb)}">${esc(t)}</text>`);
            ax += (t.length + 2) * CW * (8 / 9.5);
          }
        }
        if (i > 0 && ov.has('safepoints') && (opts.facts && (opts.facts.safepoints || []).includes(id))) parts.push(`<circle class="f-amber" cx="${r1(g.x + 4.5)}" cy="${r1(yb - 3)}" r="2"/>`);
        parts.push('</g>');
      });
      if (ov.has('path') && visits) {
        parts.push(`<rect class="f-blue" x="${r1(g.x - 3)}" y="${r1(g.y)}" width="2" height="${r1(g.h)}"/><text class="lbl8 t-blue" text-anchor="end" x="${r1(g.x + g.w - 5)}" y="${r1(hdrY)}">×${visits}</text>`);
      }
      if (ov.has('iteration') && opts.step && opts.step.block === b.name) parts.push(`<rect fill="none" class="s-ghost" stroke-dasharray="3 2" x="${r1(g.x - 5)}" y="${r1(g.y - 5)}" width="${r1(g.w + 10)}" height="${r1(g.h + 10)}" stroke-width="1"/>`);
      if (selected) parts.push(`<rect fill="none" class="s-acc" x="${r1(g.x)}" y="${r1(g.y)}" width="${r1(g.w)}" height="${r1(g.h)}" stroke-width="2"/>`);
      if (b.name === cfg.entry) parts.push(`<text class="lbl8 t-mut" x="${r1(g.x)}" y="${r1(g.y - 5)}">ENTRY</text>`);
      parts.push('</g>');
    }
    // title block, bottom right
    const counts = cfg.blocks.reduce((s, b) => s + b.ops.length + 1, 0);
    const rows = [
      ['STRATA', opts.title || ''],
      ['fn', `${cfg.name}${cfg.params && cfg.params.length ? '(' + cfg.params.map(p => p.id).join(', ') + ')' : ''}`],
      ['level', `${opts.level || 'L1'} · ${cfg.blocks.length} blocks · ${counts} ops`],
      ['show', [...ov].join(' · ') || 'nothing'],
      ['run', opts.run ? `${opts.run.mode || 'spec'} · ${opts.run.outcome ? opts.run.outcome.kind : '—'} · ${opts.run.steps != null ? opts.run.steps + ' steps' : ''}` : '—'],
    ];
    const tx = sheetW - tb.w - 14, ty = sheetH - rows.length * 15 - 14;
    parts.push(`<g class="titleblock"><rect class="f-bg s-ink" x="${r1(tx)}" y="${r1(ty)}" width="${tb.w}" height="${rows.length * 15}" stroke-width="1"/>`);
    rows.forEach((row, i) => {
      const y = ty + i * 15;
      if (i) parts.push(`<line class="s-ink" x1="${r1(tx)}" x2="${r1(tx + tb.w)}" y1="${r1(y)}" y2="${r1(y)}" stroke-width="0.55"/>`);
      if (i === 0) parts.push(`<text class="ttl t-ink" x="${r1(tx + 6)}" y="${r1(y + 11)}">STRATA</text><text class="lbl8 t-mut" text-anchor="end" x="${r1(tx + tb.w - 6)}" y="${r1(y + 11)}">${esc(cut(row[1], 34))}</text>`);
      else parts.push(`<text class="lbl8 t-mut" x="${r1(tx + 6)}" y="${r1(y + 10.5)}">${esc(row[0].toUpperCase())}</text><text class="lbl8 t-ink" x="${r1(tx + 44)}" y="${r1(y + 10.5)}">${esc(cut(row[1], 34))}</text>`);
    });
    parts.push('</g></svg>');
    el.innerHTML = parts.join('');
    if (!el.__strataStage) {
      el.__strataStage = true;
      el.addEventListener('click', ev => {
        const t = ev.target.closest('[data-id]');
        if (t && el.__onSelect) el.__onSelect(t.getAttribute('data-id'), ev);
        else if (!t && el.__onSelect) el.__onSelect(null, ev);
      });
    }
    el.__onSelect = opts.onSelect || null;
    return { width: sheetW, height: sheetH };
  }

  root.StrataStage = { draw, layout, OVERLAYS, pathInfo };
})(typeof window !== 'undefined' ? window : globalThis);
