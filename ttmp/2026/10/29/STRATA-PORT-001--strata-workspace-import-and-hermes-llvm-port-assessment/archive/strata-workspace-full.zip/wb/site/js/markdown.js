/* Strata Workbench: the Markdown the reading views render (notes, docs, book, reference, agent answers).
   Follows Form Skate Workbench "The Markdown the reading views render". Raw HTML is escaped. */
(function (root) {
  'use strict';

  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const slug = t => String(t).toLowerCase().replace(/<[^>]+>/g, '').replace(/&[a-z]+;/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

  // ---------- code highlighting (the editor's colours: tk-k keyword, tk-s string, tk-n number, tk-c comment, tk-p punctuation, tk-e arrow) ----------
  const KW = new Set(('const let var function return if else for of in new await async try catch finally throw import from export class ' +
    'typeof instanceof true false null undefined this while do continue break switch case default delete void yield static get set extends super').split(' '));
  const JS_TOKEN = /(\/\/[^\n]*)|(\/\*[\s\S]*?\*\/)|(`(?:\\[\s\S]|[^`\\])*`)|('(?:\\.|[^'\\\n])*'|"(?:\\.|[^"\\\n])*")|(\b0x[0-9a-fA-F]+n?\b|\b\d[\d_]*(?:\.\d+)?(?:e[+-]?\d+)?n?\b)|([A-Za-z_$][\w$]*)|(=>)|([{}()[\];,.:?=+\-*/%<>!&|^~])|(\s+)|([\s\S])/g;
  function tokensJS(code) {
    const out = []; let m; JS_TOKEN.lastIndex = 0;
    while ((m = JS_TOKEN.exec(code))) {
      if (m[1] || m[2]) out.push(['c', m[0]]);
      else if (m[3] || m[4]) out.push(['s', m[0]]);
      else if (m[5]) out.push(['n', m[0]]);
      else if (m[6]) out.push([KW.has(m[6]) ? 'k' : '', m[0]]);
      else if (m[7]) out.push(['e', m[0]]);
      else if (m[8]) out.push(['p', m[0]]);
      else out.push(['', m[0]]);
    }
    return out;
  }
  const IR_KW = new Set('fn invoke normal throw branch jump return unreachable entry'.split(' '));
  const IR_TOKEN = /(\/\/[^\n]*|;[^\n]*)|("(?:\\.|[^"\\\n])*")|(\b\d[\d_]*(?:\.\d+)?(?:e[+-]?\d+)?n?\b)|([A-Za-z_$][\w$.]*)|([{}()[\],:=<>])|(\s+)|([\s\S])/g;
  function tokensIR(code) {
    const out = []; let m; IR_TOKEN.lastIndex = 0;
    while ((m = IR_TOKEN.exec(code))) {
      if (m[1]) out.push(['c', m[0]]);
      else if (m[2]) out.push(['s', m[0]]);
      else if (m[3]) out.push(['n', m[0]]);
      else if (m[4]) out.push([IR_KW.has(m[4]) ? 'k' : '', m[0]]);
      else if (m[5]) out.push(['p', m[0]]);
      else out.push(['', m[0]]);
    }
    return out;
  }
  function tokens(code, lang) {
    lang = (lang || 'js').toLowerCase();
    if (lang === 'js' || lang === 'javascript' || lang === 'ts' || lang === 'mjs') return tokensJS(code);
    if (lang === 'ir' || lang === 'core' || lang === 'llvm' || lang === 'wat') return tokensIR(code);
    return [['', code]];
  }
  /** Highlighted lines: an array of HTML strings, one per source line (spans never cross a line). */
  function highlightLines(code, lang) {
    const lines = [''];
    for (const [cls, text] of tokens(String(code), lang)) {
      const parts = text.split('\n');
      parts.forEach((part, i) => {
        if (i > 0) lines.push('');
        if (!part) return;
        lines[lines.length - 1] += cls ? `<span class="tk-${cls}">${esc(part)}</span>` : esc(part);
      });
    }
    return lines;
  }
  const highlight = (code, lang) => highlightLines(code, lang).join('\n');

  // ---------- maths ----------
  function tex(src, display) {
    const k = root.katex;
    if (k && k.renderToString) {
      try { return k.renderToString(src, { output: 'mathml', throwOnError: false, displayMode: !!display }); } catch (e) { /* fall through */ }
    }
    return display ? `<pre class="tex">${esc(src)}</pre>` : `<code class="tex">${esc(src)}</code>`;
  }

  // ---------- inline ----------
  function findClose(s, i) { // s[i] === '(' ; returns index of the matching ')', one level of nesting allowed
    let depth = 0;
    for (let j = i; j < s.length; j++) {
      if (s[j] === '(') depth++;
      else if (s[j] === ')') { depth--; if (depth === 0) return j; }
      else if (s[j] === '\n') return -1;
    }
    return -1;
  }
  function inline(text, opts) {
    opts = opts || {};
    const keep = [];
    const hold = html => { keep.push(html); return '\u0000' + (keep.length - 1) + '\u0000'; };
    let s = String(text);
    s = s.replace(/\\\$/g, () => hold('$'));
    // code spans
    s = s.replace(/(`+)([\s\S]*?[^`])\1(?!`)/g, (m, ticks, body) => hold(`<code>${esc(body.trim() === '' ? body : body.replace(/^ (.*) $/, '$1'))}</code>`));
    // inline maths: $x$ with no space just inside and no letter or digit right after the closing $
    s = s.replace(/\$(?!\s)([^$\n]+?)(?<!\s)\$(?![A-Za-z0-9])/g, (m, body) => hold(tex(body, false)));
    // links
    let out = ''; let i = 0;
    while (i < s.length) {
      const b = s.indexOf('[', i);
      if (b < 0) { out += s.slice(i); break; }
      // find the matching ']' then '('
      let depth = 0, e = -1;
      for (let j = b; j < s.length; j++) { if (s[j] === '[') depth++; else if (s[j] === ']') { depth--; if (depth === 0) { e = j; break; } } else if (s[j] === '\n' && j > b + 200) break; }
      if (e < 0 || s[e + 1] !== '(') { out += s.slice(i, b + 1); i = b + 1; continue; }
      const close = findClose(s, e + 1);
      if (close < 0) { out += s.slice(i, b + 1); i = b + 1; continue; }
      const label = s.slice(b + 1, e), target = s.slice(e + 2, close).trim();
      out += s.slice(i, b);
      out += hold(link(label, target, opts, keep));
      i = close + 1;
    }
    s = out;
    s = esc(s).replace(/\u0000(\d+)\u0000/g, '\u0000$1\u0000'); // esc keeps the markers intact
    s = emphasis(s);
    // restore (repeatedly: link labels may hold markers)
    for (let n = 0; n < 4 && /\u0000\d+\u0000/.test(s); n++) s = s.replace(/\u0000(\d+)\u0000/g, (m, k) => keep[+k]);
    return s;
  }
  function emphasis(s) {
    s = s.replace(/\*\*(?=\S)([\s\S]*?\S)\*\*/g, '<b>$1</b>');
    s = s.replace(/(^|[^*\w])\*(?=\S)([^*\n]*?\S)\*(?!\*)/g, '$1<em>$2</em>');
    s = s.replace(/(^|[^\w])_(?=\S)([^_\n]*?\S)_(?![\w])/g, '$1<em>$2</em>');
    return s;
  }
  function link(label, target, opts, keep) {
    const inner = inline(label, opts);
    if (/^lab:/.test(target)) {
      if (opts.plainLab) return `<span class="lablink-plain">${inner}</span>`;
      return `<a href="#" class="lablink" data-lab="${esc(target)}">${inner}</a>`;
    }
    if (/^#/.test(target)) return `<a href="#" data-anchor="${esc(slug(target.slice(1)))}">${inner}</a>`;
    if (/^https?:\/\//.test(target)) return `<a href="${esc(target)}" target="_blank" rel="noopener">${inner}</a>`;
    return inner;
  }

  // ---------- figures ----------
  let figSeq = 0;
  function figure(svg, caption, opts) {
    const src = svg.trim();
    if (!/^<svg[\s>]/.test(src) || /<\s*(script|foreignObject|image|style|iframe)\b/i.test(src) || /\son\w+\s*=/i.test(src)) {
      return `<div class="fail"><b>This figure does not render:</b> it must start with &lt;svg and use no script, style, image or foreignObject.</div>`;
    }
    const n = ++figSeq, pre = 'f' + n + '-';
    let s = src.replace(/\sid="([^"]+)"/g, (m, id) => ` id="${pre}${id}"`)
      .replace(/url\(#([^)]+)\)/g, (m, id) => `url(#${pre}${id})`)
      .replace(/(xlink:)?href="#([^"]+)"/g, (m, x, id) => `${x || ''}href="#${pre}${id}"`);
    s = s.replace(/^<svg\b/, '<svg class="figsvg" role="img"');
    return `<figure class="fig">${s}${caption ? `<figcaption>${inline(caption, opts)}</figcaption>` : ''}</figure>`;
  }

  // ---------- blocks ----------
  const isFence = l => /^\s*(```|~~~)/.test(l);
  const isTableSep = l => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(l);
  const listRe = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/;
  function splitRow(line) {
    let l = line.trim(); if (l.startsWith('|')) l = l.slice(1); if (l.endsWith('|') && !l.endsWith('\\|')) l = l.slice(0, -1);
    const cells = []; let cur = '', inCode = false;
    for (let i = 0; i < l.length; i++) {
      const c = l[i];
      if (c === '\\' && l[i + 1] === '|') { cur += '|'; i++; continue; }
      if (c === '`') inCode = !inCode;
      if (c === '|' && !inCode) { cells.push(cur.trim()); cur = ''; continue; }
      cur += c;
    }
    cells.push(cur.trim());
    return cells;
  }
  function table(lines, opts) {
    const head = splitRow(lines[0]), sep = splitRow(lines[1]);
    const align = sep.map(c => /^:-+:$/.test(c) ? 'center' : /-+:$/.test(c) ? 'right' : '');
    const cell = (tag, c, i) => `<${tag}${align[i] ? ` style="text-align:${align[i]}"` : ''}>${inline(c, opts)}</${tag}>`;
    let h = `<div class="tablewrap-x"><table class="rt doc-t"><thead><tr>${head.map((c, i) => cell('th', c, i)).join('')}</tr></thead><tbody>`;
    for (const l of lines.slice(2)) h += `<tr>${splitRow(l).map((c, i) => cell('td', c, i)).join('')}</tr>`;
    return h + '</tbody></table></div>';
  }
  function list(lines, opts) {
    // lines: raw list block lines. Build nested lists by indentation.
    const items = []; // { indent, ordered, text, children }
    for (const l of lines) {
      const m = l.match(listRe);
      if (m) items.push({ indent: m[1].replace(/\t/g, '  ').length, ordered: /\d/.test(m[2]), start: parseInt(m[2], 10), text: m[3] });
      else if (items.length) items[items.length - 1].text += ' ' + l.trim();
    }
    let i = 0;
    function build(minIndent) {
      if (i >= items.length) return '';
      const first = items[i], ordered = first.ordered, indent = first.indent;
      let h = ordered ? `<ol${first.start > 1 ? ` start="${first.start}"` : ''}>` : '<ul>';
      while (i < items.length && items[i].indent >= minIndent) {
        const it = items[i];
        if (it.indent > indent) { h = h.replace(/<\/li>$/, '') + build(it.indent) + '</li>'; continue; }
        if (it.indent < indent || it.ordered !== ordered) break;
        i++;
        const task = it.text.match(/^\[( |x)\]\s+(.*)$/);
        const body = task ? `<span class="box${task[1] === 'x' ? ' on' : ''}"></span> ${inline(task[2], opts)}` : inline(it.text, opts);
        h += `<li>${body}</li>`;
      }
      return h + (ordered ? '</ol>' : '</ul>');
    }
    let out = '';
    while (i < items.length) out += build(items[i].indent);
    return out;
  }
  function callout(lines, opts) {
    const body = lines.map(l => l.replace(/^\s*>\s?/, '')).join('\n');
    const m = body.match(/^\s*\*\*(Try it|Exercise|Careful|Note)\.?\*\*/);
    const cls = !m ? 'callout' : m[1] === 'Try it' ? 'callout try' : m[1] === 'Exercise' ? 'callout exercise' : m[1] === 'Careful' ? 'callout caveat' : 'callout';
    return `<div class="${cls}">${blocks(body.split('\n'), Object.assign({}, opts, { inCallout: true })).html}</div>`;
  }

  function blocks(lines, opts) {
    let html = '';
    const heads = [];
    let i = 0, sawH1 = false, ledeDone = false, tocAt = -1;
    const para = [];
    const flush = () => {
      if (!para.length) return;
      const text = para.join(' ').trim(); para.length = 0;
      if (!text) return;
      html += `<p>${inline(text, opts)}</p>`;
      if (sawH1 && !ledeDone) { ledeDone = true; tocAt = html.length; }
    };
    while (i < lines.length) {
      const l = lines[i];
      if (!l.trim()) { flush(); i++; continue; }
      if (isFence(l)) {
        flush();
        const fence = l.trim().slice(0, 3), lang = l.trim().slice(3).trim().toLowerCase();
        const body = []; i++;
        while (i < lines.length && !lines[i].trim().startsWith(fence)) body.push(lines[i++]);
        i++;
        const code = body.join('\n');
        if (lang === 'svg') {
          // caption: the next paragraph that starts with Figure (bold allowed)
          let j = i; while (j < lines.length && !lines[j].trim()) j++;
          let cap = '';
          if (j < lines.length && /^\s*(\*\*)?Figure\s/.test(lines[j])) {
            const capLines = [];
            while (j < lines.length && lines[j].trim() && !isFence(lines[j])) capLines.push(lines[j++].trim());
            cap = capLines.join(' '); i = j;
          }
          html += figure(code, cap, opts);
        } else if (lang === 'math' || lang === 'tex' || lang === 'latex') {
          html += `<div class="mathblock">${tex(code, true)}</div>`;
        } else {
          const hl = ['', 'js', 'javascript', 'ts', 'mjs', 'ir', 'core', 'llvm', 'wat'].includes(lang);
          html += `<pre class="src${hl ? '' : ' plain'}">${hl && opts.highlight !== false ? highlight(code, lang || 'js') : esc(code)}</pre>`;
        }
        continue;
      }
      if (/^\s*\$\$\s*$/.test(l)) {
        flush(); const body = []; i++;
        while (i < lines.length && !/^\s*\$\$\s*$/.test(lines[i])) body.push(lines[i++]);
        i++;
        html += `<div class="mathblock">${tex(body.join('\n'), true)}</div>`;
        continue;
      }
      const dm = l.match(/^\s*\$\$(.+)\$\$\s*$/);
      if (dm) { flush(); html += `<div class="mathblock">${tex(dm[1], true)}</div>`; i++; continue; }
      const hm =l.match(/^(#{1,4})\s+(.*?)\s*#*\s*$/);
      if (hm) {
        flush();
        const level = hm[1].length, text = hm[2], id = (opts.prefix || '') + slug(text);
        if (level === 1) sawH1 = true;
        if (level === 2) heads.push({ id, text });
        html += `<h${level} id="${esc(id)}">${inline(text, opts)}</h${level}>`;
        i++; continue;
      }
      if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(l) && !para.length) { flush(); html += '<hr>'; i++; continue; }
      if (/^\s*>/.test(l)) {
        flush(); const q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) q.push(lines[i++]);
        html += callout(q, opts); continue;
      }
      if (/^\s*\|/.test(l) && i + 1 < lines.length && isTableSep(lines[i + 1])) {
        flush(); const t = [];
        while (i < lines.length && /^\s*\|/.test(lines[i])) t.push(lines[i++]);
        html += table(t, opts); continue;
      }
      if (listRe.test(l) && !para.length) {
        flush(); const L = [];
        while (i < lines.length) {
          const x = lines[i];
          if (listRe.test(x) || (x.trim() && /^\s{2,}\S/.test(x) && L.length)) { L.push(x); i++; continue; }
          if (!x.trim() && i + 1 < lines.length && (listRe.test(lines[i + 1]) && /^\s+/.test(lines[i + 1]))) { i++; continue; }
          break;
        }
        html += list(L, opts); continue;
      }
      para.push(l); i++;
    }
    flush();
    if (opts.toc && heads.length >= 3 && !opts.inCallout) {
      const toc = `<div class="toc">${heads.map(h => `<a href="#" data-anchor="${esc(h.id)}">${inline(h.text, opts)}</a>`).join('')}</div>`;
      html = tocAt >= 0 ? html.slice(0, tocAt) + toc + html.slice(tocAt) : toc + html;
    }
    return { html, heads };
  }

  function parseFrontmatter(md) {
    const m = String(md).match(/^---\n([\s\S]*?)\n---\n?/);
    if (!m) return { meta: {}, body: String(md) };
    const meta = {};
    for (const line of m[1].split('\n')) {
      const k = line.match(/^([A-Za-z_][\w-]*):\s*(.*)$/);
      if (k) meta[k[1]] = k[2].trim();
    }
    return { meta, body: String(md).slice(m[0].length) };
  }

  /** render(md, { prefix: 'n-'|'d-'|'r-'|'b-', toc, highlight, plainLab }) → { html, heads } via .html; returns the html string. */
  function render(md, opts) {
    opts = opts || {};
    const { body } = parseFrontmatter(md || '');
    return blocks(body.replace(/\r\n?/g, '\n').split('\n'), opts).html;
  }
  function headings(md, prefix) {
    const { body } = parseFrontmatter(md || '');
    return blocks(body.replace(/\r\n?/g, '\n').split('\n'), { prefix: prefix || '' }).heads;
  }
  function plainText(md) { // for search: strip markup
    return String(md || '').replace(/```[\s\S]*?```/g, ' ').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/[#*_`>|$]/g, ' ');
  }

  root.StrataMarkdown = { render, inline: (t, o) => inline(t, o || {}), highlight, highlightLines, slug, esc, parseFrontmatter, headings, plainText, tex };
})(typeof window !== 'undefined' ? window : globalThis);
